<?php


//
//	
//	WallCityServer
//	Shoutcast Admin Panel	
//	
//	Copyright 2008 
//
////////////////////////////////

session_start();

if (!isset($_GET['step']))
	$step = "1";
else
	$step = $_GET['step'];


function error($text,$back="\"javascript:history.back(1)\"")
{
	echo "
	<table border=\"1\" width=\"90%\" style=\"border:1px solid #A0A0A0; border-collapse: collapse\" bordercolor=\"#808080\">
		<tr>
			<td style=\"padding: 6px;\" bgcolor=\"#F7F7F7\" align=\"left\" valign=\"top\">
				 <font color=\"#FF9D3C\">Installations Fehler !</font>
			</td>
		</tr>
		<tr>
			<td style=\"padding: 18px;\">
			$text
			<br>Klicke <a href=\"$back\">hier</a> um zur&uuml;ck zu kommen
			</td>
		</tr>
	</table>
	<br><br>
	";
	exit;
}

function table($title,$width="90%")
{
	echo "
	<table border=\"0\" width=\"$width\">
		<tr>
			<td align=\"left\" valign=\"top\">
				 <font color=\"#85AC1E\">$title</font>
			</td>
		</tr>
		<tr>
			<td style=\"padding: 18px;\">
	";
}
function closetable($width="90%")
{
	echo "
			</td>
		</tr>
	</table>
	<br><br>
	";
}


?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html>
<head>
<meta http-equiv="content-type" content="text/html; charset=iso-8859-1" />
<title><?=$setting['page_title']?></title>
<meta name="keywords" content="" />
<meta name="description" content="" />
<link rel="stylesheet" type="text/css" href="../system/default.css" />
<script language="javascript" type="text/javascript">
var win=null;
function NewWindow(mypage,myname,w,h,scroll,pos){
if(pos=="random"){LeftPosition=(screen.width)?Math.floor(Math.random()*(screen.width-w)):100;TopPosition=(screen.height)?Math.floor(Math.random()*((screen.height-h)-75)):100;}
if(pos=="center"){LeftPosition=(screen.width)?(screen.width-w)/2:100;TopPosition=(screen.height)?(screen.height-h)/2:100;}
else if((pos!="center" && pos!="random") || pos==null){LeftPosition=0;TopPosition=20}
settings='width='+w+',height='+h+',top='+TopPosition+',left='+LeftPosition+',scrollbars='+scroll+',location=no,directories=no,status=no,menubar=no,toolbar=no,resizable=no';
win=window.open(mypage,myname,settings);}
</script>
</head>
<body>
<div id="header">
	<div id="header_inner">
		<h1><span>shoutcast.</span>admin panel</h1>
		</div>
</div>
<div id="main">
	<div id="lcol">
		<div id="menu">
			<ul>
              <li><?php if ($step==1) echo "<font color='red'>"; ?>Pr&uuml;fung<?php if ($step==1) echo "</font>"; ?></li> 
              <li><?php if ($step==2) echo "<font color='red'>"; ?>Datenbank<?php if ($step==2) echo "</font>"; ?></li>
              <li><?php if ($step==3) echo "<font color='red'>"; ?>Einstellungen<?php if ($step==3) echo "</font>"; ?></li>
              <li><?php if ($step==4) echo "<font color='red'>"; ?>Admin<?php if ($step==4) echo "</font>"; ?></li> 
              <li><?php if ($step==5) echo "<font color='red'>"; ?>Ende<?php if ($step==5) echo "</font>"; ?></li> 
 </ul>
            
      </ul>			</ul>
	  </div>
		<div id="menu_end"></div>
		<div id="lcontent">
			<h3 class="first">panel.<span>Status</span></h3>
			<ul class="divided">
				<li>Deine IP:&nbsp;<?php echo $_SERVER['REMOTE_ADDR']; ?></li>
				<li>Server IP:&nbsp;<?php echo $_SERVER['SERVER_ADDR']; ?></li>
                <li>Panel Version:&nbsp;2.1</li>
			</ul>
	  </div>
	</div>
	<div id="rcol">
		<div id="rcontent">
   	    <?php

if ($step == "1")
{
	table("Schritt 1 - Rechte Check");
	$serv_exe = false;
	if( strtoupper(substr(PHP_OS, 0, 3)) === 'WIN' )
	{
		$serv_perms = substr(sprintf('%o', fileperms("../files/windows/sc_serv.exe")), -4);
		if ( $serv_perms >= 0777 )
		{
			$serv_exe = true;
			echo "File: root/files/windows/sc_serv.exe <font color='green'>Ausf&uuml;hrbar</font><br>";
		}else{
			$serv_exe = false;
			echo "File: root/files/windows/sc_serv.exe <font color='red'>Nicht->Ausf&uuml;hrbar</font><br>";	
		}
	}else{
		$serv_perms = substr(sprintf('%o', fileperms("../files/linux/sc_serv")), -4);
		if ( $serv_perms >= 0777 )
		{
			$serv_exe = true;
			echo "File: root/files/windows/sc_serv <font color='green'>Ausf&uuml;hrbar</font><br>";
		}else{
			$serv_exe = false;
			echo "File: root/files/windows/sc_serv <font color='red'>Nicht->Ausf&uuml;hrbar</font><br>";	
		}
	}
	if (is_writable("../database.php"))
		echo "File: root/database.php <font color='green'>Ausf&uuml;hrbar</font>";
	else
		echo "File: root/database.php <font color='red'>Nicht->Ausf&uuml;hrbar</font>";
	echo "<br>";
	if (is_writable("../temp/"))
		echo "Directory: root/temp <font color='green'>Ausf&uuml;hrbar</font>";
	else
		echo "Directory: root/temp <font color='red'>Nicht->Ausf&uuml;hrbar</font>";
	echo "<br>";
	if (is_writable("../logs/"))
		echo "Directory: root/logs <font color='green'>Ausf&uuml;hrbar</font>";
	else
		echo "Directory: root/logs <font color='red'>Nicht->Ausf&uuml;hrbar</font>";
	echo "<br>";

	if (!is_writable("../temp/") || !is_writable("../database.php") || !is_writable("../logs/"))
	{
		echo "<br><font color='red'>Bitte versichern Sie sich &uuml;ber die Rechte und laden Sie diese Seite neu.</font>";
	}else{
		if ($serv_exe == false)
		{	echo "<br><font color='red'>Datei sc_serv ist nicht ausf&uuml;hrbar, wir empfehlen die Rechte auf 733 zu &auml;ndern.</font><br>";	}
		else
		{	echo "<br><font color='green'>Datei sc_serv file ist ausf&uuml;hrbar und alle anderen Dateien sind in Ordnung.<br>Bitte klicken Sie auf Fortsetzten.</font><br>";	}
			echo "<br>Klicke <a href='?step=2'>hier</a> um fortzusetzen.</a>";
		}
	closetable();
	
}

if ($step == "2")
{

	if (isset($_POST['s2-submit']))
	{
		
		if(!$connection = mysql_connect($_POST['database_host'], $_POST['database_username'], $_POST['database_password']))
			echo error(mysql_error());
		else if(!$db = mysql_select_db($_POST['database_name'])){
			echo error(mysql_error());
		}else{

			$_SESSION['database_host'] = $_POST['database_host'];
			$_SESSION['database_username'] = $_POST['database_username'];
			$_SESSION['database_password'] = $_POST['database_password'];
			$_SESSION['database_name'] = $_POST['database_name'];

			table("MySQL Verbindung");
			echo "MySQL Verbindung hergestellt.";
			
			if(
				mysql_query("
				CREATE TABLE headlines (
				 id int(11) NOT NULL auto_increment,
 				 username varchar(100) NOT NULL default '',
 				 title varchar(100) NOT NULL default '',
 				 text text NOT NULL,
 				 PRIMARY KEY  (id)
				) TYPE=MyISAM AUTO_INCREMENT=11 ")
			)	echo "<br>Tabelle 'headlines' erfolgreich erstellt.";
			else  echo "<br><font color='red'>".mysql_error()."</font>";
			
			if(
				mysql_query("
				CREATE TABLE ini_sets (
				  id int(11) NOT NULL auto_increment,
				  field varchar(100) NOT NULL default '',
				  value varchar(100) NOT NULL default '',
				  `default` varchar(100) NOT NULL default '',
				  title varchar(100) NOT NULL default '',
				  description varchar(100) NOT NULL default '',
				  admin_editable int(11) NOT NULL default '1',
				  user_editable int(11) NOT NULL default '1',
				  type int(11) NOT NULL default '1',
				  PRIMARY KEY  (id)
				) TYPE=MyISAM AUTO_INCREMENT=33 ")
			)	echo "<br>Tabelle 'ini_sets' erfolgreich erstellt.";
			else  echo "<br><font color='red'>".mysql_error()."</font>";
			
			if(
				mysql_query("
				CREATE TABLE notices (
				  id int(11) NOT NULL auto_increment,
				  username varchar(100) NOT NULL default '',
				  reason varchar(100) NOT NULL default '',
 				 message varchar(100) NOT NULL default '',
 				 ip varchar(100) NOT NULL default '',
 				 time varchar(100) NOT NULL default '',
 				 PRIMARY KEY  (id)
				) TYPE=MyISAM AUTO_INCREMENT=20")
			)	echo "<br>Tabelle 'notices' erfolgreich erstellt.";
			else  echo "<br><font color='red'>".mysql_error()."</font>";

			if(
				mysql_query("
				CREATE TABLE servers (
  				 id int(11) NOT NULL auto_increment,
  				 owner varchar(100) NOT NULL default '',
  				 maxuser varchar(100) NOT NULL default '',
  				 portbase int(11) NOT NULL default '0',
  				 bitrate varchar(100) NOT NULL default '',
 				 adminpassword varchar(100) NOT NULL default '',
  				 password varchar(100) NOT NULL default '',
  				 sitepublic varchar(100) NOT NULL default '1',
  				 logfile varchar(100) NOT NULL default '../../logs/sc_{port}.log',
 				 realtime varchar(100) NOT NULL default '1',
 				 screenlog varchar(100) NOT NULL default '0',
 				 showlastsongs varchar(100) NOT NULL default '10',
 				 tchlog varchar(100) NOT NULL default 'Yes',
 				 weblog varchar(100) NOT NULL default 'no',
 				 w3cenable varchar(100) NOT NULL default 'Yes',
 				 w3clog varchar(100) NOT NULL default 'sc_w3c.log',
 				 srcip varchar(100) NOT NULL default 'ANY',
 				 destip varchar(100) NOT NULL default 'ANY',
 				 yport varchar(100) NOT NULL default '80',
 				 namelookups varchar(100) NOT NULL default '0',
 				 relayport varchar(100) NOT NULL default '0',
 				 relayserver varchar(100) NOT NULL default 'empty',
 				 autodumpusers varchar(100) NOT NULL default '0',
 				 autodumpsourcetime varchar(100) NOT NULL default '30',
 				 contentdir varchar(100) NOT NULL default '',
 				 introfile varchar(100) NOT NULL default '',
 				 titleformat varchar(100) NOT NULL default '',
 				 publicserver varchar(100) NOT NULL default 'default',
 				 allowrelay varchar(100) NOT NULL default 'Yes',
 				 allowpublicrelay varchar(100) NOT NULL default 'Yes',
 				 metainterval varchar(100) NOT NULL default '32768',
 				 suspended varchar(100) NOT NULL default '',
 				 abuse int(11) NOT NULL default '0',
 				 pid varchar(100) NOT NULL default '',
				  PRIMARY KEY  (id)
				) TYPE=MyISAM AUTO_INCREMENT=32")
			)	echo "<br>Tabelle 'servers' erfolgreich erstellt.";
			else  echo "<br><font color='red'>".mysql_error()."</font>";

			if(
				mysql_query("
				CREATE TABLE settings (
				  id int(11) NOT NULL default '0',
				  title varchar(20) NOT NULL default '',
				  slogan varchar(50) NOT NULL default '',
				  page_title varchar(60) NOT NULL default '',
				  footer varchar(100) NOT NULL default '',
				  display_limit int(11) NOT NULL default '10',
				  host_add varchar(100) NOT NULL default '192.168.0.1',
				  os varchar(100) NOT NULL default '',
				  dir_to_cpanel varchar(100) NOT NULL default '',
 				  contact_type varchar(100) NOT NULL default '',
 				  admin_email varchar(100) NOT NULL default '',
 				  open_ports_firewall varchar(100) NOT NULL default '0',
				  dir_to_firewall_file varchar(100) NOT NULL default '',
 				  newlink varchar(255) NOT NULL default '',
				  abuse_control varchar(255) NOT NULL default '1',
 				  abuse_max_count varchar(100) NOT NULL default '4',
				  suspended_email int(11) NOT NULL default '1',
 				  suspended_days varchar(100) NOT NULL default '3',
 				  extra longtext NOT NULL,
				  PRIMARY KEY  (id)
				) TYPE=MyISAM")
			)	echo "<br>Tabelle 'settings' erfolgreich erstellt.";
			else  echo "<br><font color='red'>".mysql_error()."</font>";


			if(
				mysql_query("
				CREATE TABLE users (
				  id int(11) NOT NULL auto_increment,
				  username varchar(100) NOT NULL default '',
				  user_password varchar(50) NOT NULL default '',
				  md5_hash varchar(100) NOT NULL default '',
				  user_level varchar(100) NOT NULL default '',
				  user_email varchar(200) NOT NULL default '',
				  contact_number varchar(10) NOT NULL default '',
				  mobile_number varchar(10) NOT NULL default '',
				  account_notes text NOT NULL,
				  name varchar(50) NOT NULL default '',
				  surname varchar(50) NOT NULL default '',
				  age varchar(100) NOT NULL default '',
				  PRIMARY KEY  (id)
				) TYPE=MyISAM AUTO_INCREMENT=13")
			)	echo "<br>Tabelle 'users' erfolgreich erstellt.";
			else  echo "<br><font color='red'>".mysql_error()."</font>";

			echo "<br>Hinzuf&uuml;gen von Inhalten";

			if (!mysql_query("INSERT INTO `ini_sets` (`id`, `field`, `value`, `default`, `title`, `description`, `admin_editable`, `user_editable`, `type`) VALUES (1, 'c_owner', 'getowner', '', 'Inhaber', 'Der Name des Benutzers', 0, 0, 1)"))
				echo "<br>".mysql_error();
			if (!mysql_query("INSERT INTO `ini_sets` (`id`, `field`, `value`, `default`, `title`, `description`, `admin_editable`, `user_editable`, `type`) VALUES (2, 'c_adminpassword', '', '', 'Admin Passwort', 'Das Passwort des Admin', 1, 1, 1)"))
				echo "<br>".mysql_error();
			if (!mysql_query("INSERT INTO `ini_sets` (`id`, `field`, `value`, `default`, `title`, `description`, `admin_editable`, `user_editable`, `type`) VALUES (3, 'c_password', '', '', 'Passwort', 'Das Passwort zum senden', 1, 1, 1)"))
				echo "<br>".mysql_error();
			if (!mysql_query("INSERT INTO `ini_sets` (`id`, `field`, `value`, `default`, `title`, `description`, `admin_editable`, `user_editable`, `type`) VALUES (4, 'c_portbase', 'nextport', '', 'Port', '', 0, 0, 1)"))
				echo "<br>".mysql_error();
			if (!mysql_query("INSERT INTO `ini_sets` (`id`, `field`, `value`, `default`, `title`, `description`, `admin_editable`, `user_editable`, `type`) VALUES (5, 'c_maxuser', '', '', 'Max H&ouml;rer', 'das Maximum der H&ouml;rer', 1, 0, 1)"))
				echo "<br>".mysql_error();
			if (!mysql_query("INSERT INTO `ini_sets` (`id`, `field`, `value`, `default`, `title`, `description`, `admin_editable`, `user_editable`, `type`) VALUES (6, 'c_bitrate', '128', '128', 'Bitrate', 'Die Maximum zugelassene Bitrate', 1, 0, 1)"))
				echo "<br>".mysql_error();
			if (!mysql_query("INSERT INTO `ini_sets` (`id`, `field`, `value`, `default`, `title`, `description`, `admin_editable`, `user_editable`, `type`) VALUES (7, 'c_sitepublic', '1', '', '&Ouml;ffentlicher Srv.', 'den Server &Ouml;ffentlich zeigen', 1, 1, 1)"))
				echo "<br>".mysql_error();
			if (!mysql_query("INSERT INTO `ini_sets` (`id`, `field`, `value`, `default`, `title`, `description`, `admin_editable`, `user_editable`, `type`) VALUES (8, 'other', 'Leave blank for default', '', 'andere Einstellungen', '', 1, 0, 0)"))
				echo "<br>".mysql_error();
			if (!mysql_query("INSERT INTO `ini_sets` (`id`, `field`, `value`, `default`, `title`, `description`, `admin_editable`, `user_editable`, `type`) VALUES (9, 'c_logfile', '../../logs/sc_{port}.log', '', 'Log Dateien', 'Dort werden die LOG Dateien gespeichert.', 1, 0, 1)"))
				echo "<br>".mysql_error();
			if (!mysql_query("INSERT INTO `ini_sets` (`id`, `field`, `value`, `default`, `title`, `description`, `admin_editable`, `user_editable`, `type`) VALUES (10, 'c_realtime', '1', '', 'Real Time', '', 1, 0, 1)"))
				echo "<br>".mysql_error();
			if (!mysql_query("INSERT INTO `ini_sets` (`id`, `field`, `value`, `default`, `title`, `description`, `admin_editable`, `user_editable`, `type`) VALUES (11, 'c_screenlog', '1', '', 'Screen Log', 'ScreenLog controls whether logging is printed to the screen or not\r\n', 1, 0, 1)"))
				echo "<br>".mysql_error();
			if (!mysql_query("INSERT INTO `ini_sets` (`id`, `field`, `value`, `default`, `title`, `description`, `admin_editable`, `user_editable`, `type`) VALUES (12, 'c_showlastsongs', '10', '', 'Zeige die letzten Songs', 'Songs werden in /played.html gezeigt', 1, 1, 1)"))
				echo "<br>".mysql_error();
			if (!mysql_query("INSERT INTO `ini_sets` (`id`, `field`, `value`, `default`, `title`, `description`, `admin_editable`, `user_editable`, `type`) VALUES (13, 'c_tchlog', 'yes', '', 'Tch Log', '', 1, 0, 1)"))
				echo "<br>".mysql_error();
			if (!mysql_query("INSERT INTO `ini_sets` (`id`, `field`, `value`, `default`, `title`, `description`, `admin_editable`, `user_editable`, `type`) VALUES (14, 'c_weblog', 'no', '', 'Web Log', '', 1, 0, 1)"))
				echo "<br>".mysql_error();
			if (!mysql_query("INSERT INTO `ini_sets` (`id`, `field`, `value`, `default`, `title`, `description`, `admin_editable`, `user_editable`, `type`) VALUES (15, 'c_w3cenable', 'Yes', '', 'W3C Enable', '', 1, 0, 1)"))
				echo "<br>".mysql_error();
			if (!mysql_query("INSERT INTO `ini_sets` (`id`, `field`, `value`, `default`, `title`, `description`, `admin_editable`, `user_editable`, `type`) VALUES (16, 'c_w3clog', 'sc_w3c.log\r\n', '', 'W3C Log', '', 1, 0, 1);"))
				echo "<br>".mysql_error();
			if (!mysql_query("INSERT INTO `ini_sets` (`id`, `field`, `value`, `default`, `title`, `description`, `admin_editable`, `user_editable`, `type`) VALUES (17, 'c_srcip', 'ANY', '', 'Quell IP', '', 1, 1, 1)"))
				echo "<br>".mysql_error();
			if (!mysql_query("INSERT INTO `ini_sets` (`id`, `field`, `value`, `default`, `title`, `description`, `admin_editable`, `user_editable`, `type`) VALUES (18, 'c_destip', 'ANY', '', 'Ziel IP', '', 1, 1, 1);"))
				echo "<br>".mysql_error();
			if (!mysql_query("INSERT INTO `ini_sets` (`id`, `field`, `value`, `default`, `title`, `description`, `admin_editable`, `user_editable`, `type`) VALUES (19, 'c_yport', '80', '', 'Y Port', '', 0, 0, 1)"))
				echo "<br>".mysql_error();
			if (!mysql_query("INSERT INTO `ini_sets` (`id`, `field`, `value`, `default`, `title`, `description`, `admin_editable`, `user_editable`, `type`) VALUES (20, 'c_namelookups', '0', '', 'Name Lookups', '0 for none', 1, 0, 1)"))
				echo "<br>".mysql_error();
			if (!mysql_query("INSERT INTO `ini_sets` (`id`, `field`, `value`, `default`, `title`, `description`, `admin_editable`, `user_editable`, `type`) VALUES (21, 'c_relayport', '0', '', 'Relayport', '0  for none', 1, 1, 1)"))
				echo "<br>".mysql_error();
			if (!mysql_query("INSERT INTO `ini_sets` (`id`, `field`, `value`, `default`, `title`, `description`, `admin_editable`, `user_editable`, `type`) VALUES (22, 'c_relayserver', 'empty', '', 'RelayServer', 'empty for none', 1, 1, 1)"))
				echo "<br>".mysql_error();
			if (!mysql_query("INSERT INTO `ini_sets` (`id`, `field`, `value`, `default`, `title`, `description`, `admin_editable`, `user_editable`, `type`) VALUES (23, 'c_autodumpusers', '', '', 'Auto dump users', '', 1, 1, 1)"))
				echo "<br>".mysql_error();
			if (!mysql_query("INSERT INTO `ini_sets` (`id`, `field`, `value`, `default`, `title`, `description`, `admin_editable`, `user_editable`, `type`) VALUES (24, 'c_autodumpsourcetime', '', '', 'Auto Dump Source Time', '', 1, 1, 1)"))
				echo "<br>".mysql_error();
			if (!mysql_query("INSERT INTO `ini_sets` (`id`, `field`, `value`, `default`, `title`, `description`, `admin_editable`, `user_editable`, `type`) VALUES (25, 'c_contentdir', '', '', 'Inhalt Verzeichn.', '', 1, 0, 1)"))
				echo "<br>".mysql_error();
			if (!mysql_query("INSERT INTO `ini_sets` (`id`, `field`, `value`, `default`, `title`, `description`, `admin_editable`, `user_editable`, `type`) VALUES (26, 'c_introfile', '', '', 'Intro Datei', '', 1, 0, 1)"))
				echo "<br>".mysql_error();
			if (!mysql_query("INSERT INTO `ini_sets` (`id`, `field`, `value`, `default`, `title`, `description`, `admin_editable`, `user_editable`, `type`) VALUES (27, 'c_titleformat', '', '', 'Titel Format', '', 1, 1, 1)"))
				echo "<br>".mysql_error();
			if (!mysql_query("INSERT INTO `ini_sets` (`id`, `field`, `value`, `default`, `title`, `description`, `admin_editable`, `user_editable`, `type`) VALUES (28, 'c_publicserver', '', '', '&Ouml;ffentl. Server', '', 1, 1, 1);"))
				echo "<br>".mysql_error();
			if (!mysql_query("INSERT INTO `ini_sets` (`id`, `field`, `value`, `default`, `title`, `description`, `admin_editable`, `user_editable`, `type`) VALUES (29, 'c_allowrelay', '', '', 'Allow Relay', '', 1, 1, 1)"))
				echo "<br>".mysql_error();
			if (!mysql_query("INSERT INTO `ini_sets` (`id`, `field`, `value`, `default`, `title`, `description`, `admin_editable`, `user_editable`, `type`) VALUES (30, 'c_allowpublicrelay', '', '', 'Allow Public Relay', '', 1, 1, 1)"))
				echo "<br>".mysql_error();
			if (!mysql_query("INSERT INTO `ini_sets` (`id`, `field`, `value`, `default`, `title`, `description`, `admin_editable`, `user_editable`, `type`) VALUES (31, 'c_metainterval', '32768', '', 'Meta Interval', '', 0, 0, 1)"))
				echo "<br>".mysql_error();

			
			echo "<br>Hinzuf&uuml;gen von 'ini_sets' erfolgreich beendet.";

			if (!mysql_query("INSERT INTO headlines (id,username,title,text) VALUES('1','Installation', 'Willkommen', 'Willkommen zu Ihrem WallCity-Radio Admin Control"))
				echo "<br>".mysql_error();
					
			echo "<br>Hinzuf&uuml;gen von 'headlines' erfolgreich beendet.";

			echo "<br>Klicke <a href='?step=3'>hier</a> um fortzusetzen";

		//	if (!mysql_query(""))
		//		echo "<br>".mysql_error();

			closetable();
		}
		
		}else{
		table("Schritt 2 - Datenbank Einstellungen");
		echo "
		<form method='POST' action='?step=2'
		<table border='0' width='450'>
			<tr>
				<td colspan='3'>Bitte f&uuml;gen Sie Ihre Datenbank Einstellungen ein.</td>
			</tr>
			<tr>
				<td width='150'>Datenbank Server</td>
				<td width='100'><input type='text' name='database_host' value='localhost'></td>
				<td width='100'>Meist localhost</td>
			</tr>
			<tr>
				<td width='150'>Datenbank Benutzern.</td>
				<td width='150'><input type='text' name='database_username' value='root'></td>
				<td width='100'>Meist root</td>
			</tr>
			<tr>
				<td width='150'>Datenbank Passwort</td>
				<td width='150'><input type='password' name='database_password'></td>
			</tr>
			<tr>
				<td width='150'>Datenbank Name</td>
				<td width='150'><input type='text' name='database_name'></td>

			</tr>
			<tr>
				<td colspan='3' height='40' align='center'><input type='submit' name='s2-submit' value='Fortsetzen' style='background-image: url(../images/bbg1.gif); color:#FFFFFF; font-weight: bold; font-family: trebuchet ms, helvetica, sans-serif; font-size:11px; border:0;'/>	
				</td>
			</tr>
		</table>
		";
		closetable();
	}
	
}

if ($step == "3")
{
	if (!isset($_POST['s3-submit']))
	{
		table("Schritt 3 - Admin Panel Konfiguration");
		$cwd = str_replace("\\", "/", getcwd());
		$cwd = str_replace("install", "", $cwd);
		echo "
		<form method='POST' action='?step=3'>
			<table border='0'>
				<tr>
					<td width='80'>Titel:</td>
					<td width='160'><input type='text' name='title' value='WallCity-Radio'></td>
					<td width='230'>Dies ist ihr Server Titel</td>
				</tr>
				<tr>
					<td width='80'>Slogan:</td>
						<td width='160'><input type='text' name='slogan' value='Shoutcast Admin Panel Ver. 2.1'></td>
					<td width='230'>Slogan Ihres Server</td>
				</tr>
				<tr>
					<td width='80'>Seiten Titel:</td>
					<td width='160'><input type='text' name='page_title' value='WallCity Radio Admin'></td>
					<td width='230'>Dies ist Ihr Seiten Titel</td>
				</tr>
				<tr>
					<td width='80'>Footer:</td>
					<td width='160'><input type='text' name='footer' value='".$_SERVER["HTTP_HOST"]."'></td>
					<td width='230'>Dies wird als FOOTER unten-rechts angezeigt.</td>
				</tr>
				<tr>
					<td width='80'>Display:</td>
					<td width='160'><input type='text' name='display_limit' value='10'></td>
					<td width='230'>Max rows returned from query</td>
				</tr>
				<tr>
					<td width='80'>Server Addresse:</td>
					<td width='160'><input type='text' name='host_add' value='".$_SERVER["HTTP_HOST"]."'></td>
					<td width='230'>Die IP/DNS des aktuellen Host</td>
				</tr>
				<tr>
					<td width='80'>System:</td>
					<td width='160'><select style='width: 143' name='os'><option value='windows'>Windows</option><option value='linux'"; if (!strtoupper(substr(PHP_OS, 0, 3)) === 'WIN'){echo " selected";}  echo ">Linux</option></select></td>
					<td width='230'>Das Betriebssystem des Server</td>
				</tr>
				<tr>
					<td width='80'>Das Verzeichnis dieses Programmes:</td>
					<td width='160'><input type='text' name='dir_to_cpanel' value='".$cwd."'></td>
					<td width='230'><font size=2 color=red><i>Muss richtig angegeben werden!</i></font></td>
				</tr>
				<tr>
					<td width='80'>Inhalts Kontrolle:</td>
					<td width='160'><select name='abuse_control' style='width: 143'><option value='on'>On</option><option value='off'>Off</option</select></td>
					<td width='230'>Kontrolle der Bitrate</td>
				</tr>
				<tr>
					<td width='80'>Block Limit:</td>
					<td width='160'><input type='text' name='abuse_max_count' value='4'></td>
					<td width='230'>Zeiten bevor man gelockt wird</td>
				</tr>
				<tr>
					<td width='80'>Block auf Tage:</td>
					<td width='160'><input type='text' name='suspended_days' value='3'></td>
					<td width='230'>Die gesamten Tage auf die ein User geblockt wird.</td>
				</tr>
				<tr>
					<td width='80'>Block E-Mail:</td>
					<td width='160'><select name='suspended_email' style='width: 143'><option value='1'>Ja</option><option value='0'>Nein</option></select></td>
					<td width='230'>E-Mail auf Block</td>
				</tr>
				<tr>
					<td colspan='3' align='center' height='30' valign='bottom'><input type='submit' name='s3-submit' value='Fortsetzen' style='background-image: url(../images/bbg1.gif); color:#FFFFFF; font-weight: bold; font-family: trebuchet ms, helvetica, sans-serif; font-size:11px; border:0;'/></td>
				</tr>
			</table>
		";
	}else{
		if (!isset($_SESSION['database_host']) && !isset($_SESSION['database_username']) && !isset($_SESSION['database_password']) && !isset($_SESSION['database_name']))
			echo error("Keine Session gefunden.<br>Bitte gehe zur&uuml;ck zu Schritt 1", "?step=1");
		else if(!$connection = mysql_connect($_SESSION['database_host'], $_SESSION['database_username'], $_SESSION['database_password']))
			echo error(mysql_error());
		else if(!$db = mysql_select_db($_SESSION['database_name'])){
			echo error(mysql_error());
		}else{
			table("Step 3 - MySQL Prozess");
			echo "MySQL Verbindung hergestellt.";
			if (!mysql_query("INSERT INTO settings (id, title, slogan, page_title, footer, display_limit, host_add, os, dir_to_cpanel, contact_type, admin_email, open_ports_firewall, dir_to_firewall_file, newlink, abuse_control, abuse_max_count, suspended_email, suspended_days, extra) VALUES (0, '".$_POST['title']."', '".$_POST['slogan']."', '".$_POST['page_title']."', '".$_POST['footer']."', '".$_POST['display_limit']."', '".$_POST['host_add']."', '".$_POST['os']."', '".$_POST['dir_to_cpanel']."', '', '', '0', '', '?page=contact', '".$_POST['abuse_control']."', '".$_POST['abuse_max_count']."', '".$_POST['suspended_email']."', '".$_POST['suspended_days']."', '0')"))
				echo "<br>".mysql_error();
			echo "<br>Hinzuf&uuml;gen der Tabelle 'settings' erfolgreich
				<br>Klicke <a href='?step=4'>hier</a> um fortzusetzen";
			closetable();
		}
	}
}

if ($step == "4")
{
	if (!isset($_POST['s4-submit']))
	{
		table("Schritt 4 - Administrator Einstellungen");
		echo "
		<form method='POST' action='?step=4'>
			<table border='0'>
				<tr>
					<td width='100'>Benutzername:</td>
					<td width='140'><input type='text' name='username' value='Superadmin'></td>
					<td width='220'>Der Super-Admin</td>
				</tr>
				<tr>
					<td width='100'>Passwort:</td>
					<td width='140'><input type='password' name='user_password'></td>
					<td width='220'>Super-Admin Passwort</td>
				</tr>
				<tr>
					<td width='100'>Wiederholung:</td>
					<td width='140'><input type='password' name='comfirm_user_password'></td>
					<td width='220'>Passwort Wiederholung</td>
				</tr>
				<tr>
					<td width='100'>E-Mail:</td>
					<td width='140'><input type='text' name='user_email' value='admin@domain.com'></td>
					<td width='220'>Die Haupt E-Mail Adresse</td>
				</tr>
				<tr>
					<td width='100'>Name:</td>
					<td width='140'><input type='text' name='name' value='Max'></td>
					<td width='220'>Dein Vorname</td>
				</tr>
				<tr>
					<td width='100'>Nachname:</td>
					<td width='140'><input type='text' name='surname' value='Mustermann'></td>
					<td width='220'>Dein Nachname</td>
				</tr>
				<tr>
					<td width='100'>Alter:</td>
					<td width='140'><input type='text' name='age' value=''></td>
					<td width='220'>Die Alter</td>
				<tr>
					<td width='100'>Telefonnummer:</td>
					<td width='140'><input type='text' name='contact_number' value=''></td>
					<td width='220'>Deine Telefonnummer</td>
				</tr>
				<tr>
					<td width='100'>Handynummer:</td>
					<td width='140'><input type='text' name='mobile_number' value='04'></td>
					<td width='220'>Deine Handynummer</td>
				</tr>
				<tr>
					<td colspan='3' align='center' height='30' valign='bottom'><input type='submit' name='s4-submit' value='Fortsetzen' style='background-image: url(../images/bbg1.gif); color:#FFFFFF; font-weight: bold; font-family: trebuchet ms, helvetica, sans-serif; font-size:11px; border:0;'/></td>
				</tr>
			</table>";
		closetable();
	}else{

		foreach($_POST as $setting => $value)
		{
			if ($value == "" && $setting!="username")
				$value = "none";
			if ($setting == "username" && $value == "")
				echo error("Bitte gebe einen Benutzernamen ein");
			if ($setting == "user_password" && $value == "")
				echo error("Bitte gebe ein Passwort ein");
		}

		if (!isset($_SESSION['database_host']) && !isset($_SESSION['database_username']) && !isset($_SESSION['database_password']) && !isset($_SESSION['database_name']))
			echo error("Keine Session gefunden.<br>Bitte gehe zur&uuml;ck zu Schritt 1", "?step=1");
		else if ($_POST['user_password']!=$_POST['comfirm_user_password'])
			echo error("Passw&ouml;rter stimmen nicht &uuml;berein.<br>Bitte gehen Sie zur&uuml;ck.");
		else if(!$connection = mysql_connect($_SESSION['database_host'], $_SESSION['database_username'], $_SESSION['database_password']))
			echo error(mysql_error());
		else if(!$db = mysql_select_db($_SESSION['database_name'])){
			echo error(mysql_error());
		}else{
			table("Step 4 - MySQL Verbindung");
			echo "MySQL Verbindung hergestellt.";
			if (!mysql_query("INSERT INTO `users` VALUES ('1', '".$_POST['username']."', '".$_POST['user_password']."', '".md5($_POST['username'].$_POST['user_password'])."', 'Super Administrator', '".$_POST['user_email']."', '".$_POST['contact_number']."', '".$_POST['mobile_number']."', 'Default Administrator', '".$_POST['name']."', '".$_POST['surname']."', '".$_POST['age']."') "))
				echo "<br>".mysql_error();
			echo "<br>Hinzuf&uuml;gen von 'users' fertiggestellt.
				<br>Klicke <a href='?step=5'>hier</a> um fortzusetzen.";
			closetable();
		}
	}
}




if ($step == "5")
{
		if (!isset($_SESSION['database_host']) && !isset($_SESSION['database_username']) && !isset($_SESSION['database_password']) && !isset($_SESSION['database_name']))
			echo error("Keine Session gefunden.<br>Bitte gehe zur&uuml;ck zu Schritt 1", "?step=1");
		else if(!$connection = mysql_connect($_SESSION['database_host'], $_SESSION['database_username'], $_SESSION['database_password']))
			echo error(mysql_error());
		else if(!$db = mysql_select_db($_SESSION['database_name'])){
			echo error(mysql_error());
		}else{

			$settings = mysql_query("SELECT * FROM settings");
			$userq = mysql_query("SELECT * FROM users WHERE id='1'");
			$userdata = mysql_fetch_array($userq);

			$db_file = fopen("../database.php", "w");
			if (!fwrite($db_file, "<?php\n if (!eregi(\"index.php\", \$_SERVER['PHP_SELF']))\n    die (\"You can't access this file directly...\");

\$db_host = \"".$_SESSION['database_host']."\"; 
\$db_username = \"".$_SESSION['database_username']."\"; 
\$db_password = \"".$_SESSION['database_password']."\"; 
\$database = \"".$_SESSION['database_name']."\";
			")) echo error("Es ist ein Fehler beim schreiben von ../database.php aufgetreten<br>Installation fehlgeschlagen.");

			fclose($db_file);
			if (mysql_num_rows($settings)==1 && mysql_num_rows($userq)==1)
			{
				table("Installation fertiggestellt.");
				echo "MySQL Verbindung Hergestellt.";
				echo "
				<br>Schreibe auf root/database.php erfolgreich
				<br>Ihre Installation ist erfolgreich verlaufen.
				<br>Super Administrator: <b>".$userdata['username']."</b>
				<br>Passwort: <b>".$userdata['user_password']."</b>
				<br>
				<br>Bitte l&ouml;schen Sie das Installationsverzeichnis.
				<br>Klicken Sie <a href='../index.php'>hier</a> um jetzt zu starten.
				";
				closetable();
			}else
				echo error("Fehler ist aufgetreten beim Schreiben auf Database.php<br>Bitte neuinstallieren.", "?step=1");
		}
}

?>
	  </div>
	</div>
</div>
<div id="footer">
&copy; 2008 shoutcast admin panel | Wallcity-server | djcrackhome | <a href="http://sourceforge.net/projects/shoutcastadmin/" target="_blank">sourceforge</a></div>
</body>
</html>
