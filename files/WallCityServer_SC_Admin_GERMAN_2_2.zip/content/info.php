<?PHP


//
//	
//	WallCityServer
//	Shoutcast Admin Panel	
//	
//	Copyright 2008 
//
////////////////////////////////

table("Info");
?>
This is the basic layout of the page<br>
The page and title is determined by the ?page=page tag in the url<br>
<Br>
if no page is assigned it will run the default main.php page<br>
located in the pages directory
<?PHP
closetable();
?>