<?PHP


//
//	
//	WallCityServer
//	Shoutcast Admin Panel	
//	
//	Copyright 2008 
//
////////////////////////////////


if (!eregi("index.php", $_SERVER['PHP_SELF'])) {
    die ("You can't access this file directly...");
}

if (isset($_POST['login_submit']))
{
	if (isset($loggedin) && $loggedin==TRUE)
	{
		table("Login");
		echo "Du bist jetzt eingeloggt als $loginun<br>Du kannst jetzt deine Server konfigurieren<br> oder dein Konto &auml;ndern.";
		closetable();
	}else{
		table("Warning!");
		echo "Username ".$_POST['username']." wurde in unserer Datenbank nicht gefunden.<bR>Bitte &uuml;berpr&uuml;fe deine Eingabe.<br>Bitte beachte auch Gro&szlig;- und kleinschreibung.<br>Bitte gehe <a href=\"index.php?page=login\">zur&uuml;ck</a>";
		closetable();
	}
}else if (!isset($_GET['action'])){
		table("Login");
		?>
<form method="post" action="index.php?page=login">
<table width="223" height="87" border="0" cellpadding="0" cellspacing="0">
  <tr>
    <td width="104">Benutzername:</td>
    <td width="119"><input type="text" name="username"  size="15"></td>
  </tr>
  <tr>
    <td>Passwort:</td>
    <td><input type="password" name="user_password"  size="15"></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td><input type="submit" name="login_submit" value="Anmelden" style='background-image: url(images/bbg1.gif); color:#FFFFFF; font-weight: bold; font-family: trebuchet ms, helvetica, sans-serif; font-size:11px; border:0;'/>
</td>
  </tr>
</table>
</form>
<?PHP
		closetable();
}

if (isset($_GET['action']) && $_GET['action']=="logout")
{
		table("Abmelden");
		echo "Du bist Abgemeldet.";
		closetable();
}