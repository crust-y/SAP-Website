<?php 


//
//	
//	WallCityServer
//	Shoutcast Admin Panel	
//	
//	Copyright 2008 
//
////////////////////////////////

$server = $_GET['server'];
$port = $_GET['port'];
error_reporting(E_ALL);
ini_set('display_errors', '0');
$fp = @fsockopen($server, $port, $errno, $errstr, 30);
    
    if ($fp) {
        fputs($fp, "GET /7.html HTTP/1.0\r\nUser-Agent: XML Getter (Mozilla Compatible)\r\n\r\n");
        while(!feof($fp))
        $page .= fgets($fp, 1000);
        fclose($fp);
        $page = ereg_replace(".*<body>", "", $page);
        $page = ereg_replace("</body>.*", ",", $page);
        $numbers = explode(",", $page);
        $shoutcast_currentlisteners = $numbers[0];
        $connected = $numbers[1];
        if($connected == 1) {
            $radio_status = 1;
            $wordconnected = "yes";
        }
        else
            $wordconnected = "no";
        $shoutcast_peaklisteners = $numbers[2];
        $shoutcast_maxlisteners = $numbers[3];
        $shoutcast_reportedlisteners = $numbers[4];
        $shoutcast_bitrate = $numbers[5];
        $shoutcast_cursong = $numbers[6];
		$shoutcast_name = $numbers[1];
        $shoutcast_curbwidth = $shoutcast_bitrate * $shoutcast_currentlisteners;
        $shoutcast_peakbwidth = $shoutcast_bitrate * $shoutcast_peaklisteners;
    }
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html>
<head>
<meta http-equiv="content-type" content="text/html; charset=iso-8859-1" />
<title>Server Status</title>
<meta name="keywords" content="" />
<meta name="description" content="" />
<link rel="stylesheet" type="text/css" href="../system/default.css" />
<style type="text/css">
<!--
.style2 {
	font-size: 14px;
	color: #FFFFFF;
	font-weight: bold;
}
-->
</style>
</head>
<body marginheight="0" marginwidth="0" topmargin="0" leftmargin="0">
<table width="450" height="290" border="0" cellpadding="0" cellspacing="0">
  <tr>
    <td width="595" height="34" background="../images/bbg1.gif"><div align="center" class="style2">Shoutcast Server Status</div></td>
  </tr>
  <tr>
    <td height="235" bgcolor="#F8F8F8"><table width="452" height="76" border="0" cellpadding="0" cellspacing="0">
      <tr>
        <td width="14">&nbsp;</td>
        <td width="206" height="16">Server Status:</td>
        <td width="249"><?php

function Server($host, $port2, $wait_sec)
{
	$fp = fsockopen($host, $port2, &$errstr, &$errno, $wait_sec);

	if ($fp)
	{
		fputs($fp, "GET / HTTP/1.0\r\nUser-Agent:AmIoffOrOn\r\n\r\n");
	
		$ret = fgets($fp, 255);
	
		if (eregi("200", $ret))
		{
			return true;
		}
		else
		{
			return false;
		}

		fclose($fp);
	}
	else
	{
		return false;
	}
}

if (Server($server, $port, 1))
{
	echo "<img src='../images/status_on.gif' width='10' height='10'/> - Online";
}
else
{
	echo "<img src='../images/status_off.gif' width='10' height='10'/> - Offline";
}
?></td>
      </tr>
      <tr>
        <td height="19">&nbsp;</td>
        <td>IP und Port:</td>
        <td><?php echo $server;?> auf Port <?php echo $port;?></td>
      </tr>
      <tr>
        <td height="19">&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td height="19">&nbsp;</td>
        <td>Aktueller Titel:</td>
        <td><script type="text/javascript">
var memorywidth="230px"
var memoryheight="13px"
var memorybgcolor=""
var memorypadding="0px".
var borderCSS="border: 0px;"
var memoryspeed=2
var pauseit=0
var persistlastviewedmsg=1
var persistmsgbehavior="onload"
var memorycontent='<nobr><?php echo $shoutcast_cursong;?></nobr>'
var combinedcssTable="width:"+(parseInt(memorywidth)+6)+"px;background-color:"+memorybgcolor+";padding:"+memorypadding+";"+borderCSS+";"
var combinedcss="width:"+memorywidth+";height:"+memoryheight+";"

var divonclick=(persistlastviewedmsg && persistmsgbehavior=="onclick")? 'onClick="savelastmsg()" ' : ''
memoryspeed=(document.all)? memoryspeed : Math.max(1, memoryspeed-1) //slow speed down by 1 for NS
var copyspeed=memoryspeed
var pausespeed=(pauseit==0)? copyspeed: 0
var iedom=document.all||document.getElementById
if (iedom)
document.write('<span id="temp" style="visibility:hidden;position:absolute;top:-100px;left:-10000px">'+memorycontent+'</span>')
var actualwidth=''
var memoryscroller

if (window.addEventListener)
window.addEventListener("load", populatescroller, false)
else if (window.attachEvent)
window.attachEvent("onload", populatescroller)
else if (document.all || document.getElementById)
window.onload=populatescroller

function populatescroller(){
memoryscroller=document.getElementById? document.getElementById("memoryscroller") : document.all.memoryscroller
memoryscroller.style.left=parseInt(memorywidth)+8+"px"
if (persistlastviewedmsg && get_cookie("lastscrollerpos")!="")
revivelastmsg()
memoryscroller.innerHTML=memorycontent
actualwidth=document.all? temp.offsetWidth : document.getElementById("temp").offsetWidth
lefttime=setInterval("scrollmarquee()",20)
}

function get_cookie(Name) {
var search = Name + "="
var returnvalue = ""
if (document.cookie.length > 0) {
offset = document.cookie.indexOf(search)
if (offset != -1) {
offset += search.length
end = document.cookie.indexOf(";", offset)
if (end == -1)
end = document.cookie.length;
returnvalue=unescape(document.cookie.substring(offset, end))
}
}
return returnvalue;
}

function savelastmsg(){
document.cookie="lastscrollerpos="+memoryscroller.style.left
}

function revivelastmsg(){
lastscrollerpos=parseInt(get_cookie("lastscrollerpos"))
memoryscroller.style.left=parseInt(lastscrollerpos)+"px"
}

if (persistlastviewedmsg && persistmsgbehavior=="onload")
window.onunload=savelastmsg

function scrollmarquee(){
if (parseInt(memoryscroller.style.left)>(actualwidth*(-1)+8))
memoryscroller.style.left=parseInt(memoryscroller.style.left)-copyspeed+"px"
else
memoryscroller.style.left=parseInt(memorywidth)+8+"px"
}

if (iedom){
with (document){
document.write('<div style="position:relative;overflow:hidden;'+combinedcss+'" onMouseover="copyspeed=pausespeed" onMouseout="copyspeed=memoryspeed">')
write('<div id="memoryscroller" style="position:absolute;left:0px;top:0px;" '+divonclick+'></div>')
write('</div>')
document.write('')
}
}
</script></td>
      </tr>
      <tr>
        <td height="19">&nbsp;</td>
        <td>Server Bitrate:</td>
        <td><?php echo $shoutcast_bitrate;?> kb/s</td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td>Aktuelle H&ouml;rerzahl:</td>
        <td><?php echo $shoutcast_currentlisteners;?></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td>H&ouml;rerzahl Durchschnitt:</td>
        <td><?php echo $shoutcast_peaklisteners;?></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td>Maximale Zuh&ouml;rer:</td>
        <td><?php echo $shoutcast_maxlisteners;?></td>
      </tr>
    </table>
      <p>&nbsp;</p>
      <p> <center><a href="http://<?php echo $server;?>:<?php echo $port;?>/listen.pls" target="_self">
        <input type='submit' value='Zuh&ouml;ren' style='background-image: url(../images/bbg1.gif); color:#FFFFFF; font-weight: bold; font-family: trebuchet ms, helvetica, sans-serif; font-size:11px; border:0;'/></a>
        <input type='submit' onclick="window.close()" value='Schliessen' style='background-image: url(../images/bbg1.gif); color:#FFFFFF; font-weight: bold; font-family: trebuchet ms, helvetica, sans-serif; font-size:11px; border:0;'/></center>
      </p>    </td>
  </tr>
</table>
<p>&nbsp;</p>
<p>&nbsp;</p>
</body>
</html>