<?php



//
//	
//	WallCityServer
//	Shoutcast Admin Panel	
//	
//	Copyright 2008 
//
////////////////////////////////


$limit = $setting['display_limit'];
if (!isset($_POST['p']))
	$p = 0;
else
	$p = $_POST['p'] * $limit;

$l = $p + $limit;

$select = mysql_query("SELECT * FROM servers WHERE sitepublic='1' ORDER BY id ASC LIMIT $p,$limit");

table("Server Status");

		echo "";

		if (mysql_num_rows($select)==0)
			echo "Es sind keine &Ouml;ffentliche Server vorhanden.";
		else{
		echo "<table width='95%' border='0' cellpadding='0' cellspacing='0'>
                      <tr>
                        <td align='left'>Bitte w&auml;hlen Sie einen Server aus:</td>
                      </tr>
                      <tr>";
			while($data = mysql_fetch_array($select))
				echo "<tr>
                        <td width='95%' align='left'>
                        <a href='content/status-s.php?server=".$setting['host_add']."&port=".$data['portbase']."' onclick=\"NewWindow(this.href,'mywin','450','290','no','center');return false\" onfocus=\"this.blur()\">".$setting['host_add'].":".$data['portbase']."</a></td>
                      </tr>
                      <tr>
                        <td height='2px' align='left'>&nbsp;</td>
                      </tr>";
							echo "</tr>
                    </table>";
		}
		
		$page = mysql_num_rows(mysql_query("SELECT * FROM servers WHERE sitepublic='1'"));
		echo "\n<BR>
			<form method='POST' action='index.php?page=status'>
				<center>Seite:&nbsp;<select name='p'>";
		$i = 0;
		$page = mysql_num_rows(mysql_query("SELECT * FROM servers"));
		while($page > "0")
		{
				echo "
			<option "; if (($p / $limit) == $i){echo "selected ";} echo ">$i</option>
				";
			$i++;
			$page -= $limit;
		}
		echo "
				</select> 
				  <input type='submit' value='&Uuml;bernehmen' style='background-image: url(images/bbg1.gif); color:#FFFFFF; font-weight: bold; font-family: trebuchet ms, helvetica, sans-serif; font-size:11px; border:0;'/>
				</center>
		";
closetable();
