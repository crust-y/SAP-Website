<?PHP


//
//	
//	WallCityServer
//	Shoutcast Admin Panel	
//	
//	Copyright 2008 
//
////////////////////////////////


if (file_exists("install/install.php"))
{
	table("Sicherheitsl&uuml;cke gefunden!");
	echo "Bitte l&ouml;sche das Installationsverzeichnis<br> und alle dort enthaltenden Dateien";
	closetable();
}
$newsq = mysql_query("SELECT * FROM headlines order by id DESC LIMIT 3");

if (mysql_num_rows($newsq)==0)
{
	table("Nachrichten");
	echo "Es sind keine Nachrichten vorhanden.";
	closetable();
}

while($data = mysql_fetch_array($newsq))
{
	table($data['title']);
	echo $data['text'];
	closetable();
}

?>