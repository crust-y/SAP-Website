<?php


//
//	
//	WallCityServer
//	Shoutcast Admin Panel	
//	
//	Copyright 2008 
//
////////////////////////////////

if (!eregi("index.php", $_SERVER['PHP_SELF'])) {
    die ("You can't access this file directly...");
}

if (!isset($user_level))
{
	table("Access Denied");
	echo "Du haste kein Zugriff auf die Datei";
	closetable();
	exit;
}

if (!isset($_POST['submit']))
{

		$userq = mysql_query("SELECT * FROM users WHERE md5_hash='$hash'");
		foreach(mysql_fetch_array($userq) as $key => $pref)
		{
			if (!is_numeric($key))
			{
				if ($pref != "")
					$userdata[$key] = $pref;
				else
					$userdata[$key] = "none";

			}
		}
	
		echo "
				<form action='index.php?page=account' method='POST'>
				<table border='0' align='center' width='100%'>
					<tr>
						<td>						  <div align='center'><b><font color='#85AC1E' size='3' face='trebuchet ms, helvetica, sans-serif'>Einstellungen</font></b></div></td>
				      <td width='45%'>					      <div align='center'><b><font color='#85AC1E' size='3' face='trebuchet ms, helvetica, sans-serif'>Eigenschaften</font></b></div></td>
				  </tr>
					<tr>
						<td align='center'><b>Benutzername</b><bR><font size=2><i>Der Benutzer des Kontos</i></font></td>
						<td width='55%' align='center'>".$userdata['username']."</td>
					</tr>
					<tr>
						<td align='center'><b>Passwort</b><bR><font size=2><i>Das Kennwort zum Benutzer</i></font></td>
						<td width='55%' align='center'><input type='password' name='u_user_password' value='".$userdata['user_password']."' maxlength='50'></td>
					</tr>
					<tr>
						<td align='center'><b>Wiederholung des Passwort</b><bR><font size=2><i>Bei &Auml;nderung bitte nochmals eingeben.</i></font></td>
						<td width='55%' align='center'><input type='password' name='u_cuser_password' maxlength='50'></td>
					</tr>
					<tr>
						<td align='center'><b>Benutzer Status</b><bR><font size=2><i>Der Zugriffsstatus des Benutzer</i></font></td>
						<td width='55%' align='center'>".$userdata['user_level']."</td>
					</tr>
					<tr>
						<td align='center'><b>Telefonnummer</b><bR><font size=2><i>Die Telefonnummer des Benutzers</i></font></td>
						<td width='55%' align='center'><input type='text' name='u_contact_number' value='".$userdata['contact_number']."' maxlength='10'></td>
					</tr>
					<tr>
						<td align='center'><b>Handynummer</b><bR><font size=2><i>Die Handynummer des Benutzers</i></font></td>
						<td width='55%' align='center'><input type='text' name='u_mobile_number' value='".$userdata['mobile_number']."' maxlength='50'></td>
					</tr>
					<tr>
						<td align='center'><b>E-Mail</b><bR><font size=2><i>Die E-Mail Adresse des Benutzers</i></font></td>
						<td width='55%' align='center'><input type='text' name='u_user_email' value='".$userdata['user_email']."' maxlength='50'></td>
					</tr>
					<tr>
						<td align='center'><b>Vorname</b><bR><font size=2><i>Der Vorname des Benutzer</i></font></td>
						<td width='55%' align='center'><input type='text' name='u_name' value='".$userdata['name']."' maxlength='50'></td>
					</tr>
					<tr>
						<td align='center'><b>Nachname</b><bR><font size=2><i>Der Nachname des Benutzer</i></font></td>
						<td width='55%' align='center'><input type='text' name='u_surname' value='".$userdata['surname']."' maxlength='50'></td>
					</tr>
					<tr>
						<td align='center'><b>Alter</b><bR><font size=2><i>Das Alter des Benutzer</i></font></td>
						<td width='55%' align='center'><input type='text' name='u_age' value='".$userdata['age']."' maxlength='50'></td>
					</tr>
					<tr>
						<td align='center'><b>Konto Kommentar</b><bR><font size=2><i>Dies kann nur der Administrator sehen.</i></font></td>
						<td width='55%' align='center'>".nl2br($userdata['account_notes'])."</td>
					</tr>
				</table>
				<center><input type='submit' name='submit' id='button' value='Aktualisieren' style='background-image: url(images/bbg1.gif); color:#FFFFFF; font-weight: bold; font-family: trebuchet ms, helvetica, sans-serif; font-size:11px; border:0;'/></center>
		";
}else{

	$fields = "";
	$values = "";

	if (strtolower($_POST['u_user_password'])!=strtolower($loginpw) && strtolower($_POST['u_user_password']) == strtolower($_POST['u_cuser_password']))
	{
		$loginpw = $_POST['u_user_password'];
		$_POST['u_md5_hash'] = md5(strtolower($loginun.$loginpw));
	}else if (strtolower($_POST['u_user_password'])!=strtolower($loginpw) && strtolower($_POST['u_user_password']) != strtolower($_POST['u_cuser_password'])){
		table("Warning!");
		echo "Bitte �berpr�fe dein Passwort<br>Klicke <a href='?page=account'>hier</a> um zur�ck zu kommen.";
		closetable();
		exit;
	}

	

	foreach($_POST as $key => $value)
	{
		if ($key != "submit" && $value!="" && $key!="u_cuser_password")
		{
			$key = explode("u_", $key);
			$key = $key['1'];
			$values .= $key."='".$value."', ";
			$lastvalue = "'".$value."'";
		}
		if ($key == "user_password")
			$newpass = $value;

	}
	$values = explode($lastvalue,$values);
	$values = $values['0'].$lastvalue;

	if ( mysql_query("UPDATE users SET ".$values." WHERE id='".$userdata['id']."'") )
	{
		table("Account Details - update");
		echo "Deine Konto Daten wurden erfolgreich ge�ndert<br>Klicke <a href='?page=main'>hier</a> um zur�ck zu kommen.";
		closetable();
		$_SESSION['user_password'] = $newpass;
	}else{
		table("Warnung");
		echo "Es ist ein Fehler aufgetaucht.<br>MYSQL ERROR: ".mysql_error();
		closetable();
	}
		
}