<?php


//
//	
//	WallCityServer
//	Shoutcast Admin Panel	
//	
//	Copyright 2008 
//
////////////////////////////////


if (!eregi("index.php", $_SERVER['PHP_SELF']))
    die ("You can't access this file directly...");

$select = mysql_query("SELECT * FROM servers WHERE id='".$_GET['id']."'");
$server = mysql_fetch_array($select);
if (mysql_num_rows($select)==0 && $server['owner']!=$loginun && ( $userdata['user_level']!="Super Administrator" || $userdata['user_level']!="Administrator") )
{
		table("Warning !");
		echo "Der Server existiert nicht<br>oder du hast kein Zugriff darauf<br>Klicke <a href='?page=servers'>hier</a> um zur&uuml;ck zu kommen.";
		closetable();
		exit;
}

	$data = explode("\n", $server['suspended']);
	$reason = explode("reason:",$data['0']);
	$timestamp = explode("timestamp: ", $data['1']);
	$mins = round( ( (86400 * $setting["suspended_days"]) - (time() - $timestamp['1'])) / 60);
	$hours = round($mins / 60);
	if ($mins <= 0)	{
		if(mysql_query("UPDATE servers SET suspended='', abuse='0' WHERE id='".$server['id']."'"))
		{
			table("Server wurde gel&ouml;scht");
			echo "Der Server wurde gel&ouml;scht.<br>Bitte in der Zukunft an die Regeln halten<br>Klicke <a href='?page=servers'>hier</a> um zur&uuml;ck zu kommen.";
			closetable();
		}else{
			table("Warning !");
			echo "Ein Fehler ist aufgetreten.<br>MYSQL ERROR:<br><font color='red'>".mysql_error()."</font>";
		}
	}else{
		table("Servers wurde gel&ouml;scht");
		echo "Dein Server wurde f&uuml;r ".$setting['suspended_days']." Tage suspendiert.<br>Begr&uuml;ndung: <font color='red'>".$reason['1']."</font><br>Stunden bis zur Freischaltung: <font color='red'>$hours</font><br>Minuten bis zur Freischaltung: <font color='red'>$mins</font>";
		echo "<br>Bitte komme in $mins Minuten wieder um dein Status zu checken.<br><br>Klicke <a href='?page=servers'>hier</a> um zur&uuml;ck zu kommen.";
		closetable();
	}