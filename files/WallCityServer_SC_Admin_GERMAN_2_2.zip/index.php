<?PHP
//
//	
//	WallCityServer
//	Shoutcast Admin Panel	
//	
//	Copyright 2008 
//
////////////////////////////////

session_start();
$version = "2.2";
if (!include("database.php"))
	die("database.php konnte nicht gefunden werden.");
if ($db_host == "" || !isset($db_host))
	header("Location: ./install/install.php");
$connection = mysql_connect($db_host, $db_username, $db_password) or die ('MySQL Server nicht erreichbar. Bitte Administrator kontaktieren.');
$db = mysql_select_db($database) or die ("Datenbank nicht gefunden.<br>Bitte neu installieren.");
if (!isset($_GET['page']))
{	
	$page = "main";
}
else
{	
	$page = $_GET['page'];	
}
$page = ereg_replace("/","", $page);
$settingsq = mysql_query("SELECT * FROM settings WHERE id='0'") or die("Datenbank Fehler<br>Bitte neu Installieren.");
foreach(mysql_fetch_array($settingsq) as $key => $pref)
{
	if (!is_numeric($key))
	{
		$setting[$key] = stripslashes($pref);
	}
}
$loggedin = FALSE;
if (isset($_SESSION['username']) && isset($_SESSION['user_password']) || isset($_POST['username']) && isset($_POST['user_password']))
{
	if (isset($_POST['login_submit']))
	{
		$loginun = $_POST['username'];
		$loginpw = $_POST['user_password'];
	}else{
		$loginun = $_SESSION['username'];
		$loginpw = $_SESSION['user_password'];
	}
	$hash = md5($loginun.$loginpw);
	$selectuser = mysql_query("SELECT * FROM users WHERE md5_hash='$hash'");
	if (mysql_num_rows($selectuser)==1)
	{
		$_SESSION['username'] = $loginun;
		$_SESSION['user_password'] = $loginpw;
		$userdata = mysql_fetch_array($selectuser);
		$loginun = $userdata['username'];
		$user_level = $userdata['user_level'];
		$user_id = $userdata['id'];
		$loggedin = TRUE;
	}else{
		session_destroy();
		$loggedin = FALSE;
	}
}
$dir = ".\\temp\\";
$files = glob($dir."*");
if ($files != "")
{
	foreach (glob($dir."*") as $filename)
	{
		$tmptime = explode("_",$filename);
		$tmptime = $tmptime['1'];
		$tmptime = ereg_replace(".ini","",$tmptime);
		$tmp = time() - 100;
		if ($tmp > $tmptime)
		{
			if (!unlink($filename) && isset($user_level))
				echo "Datei konnte nicht gel&ouml;scht werden ".$filename;
		}
	}
}
function table($title,$width="99%")
{
	if (isset($_GET['page']))
		$page = $_GET['page'];
	else
		$page = "main";

	if ($page=="admin" && strstr($title,"Administration"))
	{
		$title = ereg_replace("Administration", "<a href='index.php?page=admin'>Administration</a>", $title);
		$title = ereg_replace("Settings", "<a href='index.php?page=admin&m=settings'>Settings</a>", $title);
		$title = ereg_replace("Servers", "<a href='index.php?page=admin&m=servers'>Servers</a>", $title);
		$title = ereg_replace("Servers", "<a href='index.php?page=status'>Status</a>", $title);
		$title = ereg_replace("Users", "<a href='index.php?page=admin&m=users'>Users</a>", $title);
		$title = ereg_replace("Headlines", "<a href='index.php?page=admin&m=headlines'>Headlines</a>", $title);
		$title = ereg_replace("Permissions", "<a href='index.php?page=admin&m=permissions'>Permissions</a>", $title);

	}else{
		$title = ereg_replace("Servers", "<a href='index.php?page=servers'>Servers</a>", $title);
		$title = ereg_replace("Accounts", "<a href='index.php?page=accounts'>Accounts</a>", $title);

	}

?>
				<table border="0" width="99%">
					<tr>
						<td align="left" valign="top">
						 <font color="#85AC1E"><b><u><?=$title?></u></b></font>
						</td>
					</tr>
					<tr>
						<td style="padding: 18px;">
<?PHP
}

function closetable()
{
?>
						</td>
					</tr>
				</table>
<?PHP
}
if (isset($_GET['action']) && $_GET['action'] == "logout")
{
	$loggedin = FALSE;
	session_destroy();
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html>
<head>
<meta http-equiv="content-type" content="text/html; charset=iso-8859-1" />
<title><?=$setting['page_title']?></title>
<meta name="keywords" content="" />
<meta name="description" content="" />
<link rel="stylesheet" type="text/css" href="system/default.css" />
<script language="javascript" type="text/javascript">
var win=null;
function NewWindow(mypage,myname,w,h,scroll,pos){
if(pos=="random"){LeftPosition=(screen.width)?Math.floor(Math.random()*(screen.width-w)):100;TopPosition=(screen.height)?Math.floor(Math.random()*((screen.height-h)-75)):100;}
if(pos=="center"){LeftPosition=(screen.width)?(screen.width-w)/2:100;TopPosition=(screen.height)?(screen.height-h)/2:100;}
else if((pos!="center" && pos!="random") || pos==null){LeftPosition=0;TopPosition=20}
settings='width='+w+',height='+h+',top='+TopPosition+',left='+LeftPosition+',scrollbars='+scroll+',location=no,directories=no,status=no,menubar=no,toolbar=no,resizable=no';
win=window.open(mypage,myname,settings);}
</script>
</head>
<body>
<div id="header">
	<div id="header_inner">
		<h1><span>shoutcast.</span>admin panel</h1>
		</div>
</div>
<div id="main">
	<div id="lcol">
		<div id="menu">
			<ul>
              <li><a href="index.php">Home</a></li>
              <li><a href="index.php?page=contact">Kontakt</a></li>
              <li><a href="index.php?page=status">server status</a></li>
              <li><?php if ($loggedin == TRUE){
						echo "
				<a href=\"index.php?page=servers\">Server</a>
							";
			
							$servers = mysql_query("SELECT * FROM servers WHERE owner='$loginun'");
							$i = 0;
							echo "";
							while($data = mysql_fetch_array($servers))
							{
								$i++;
							}
					}else{
						echo "<a href=\"index.php?page=login\">login</a>";}?></li>
              <li><?php if ($loggedin == TRUE)
					echo "
				<a href=\"index.php?page=account\">Mein Konto</a>";?></li>
                <?PHP
			if ($loggedin == TRUE)
			{
				if ($user_level == "Administrator" || $user_level == "Super Administrator")
				{
					?>
              <li><a href="index.php?page=admin">Admin</a></li>
              <?PHP
				}
			}

			if ($loggedin == TRUE)
			{?>
            <li><a href="index.php?page=login&action=logout">Abmelden</a></li>
            	<?PHP }
			?>             
      </ul>			</ul>
	  </div>
		<div id="menu_end"></div>
		<div id="lcontent">
			<h3 class="first">panel.<span>Status</span></h3>
			<ul class="divided">
				<li>Deine IP:&nbsp;<?php echo $_SERVER['REMOTE_ADDR']; ?></li>
				<li>Server IP:&nbsp;<?php echo $_SERVER['SERVER_ADDR']; ?></li>
                <li>Panel Version:&nbsp;2.2</li>
			</ul>
	  </div>
	</div>
	<div id="rcol">
		<div id="rcontent">
 <?PHP if(!include("content/".$page.".php"))
			{
				echo "Server Fehler"; 
			}
		?>

	  </div>
	</div>
</div>
<div id="footer">
&copy; 2008 shoutcast admin panel | Wallcity-server | djcrackhome | <a href="http://shoutcastadmin.sourceforge.net/" target="_blank">sourceforge</a></div>
</body>
</html>
