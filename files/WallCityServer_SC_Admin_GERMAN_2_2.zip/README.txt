==============================================
APP NAME---> WallCity-Server Shoutcast Admin Panel
VERSION----> 2.2
CREATED BY-> djcrackhome
==============================================


//�NDERUNGEN VON 2.1:
PATCH F�R DAS SICHERHEITSPROBLEM WAS ES IN 2.1 GAB
UND UPDATE DER SHOUTCAST VERSIONEN

//EINE KLEINERE INFO NOCH IN DER INSTALLATION F�R DIE CHMOD




INDEX:

-> Wichtiger Hinweis
-> Anforderungen
-> Installation
-> History
-> Kontakt


==============================================
WICHTIGER HINWEIS:
==============================================
Bei Erstellung eines Shoutcast Servers bitte 
die Portrange von 8000-8200 nicht Unter/�ber-
schreiten. Manche Firewall's bzw Server lassen
sonst den Server nicht starten.

Bei Linux kann es passieren dass alle die Files
unterverzeichnisse und auch deren Dateien mit
Lese und Schreibrechte abge�ndert m�ssen.

==============================================
ANFORDERUNGEN:
===============================================
WallCity-Server Shoutcast Admin Panel hat einige
Anforderungen bevor es richtig auf Ihrem Server
laufen kann. Bitte versichern Sie sich dass diese
Anforderungen erf�llt sind bevor Sie den Admin-
Panel installieren.

  1.  Unix/Windows

Der Shoutcast Admin Panel unterst�tzt Windows und
Unix/Linux basierende Betriebssysteme. Es 
funktioniert auch auf anderen Systemen die eine
Kompatibele Shell wie der von Unix/Linux aufweist.
  
  2.  PHP

PHP ist die wichtigste Anforderung diese muss bei
bei allen Systemen vorhanden sein.

  3.  Shell Access

Wenn Sie versuchen Shoutcast Admin Panel auf einem 
WebHosting Account zu installieren, versichern Sie
sich dass Sie Shell Zugriff bzw. Admin Rechte haben.
Viele Hoster bieten Shell Zugriff gegen einen geringen
Aufpreis an.

  4.  Access to Ports

Shoutcast Admin Panel unterst�tzt nicht APF
(Advanced Policy Firewall). Falls Sie diese
haben, bitte versichern Sie sich dass sie die
Ports die Sie f�r den Server haben wollen offen
sind. Auch unter Windows IIS m�ssen Sie sich
versichern dass sie genug Ports der shoutcast.exe
zugeteilt haben.


===============================================
INSTALLATION:
===============================================
Bitte alle Dateien die in diesem Verzeichnis
vorhanden sind auf ihren Host uploaden.

Bitte versichern Sie sich dass die Datei
database.php Schreib-/Leserechte besitzt.

-- WICHTIG:
Auch 	files/linux/sc_serv
und	files/windows/sc_serv.exe 
m�ssen beide auch CHMOD 777 haben.

Wenn Sie alle Dateien hochgeladen haben einfach
die Datei index.php �ber Ihren Browser anfragen.
Danach den Installationsschritten folgen.


===============================================
HISTORY:
===============================================
ACHTUNG:
Alle zwischen Versionen die hier nicht gelistet sind, sind alles
Experimentelle Version, meist nicht richtig funktionsf�hig,
d.h. wenn Sie eine Version besitzen, die hier nicht gelistet ist, 
besuchen Sie bitte:
http://sourceforge.net/projects/shoutcastadmin/
um eine Offizielle Version zu erhalten.


Version 2.5 (In work Release: Aug/Sep08)
~~~~~~~~~~~~
Multilanguage Interface ENG+DE+ESP
Server Status erneuert
Anfragen importiert


Version 2.0/2.1
~~~~~~~~~~~~
Neues Design
Style Anzeige Probleme behoben
Shoutcast Linux Update
Shoutcast Windows Update
Server Status erneuert
Anfragen importiert
Installationsdatei erweitert


Version 1.7
~~~~~~~~~~~~
Server Status von Server P-Server
Feinheiten behoben


Version 1.4
~~~~~~~~~~~~
Wichtiger Linux Update behoben


Version 1.2
~~~~~~~~~~~~
Sicherheitsupdate f�r alle Ordner und Dateien
Kompatibilit�t f�r Linux erweitern
Style Anzeige Probleme behoben
Installationsdatei einfacher gestaltet


Version 1.1
~~~~~~~~~~~~
Geringe Ver�nderungen an der Install.php und
an den MySQL Eintr�gen


Version 1.0
~~~~~~~~~~~~
Shoutcast Admin Panel mit Design


===============================================
KONTAKT:
===============================================
Bitte unser Kontaktformular auf:
http://shoutcast-admin-panel.iblogger.org/
benutzen

===============================================
DANKE:
===============================================
Sourceforge f�r das Hosten
DJ-Marquez f�r die Promo
Marcel Hoffmann als Linux Server Tester
Christian Wegner als Social Helper
Und nat�rlich an Shoutcast und WinAmp und alle
anderen f�r die Motivation und auch an alle User
f�r eure Feedbacks und auch eure guten Problem-
beschreibungen.

DANKE AN EUCH ALLE
mfg djcrackhome