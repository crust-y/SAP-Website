<?PHP


//
//	
//	WallCityServer
//	Shoutcast Admin Panel	
//	
//	Copyright 2008 
//
////////////////////////////////


if (!eregi("index.php", $_SERVER['PHP_SELF'])) {
    die ("You can't access this file directly...");
}

if (isset($_POST['login_submit']))
{
	if (isset($loggedin) && $loggedin==TRUE)
	{
		table("Login");
		echo "Du bist jetzt eingeloggt als $loginun<br>Du kannst jetzt deine Server konfigurieren<br> oder dein Konto &auml;ndern.";
		closetable();
	}else{
		table("Warning!");
		echo "Username ".$_POST['username']." wurde in unserer Datenbank nicht gefunden.<bR>Bitte &uuml;berpr&uuml;fe deine Eingabe.<br>Bitte beachte auch Gro&szlig;- und kleinschreibung.<br>Bitte gehe <a href=\"index.php?page=login\">zur&uuml;ck</a>";
		closetable();
	}
}else if (!isset($_GET['action'])){
		table("Login");
		?>
		<form method="post" action="index.php?page=login">
			Benutzername: 	<input type="text" name="username"  size="15"><Br>
			Passwort:  	<input type="password" name="user_password"  size="15"><Br>
			<br><center><input type="submit" name="login_submit" value="Anmelden" style="color: #FFFFFF; border: 1 solid #000000;  background-color: #5D9E9B; font-weight:bold;">
		</form>
		<?PHP
		closetable();
}

if (isset($_GET['action']) && $_GET['action']=="logout")
{
		table("Abmelden");
		echo "Du bist Abgemeldet.";
		closetable();
}