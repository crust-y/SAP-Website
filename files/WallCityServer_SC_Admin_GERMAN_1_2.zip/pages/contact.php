<?php


//
//	
//	WallCityServer
//	Shoutcast Admin Panel	
//	
//	Copyright 2008 
//
////////////////////////////////

if (!eregi("index.php", $_SERVER['PHP_SELF'])) {
    die ("You can't access this file directly...");
}

//if (!isset($user_level))
//{
//	table("Access Denied");
//	echo "You do not have permissions to access this file";
//	closetable();
//	exit;
//}

if (!isset($_POST['submit']))
{
	if (!isset($_GET['s']))
		$s = "General";
	else
		$s = $_GET['s'];

	if (isset($_GET['s']) && $_GET['s'] == "Cancel" && isset($_GET['id']))
		$text = "Bitte um k&uuml;ndigung meines Server mit der ID ".$_GET['id'];
	else
		$text = "";

	table("Administrator kontaktieren");
	echo "
		<form method='POST' action='?page=contact'>";
	if (!isset($user_level))
	{
		echo "
		E-Mail Addresse: <input type='text' name='email'>
		";
	}else{
		echo "
		Benuztername: $loginun
		";
	}
	echo "
		<Br>Begr&uuml;ndung: <select name='reason'>
					<option"; if ($s=='General')echo " Selected"; echo ">Allgemein</option>
					<option"; if ($s=='Feedback')echo " Selected"; echo ">Feedback</option>
					<option"; if ($s=='Complaint')echo " Selected"; echo ">Beschwerde</option>
					<option"; if ($s=='Support')echo " Selected"; echo ">Hilfe</option>
					<option"; if ($s=='Cancel')echo " Selected"; echo ">K&uuml;ndigung</option>
				</select>
		<br>Mitteilung:<br>
		<textarea cols=55 rows='8' name='message'>$text</textarea>
		<center><input type='submit' name='submit' value='&Uuml;bernehmen'></centeR>
	";
	closetable();
}else{
	if (isset($_POST['email']))
	{
		if (!strstr($_POST['email'],"@"))
		{
			table("Warnung");
			echo("Bitte geben Sie eine g&uuml;ltige E-Mail Adresse ein.<br>Klicke <a href='?page=contact'>hier</a> um zur&uuml;ck zu kommen");
			closetable();
			exit;
		}
		//$_POST['message'] = "Email Address: ".$_POST['email']."<br><br>".$_POST['message'];
		$loginun = $_POST['email'];
	}
	if (mysql_query("INSERT INTO notices (username,reason,message,ip) VALUES('".$loginun."','".$_POST['reason']."','".$_POST['message']."','".$_SERVER['REMOTE_ADDR']."')"))
	{
		table("Nachticht gesendet");
		echo "Deine Nachricht wurde erfolgreich an den Admin versendet.";
		closetable();
	}else{
		table("Warnung");
		echo "Es ist ein Fehler aufgetreten.<br>MYSQL ERROR:".mysql_error();
		closetable();
	}
	$loginun = FALSE;
}