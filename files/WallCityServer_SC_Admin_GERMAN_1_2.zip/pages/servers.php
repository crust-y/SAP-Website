<?PHP


//
//	
//	WallCityServer
//	Shoutcast Admin Panel	
//	
//	Copyright 2008 
//
////////////////////////////////


if (!eregi("index.php", $_SERVER['PHP_SELF'])) {
    die ("You can't access this file directly...");
}
if (!isset($user_level))
{
	table("Access Denied");
	echo "You must be logged in to access this file";
	closetable();
	exit;
}
	if (!isset($_GET['manage']) && !isset($_GET['view']))
	{
		table("Server - &Uuml;berblick");

		echo "
				<table border='0' align='center' width='530'>
					<tr>
						<td width=150>
						<p align='left'><b><font size=4>Inhaber</font></b></td>
						<td align=center width='80'>
						<p><b><font size=4>Port</font></b></td>
						<td width='300' align=center>
						<p align='center'><b><font size=4>Funktionen</font></b></td>
					</tr>
		";

		$limit = $setting['display_limit'];
		if (!isset($_POST['p']))
			$p = 0;
		else
			$p = $_POST['p'] * $limit;
		
			$l = $p + $limit;

		$listq = mysql_query("SELECT * FROM servers WHERE owner='$loginun' order by id ASC limit $p,$limit");
		while($data = mysql_fetch_array($listq))
		{
			if ($data['suspended']=="")
			{
				echo "

					<tr>
						<td align='left'>".$data['owner']."</td>
						<td align='center'>".$data['portbase']."</td>
						<td align='center'>[ <a href='index.php?page=servers&view=".$data['id']."'>Anzeigen</a> ] - [ <a href='index.php?page=servers&manage=".$data['id']."'>Einstellen</a> ] <br> [ <a href='index.php?page=servers&view=".$data['id']."&action=start'>Starten</a> ] - [ <a href='index.php?page=servers&view=".$data['id']."&action=stop'>Beenden</a> ]</td>
					</tr>


				";
			}else{
				echo "

					<tr>
						<td align='left'>".$data['owner']."</td>
						<td align='center'>".$data['portbase']."</td>
						<td align='center'><font color='red'>Suspendiert</font> - <a href='?page=reason&id=".$data['id']."'>Begr&uuml;ndung</a></td>
					</tr>


				";
			}
		}
		if (mysql_num_rows($listq)==0)
		{
			echo "

					<tr>
						<td align='center' colspan='3'>Es sind keine Server auf dich registriert.</td>
					</tr>


			";
		}
		echo "
				</table>

		";
		$page = mysql_num_rows(mysql_query("SELECT * FROM servers"));
		echo "
			<form method='POST' action='index.php?page=servers'>
				<center>Seite:&nbsp;<select name='p'>";
		$i = 0;
		while($page > "0")
		{


				echo "
			<option "; if (($p / $limit) == $i){echo "selected ";} echo ">$i</option>
				";
			$i++;
			$page -= $limit;
		}
		echo "
				</select><input type='submit' value='Anzeigen'>
				<br><br><a href='".$setting['newlink']."'>Einen Server beantragen</a>
				</center>
		";
		closetable();
	}



	if (isset($_GET['view']))
	{
		$serverq = mysql_query("SELECT * FROM servers WHERE id='".$_GET['view']."'");
		$serverdata = mysql_fetch_array($serverq);
		if ($serverdata['suspended']!="")
		{
			table("Achtung !");
			echo "Der Server der angefragt wurde ist suspendiert.<br>Klicke <a href='?page=reason&id=".$_GET['view']."'>hier</a> um Details anzuzeigen";
			closetable();
			exit;
		}
		if (mysql_num_rows($serverq)==0 || $serverdata['owner']!=$loginun && ($userdata['user_level']!="Super Administrator"))
		{
			table("Achtung");
			echo "Server existiert nicht, oder ist nicht auf dich registriert.<br>Bitte gehe <a href='index.php?page=servers'>zur&uuml;ck</a>";
			closetable();
			exit;
		}
		if (!isset($_GET['action']))
		{

			table("Server - &Uuml;berblick");
			echo "<center>";

//start stats script

    $scip = $setting['host_add'];
    $scpt = $serverdata['portbase'];


  //_____________________________________________________________________________
  //=============================================================================
  //--[ do not edit below this line! but i have commented to explain what we did

    function quiry_scserv($scservurl, $scservprt) {
      $scservfip = gethostbyname($scservurl);
      $getscserv = @fsockopen($scservfip, $scservprt, &$errno, &$errstr, 1) or $php_err .= "server doa";
      $servquiry = "";
      if (!$getscserv) { return "offline"; }
      else {
        fputs($getscserv, "GET /7.html HTTP/1.1\r\nAccept: */*\r\nAccept-Encoding: gzip, deflate\r\nUser-Agent: RaveTrax SC_Serv Stats Getter v1.1 (Mozilla Compatible)\r\nConnection: Keep-Alive\r\n\r\n");
        while (!feof($getscserv)) { $servquiry .= fread($getscserv, 500); }
        fclose($getscserv);
        $quiryb = substr($servquiry, strpos($servquiry, "\r\n\r\n") + 4);
        return $quiryb;
      }
    }

      echo "<!-- "; $scserv_quiry = quiry_scserv($scip, $scpt); echo " -->"; 
      if ($scserv_quiry == "offline") { 
		$link = "[ <a href='?page=servers&view=".$_GET['view']."&action=start'>Starten</a> ]";
        $csc_status = "Offline"; 
        ?>

    Server Is Currently:       <? echo $csc_status; ?> 

	<?
        //--[ time to exit... see ya!
              }
      //--[ retuned quiry is online! let continue here
      else {
        //--[ lets explode the quiry data into an array...
        $quirydat = explode(",", $scserv_quiry);
        //--[ ok, now lets double check to see if server is actually broadcasting
        if ($quirydat[1] == "1") {
          //--[ double check says server is online, lets continue here.
          //--[ what verbage should be used?
          $csc_status = "Dein Server ist Online<br>";
          //--[ now lets turn the pretty array into some variables for output.
          $listener_c = $quirydat[0]; $listener_p = $quirydat[2];
          $listener_m = $quirydat[3]; $listener_r = $quirydat[4];
          $sc_bitrate = $quirydat[5]; $sc_playing = $quirydat[6];
          //--[ let get the online template and show user the stats what we found.
          ?>

    <b>Aktueller Titel:    <? echo $sc_playing; ?></b><br>
    ------------------------------------------ <br>
    Aktuelle Zuh&ouml;rer: <? echo $listener_c; ?> <br>
    Zuh&ouml;rer Record:     <? echo $listener_p; ?> <br>
    Gesamte Zuh&ouml;rer: <? echo $listener_r; ?> <br>
    Max Zuh&ouml;rer:     <? echo $listener_m; ?> <br>
    Bitrate:           <? echo $sc_bitrate; ?> <br>

		<?
		$link = "[ <a href='?page=servers&view=".$_GET['view']."&action=stop'>Stoppen</a> ]";

        }
        else { 
          //--[ double check says server is offline, lets bail!
          //--[ what verbage should be used?
          $csc_status = "Dein Server ist Online, aber kein DJ verbunden<br>"; 
		$link = "[ <a href='?page=servers&view=".$_GET['view']."&action=stop'>Server stoppen</a> ]";
          //--[ let get the offline template and show user what we found.
         

      echo $csc_status; 

          //--[ time to exit... see ya!
          
        }

      }
    

  //_____________________________________________________________________________
  //=============================================================================
  //--[ ok stop reading now, time to say goodbye! developed by rava@ravetrax.com


// end stats script	
//


			echo "<br>
			".$link." - [ <a href='?page=servers&manage=".$_GET['view']."'>Einstellungen</a> ]";
			closetable();
		}

		if (isset($_GET['action']) && $_GET['action']=="start")
		{
			if ($user_level == "Super Administrator")
				$radioport = mysql_query("SELECT portbase FROM servers WHERE id='".$_GET['view']."'");
			else
				$radioport = mysql_query("SELECT portbase FROM servers WHERE id='".$_GET['view']."' AND owner='".$loginun."'");

			if (mysql_num_rows($radioport)==0)
			{
				table("Achtung");
				echo "Server existiert nicht<br>Bitte gehe <a href='index.php?page=servers'>zur&uuml;ck</a>";
				closetable();
				exit;
			}
			$connection = @fsockopen($setting['host_add'], mysql_result($radioport,0), &$errno, &$errstr, 1)  or $php_err .= "server doa";
			if ($connection)
			{
				table("Achtung");
				echo "Server ist Online<br>Bitte gehe <a href='index.php?page=servers'>zur&uuml;ck</a>";
				closetable();
				exit;
			}

			table("Server - &Uuml;berblick");
			echo "<center>";




				$serverdata = mysql_query("SELECT * FROM servers WHERE id='".$_GET['view']."' AND portbase='".mysql_result($radioport,0)."'");
			$ini_content = "";
			foreach(mysql_fetch_array($serverdata) as $field => $value)
			{
				if (!is_numeric($field) && $field != "id" && $value !="" && $field != "owner" && $field!="pid" && $field!="sitepublic" && $field!="suspended" && $field!="abuse")
				{
					$ini_content .= $field."=".$value."
";
				}
			}
			if ($setting['os'] == 'windows')
			{
				$filename = $setting['dir_to_cpanel']."temp\\".mysql_result($radioport,0)."_".time().".ini";
			}
			if ($setting['os'] == 'linux')
			{
				$filename = "temp/".mysql_result($radioport,0)."_".time().".conf";
			}

			if (!$handle = fopen($filename, 'a')) {
			echo "Cannot open file ($filename)";
			exit;
			}
			if (fwrite($handle, $ini_content) === FALSE) {
			echo "Cannot write to file ($filename)";
			exit;
			}
			fclose($handle);



			if ($setting['os']=='windows')
			{

				//this starts the server then checks for the latest pid

				$WshShell = new COM("WScript.Shell");

				$oExec = $WshShell->Run($setting['dir_to_cpanel']."files/windows/sc_serv.exe $filename", 3, false);
				$output = array();


        			exec('tasklist /fi "Imagename eq  sc_serv.exe" /NH', $output);      

				foreach($output as $a => $b)
					$pid = $b;

				if (strstr($pid,"INFO:") || !$pid || mysql_num_rows(mysql_query("SELECT * FROM servers WHERE pid='$pid'"))==1)
				{
					mysql_query("INSERT INTO notices (username,reason,message,ip) VALUES('".$loginun."','Server failure','The server with id".$_GET['view']." cannot start on port ".$serverdata['portbase']."','".$_SERVER['REMOTE_ADDR']."')");

					echo "Could not start server, please contact administration using the contact form on your left";
					closetable();
					exit;
				}
				$pid = explode(" ",$pid);
				$i=0;
				foreach($pid as $a)
				{
					if (is_numeric($a) && !isset($set))
					{
						$pid = trim($a);
						$set = 1;
					}
				}
			}

			if ($setting['os'] == 'linux')
			{
				$pid = shell_exec("nohup ".$setting['dir_to_cpanel']."files/linux/sc_serv ".$setting['dir_to_cpanel'].$filename." > /dev/null & echo $!");
				if (!$pid || $pid == "")
				{
					mysql_query("INSERT INTO notices (username,reason,message,ip) VALUES('".$loginun."','Server failure','The server with id ".$_GET['view']." cannot start on port ".$serverdata['portbase']."','".$_SERVER['REMOTE_ADDR']."')");
					echo "Could not start server, please contact administration using the contact form on your left";
					closetable();
					exit;
				}
			}

			//unlink($filename);
			mysql_query("UPDATE servers SET pid='$pid' WHERE id='".$_GET['view']."'");
				echo "Dein Server sollte jetzt Online sein.<br>Bei einem Problem bitte an den Administrator wenden.<br>";
			closetable();
		}

		if (isset($_GET['action']) && $_GET['action']=="stop")
		{
			table("Servers - &Uuml;berblick - Stoppen");
			$radioport = mysql_query("SELECT portbase FROM servers WHERE id='".$_GET['view']."'");
			$connection = fsockopen($setting['host_add'], mysql_result($radioport,0), $errno, $errstr, 1);
			if (!$connection)
			{
				echo "Server ist nicht Online<br>";
			}else{
				$pid = mysql_query("SELECT pid FROM servers WHERE id='".$_GET['view']."'");
				if (mysql_result($pid,0)=="")
				{

					echo "Fortschritts ID nicht gefunden.<br>Bitte kontaktiere den Administrator.";
					closetable();
					exit;
				}

				if ($setting["os"]=="windows")
				{
					$WshShell = new COM("WScript.Shell");
					$oExec = $WshShell->Run("taskkill /pid ".mysql_result($pid,0)." /f", 3, false);
				}
				if ($setting["os"]=="linux")
				{
					$output = shell_exec("kill ".mysql_result($pid,0));
				}
				echo "Server sollte jetzt Offline sein.";
			}	
			closetable();
		}

				
	}

	
	if (isset($_GET['manage']))
	{

		$serverq = mysql_query("SELECT * FROM servers WHERE id='".$_GET['manage']."'");
		$serverdata = mysql_fetch_array($serverq);

		if ($serverdata['suspended']!="")
		{
			table("Achtung !");
			echo "Der Server ist suspendiert.<br>Klicke <a href='?page=reason&id=".$_GET['manage']."'>hier</a> um Details aufzurufen.";
			closetable();
			exit;
		}

		if (mysql_num_rows($serverq)==0 || $serverdata['owner']!=$loginun && ($userdata['user_level']!="Super Administrator" || $userdata['user_level']!="Administrator") )
		{
			table("Achtung");
			echo "Server existiert nicht, oder ist nicht auf die registriert.<br>Bitte gehe <a href='index.php?page=servers'>zur&uuml;ck</a>";
			closetable();
			exit;
		}
		
		if (!isset($_POST['submit']))
		{
			
			table(" Server - Einstellungen");
			echo "
				<form method='POST' action='index.php?page=servers&manage=".$_GET['manage']."'>
					<table border='0' align='center' width='100%'>
						<tr>
							<td>
							<p align='center'><b><font size=4>Funktion</font></b></td>
							<td width='45%'>
							<p align='center'><b><font size=4>Einstellungen</font></b></td>
						</tr>

			";
			
			$server= mysql_query("SELECT * FROM servers WHERE id='".$_GET['manage']."'");
			foreach (mysql_fetch_array($server) as $field => $value)
			{
				$typeq = mysql_query("SELECT type FROM ini_sets WHERE field='c_".$field."'");
				$ue = mysql_query("SELECT user_editable FROM ini_sets WHERE field='c_".$field."'");
				$q = mysql_fetch_array(mysql_query("SELECT * FROM ini_sets WHERE field='c_".$field."'"));		
				$type=0;
				$skip=0;
				if (mysql_num_rows($typeq)==0 || mysql_num_rows($ue)==0)
					$skip = 1;
				else if (mysql_result($ue,0)==1 && $skip==0)
					$type = 1;
				else if (mysql_result($typeq,0)==1 && $skip==0)
					$type = 0;
				
				if (!is_numeric($field) && $field == "sitepublic" && $type==1 && $skip==0)
				{
					echo "
						<tr>
							<td align='center'><b>".$q['title']."</b><bR><font size=2><i>".$q['description']."</i></font></td>
							<td width='55%' align='center'>
								<select name='".$field."'>
									<option value='1'"; if ($value == 1) echo " Selected"; echo ">Yes</option>
									<option value='0'"; if ($value == 0) echo " Selected"; echo ">No</option>
								</select>
							</td>
						</tr>
					";
					$skip = 1;
				}
				
				if (!is_numeric($field) && $type==1 && $skip==0)
				{

					echo "
						<tr>
							<td align='center'><b>".$q['title']."</b><bR><font size=2><i>".$q['description']."</i></font></td>
							<td width='55%' align='center'><input type='text' name='".$field."' value='".$value."' size=8 maxlength='50'></td>
						</tr>
					";			
				}else if (!is_numeric($field) && $skip==0){
					echo "
						<tr>
							<td align='center'><b>".$q['title']."</b><bR><font size=2><i>".$q['description']."</i></font></td>
							<td width='55%' align='center'>".$value."</td>
						</tr>
					";
				}
			}
			echo "

					</table>
					<center><input type='submit' name='submit' value='Aktualisieren'></center></form>
			";


		}else{


			$fields = "";
			$values = "";
			foreach($_POST as $key => $value)
			{
				if ($key != "submit" && $value!="" && $key!="id")
				{
					$fields .= $key."='".$value."', ";
					$lastfield = $key;
					$lastvalue = $value;
				}
			}
			$fields = explode($lastfield,$fields);
			$fields = $fields['0'].$lastfield."='".$lastvalue."'";

			if (mysql_query("UPDATE servers SET $fields WHERE id='".$_GET['manage']."'"))
			{
				table(" Servers - Aktualisierung");
				echo "Server wurde erfolgreich aktualisiert.<br>&Auml;nderungen werden nach dem n&auml;chsten Neustart &uuml;bernommen.<br>Klicke <a href='index.php?page=servers'>hier</a> um zur&uuml;ck zu kommen";
			}else{
				table(" Servers - Aktualisierung - FEHLER");
				echo "Es ist ein Fehler aufgetreten<br>MYSQL ERROR:<br><font color=red>".mysql_error()."</font><br>Klicke <a href='index.php?page=servers&manage=".$_GET['manage']."'>hier</a> um zur&uuml;ck zu kommen";
				echo "<br>".$fields;
			}
			closetable();
		}
	}
	echo "</table>";