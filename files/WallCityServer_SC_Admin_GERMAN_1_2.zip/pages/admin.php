<?PHP


//
//	
//	WallCityServer
//	Shoutcast Admin Panel	
//	
//	Copyright 2008 
//
////////////////////////////////

if (!eregi("index.php", $_SERVER['PHP_SELF'])) {
    die ("You can't access this file directly...");
}

if ($user_level != "Administrator" && $user_level != "Super Administrator")
{
	table("Warnung");
	echo "Du hast kein Zugriff auf den Admin Bereich";
	closetable();
	exit;
}

	if (isset($_GET['m']))
	$m = $_GET['m'];
	else
	$m = "none";

	if (isset($_GET['action']))
	$action = $_GET['action'];
	else
	$action = "none";

if ($m == "none")
{
	table("Administration");
	echo "
		<center>Bitte ausw&auml;hlen<br><p>
		";
	if ($user_level=="Super Administrator")
	{
		echo "
		[ <a href='index.php?page=admin&m=settings'>Einstellungen</a> ] - 
		[ <a href='index.php?page=admin&m=permissions'>Zugriffsrechte</a> ] -
		[ <a href='index.php?page=admin&m=users'>Benutzer</a> ]<br>
		";
	}
		echo "
		[ <a href='index.php?page=admin&m=servers'>Server</a> ] -
		[ <a href='index.php?page=admin&m=headlines'>Mitteilungen</a> ]
		</p> 
		";
		$noticesq = mysql_query("SELECT * FROM notices");

		if (mysql_num_rows($noticesq)==0)
		{
			echo "Es sind aktuell keine Mitteilungen vorhanden";
		}else{
			echo "Mitteilungen<hr>";
			while($data = mysql_fetch_array($noticesq))
			{
				echo $data['username']." - ".$data['reason']." [ <a href='?page=admin&m=notices&action=view&id=".$data['id']."'>&ouml;ffnen</a> ] -  [ <a href='?page=admin&m=notices&action=remove&id=".$data['id']."'>x</a> ]<br>";
			}
		}
	closetable();
}

if ($m == "notices")
{
	if (!isset($_GET['action']))
	{
			table("Administration - Messages");
		echo "test";
		closetable();
	}

	if (isset($_GET['action']) && $_GET['action'] == "view" && isset($_GET['id']))
	{
		$noticeq = mysql_query("SELECT * FROM notices WHERE id='".$_GET['id']."'");
		$notice = mysql_fetch_array($noticeq);

		table("Administrator - Mailbox");
		echo "<b>Von:</b> ".$notice['username']."<br><b>Begr&uuml;ndung:</b> ".$notice['reason']."<br><b>Mitteilung: </b>".nl2br($notice['message']).
		"<br><br><center><font size=2><i>Mitteilung gesendet von ".$notice['ip']."</i></font><br>[ <a href='?page=admin'>Zur&uuml;ck</a> ] - [ <a href='?page=admin&m=notices&action=remove&id=".$notice['id']."'>x</a> ]</center>";
		closetable();
	}

	if (isset($_GET['action']) && $_GET['action'] == "remove" && isset($_GET['id']))
	{
		if ( mysql_query(" DELETE FROM notices WHERE id='".$_GET['id']."' ") )
		{
			table("Administrator - Mailbox - L&ouml;schen");
			echo "Mitteilungen wurden erfolgreich gel&ouml;scht.<Br>Klicke <a href='?page=admin'>hier</a> um zur&uuml;ck zukommen.";
			closetable();
		}else{
			table("Warnung");
			echo "Es ist ein Fehler aufgetreten!<br>MYSQL ERROR:".mysql_error();
			closetable();
		}
	}
}

if ($m == "settings")
{
	if ($user_level != "Super Administrator")
	{
		table("Warning!");
		echo "Zugriff verweigert.";
		closetable();
		exit;
	}
	if (isset($_POST['submit']))
	{
		table("Administration - Settings - Save");
		if ($action == "none")
		{
			$action = "savesettings";

			foreach($_POST as $key => $pref)
			{
				$_POST[$key] = addslashes($pref);
			}

			if (mysql_query("UPDATE settings SET os='".$_POST['os']."',dir_to_cpanel='".addslashes($_POST['dir_to_cpanel'])."',title='".$_POST['title']."', slogan='".$_POST['slogan']."', page_title='".$_POST['page_title']."', footer='".$_POST['footer']."', host_add='".$_POST['host_add']."', newlink='".$_POST['newlink']."', abuse_control='".$_POST['abuse_control']."', abuse_max_count='".$_POST['abuse_max_count']."', suspended_email='".$_POST['suspended_email']."', suspended_days='".$_POST['suspended_days']."'"))
			echo "<center>Einstellungen erfolgreich ge&auml;ndert.</center>";
			else
			echo "Einstellungen konnten nicht ge&auml;ndert werden.<br>MYSQL RETURNED: <br><font color=red>".mysql_error()."</font>";
			echo "<center><br><a href='index.php?page=admin&m=settings'>Klicke hier um zur&uuml;ck zu kommen</a>";

		}

		closetable();
	}

	if ($action == "none")
	{
		table("Administration - Settings");
		echo "
				<table border='0' align='center' width='100%'>
					<tr>
						<td>
						<p align='center'><b><font size=4>Einstellungen</font></b></td>
						<td width='45%'>
						<p align='center'><b><font size=4>Eigenschaften</font></b></td>
					</tr>
					<tr>
						<td align='center'><b>Betriebssystem</b><bR><font size=2><i>Das Betriebssystem Ihres Servers</i></font></td>
						<td width='55%' align='center'>".$setting['os']."</td>
					</tr>
					<tr>
						<td align='center'><b>Das Verzeichnis dieses Programmes</b><bR><font size=2 color=red><i>Muss richtig angegeben werden!</i></font></td>
						<td width='55%' align='center'>".$setting['dir_to_cpanel']."</td>
					</tr>
					<tr>
						<td align='center'><b>Titel</b><bR><font size=2><i>Der Titel Ihres Servers</i></font></td>
						<td width='55%' align='center'>".$setting['title']."</td>
					</tr>
					<tr>
						<td align='center'><b>Slogan</b><bR><font size=2><i>Der Slogan Ihres Servers</i></font></td>
						<td width='55%' align='center'>".$setting['slogan']."</td>
					</tr>
					<tr>
						<td align='center'><b>Seiten Titel</b><bR><font size=2><i>Der Titel der Website</i></font></td>
						<td width='55%' align='center'>".$setting['page_title']."</td>
					</tr>
					<tr>
						<td align='center'><b>Footer</b><bR><font size=2><i>Inhalt wird unten rechts angezeigt.</i></font></td>
						<td width='55%' align='center'>".$setting['footer']."</td>
					</tr>
					<tr>
						<td align='center'><b>Server Adresse</b><bR><font size=2><i>Die IP/DNS Adresse mit der die User sich verbinden.</i></font></td>
						<td width='55%' align='center'>".$setting['host_add']."</td>
					</tr>
					<tr>
						<td align='center'><b>Auftragssadresse</b><bR><font size=2><i>Die Adresse von <br>\"bestelle einen neuen Server\"</i></font></td>
						<td width='55%' align='center'>".$setting['newlink']."</td>
					</tr>
					<tr>
						<td align='center'><b>Inhalts Kontrolle</b><bR><font size=2><i>Kontrolle der Bitrate</i></font></td>
						<td width='55%' align='center'>".$setting['abuse_control']."</td>
					</tr>
					<tr>
						<td align='center'><b>Block Limit</b><bR><font size=2><i>Zeiten bevor man gelockt wird</i></font></td>
						<td width='55%' align='center'>".$setting['abuse_max_count']." times</td>
					</tr>
					<tr>
						<td align='center'><b>Block E-Mail</b><bR><font size=2><i>Email auf Block</i></font></td>
						<td width='55%' align='center'>".$setting['suspended_email']."</td>
					</tr>
					<tr>
						<td align='center'><b>Block auf Tage</b><bR><font size=2><i>Die gesamten Tage auf die ein User geblockt wird.</i></font></td>
						<td width='55%' align='center'>".$setting['suspended_days']." Days</td>
					</tr>

			</table>
			<center><a href='index.php?page=admin&m=settings&action=editsettings'>Einstellungen ver&auml;ndern</a>
</center>
		";
		closetable();
	}
	if ($action == "editsettings")
	{
		table("Administrator - Einstellungen");
		echo "
				<form action='index.php?page=admin&m=settings' method='POST'>
				<table border='0' align='center' width='100%'>
					<tr>
						<td>
						<p align='center'><b><font size=4>Inhalte</font></b></td>
						<td width='45%'>
						<p align='center'><b><font size=4>Einstellungen</font></b></td>
					</tr>
					<tr>
						<td align='center'><b>Betriebssystem</b><bR><font size=2><i>Das Betriebssystem des Servers</i></font></td>
						<td width='55%' align='center'><select name='os'><option>linux</option><option"; if ($setting['os']=="windows") {echo " selected";} echo ">windows</option></select></td>
					</tr>
					<tr>
						<td align='center'><b>Verzeichnis</b><bR><font size=2><i>Das Verzeichnis des Servers<br>WICHTIG</i></font></td>
						<td width='55%' align='center'><input type='text' name='dir_to_cpanel' maxlength='100' value='".$setting['dir_to_cpanel']."'></td>
					</tr>
					<tr>
						<td align='center'><b>Titel</b><bR><font size=2><i>Der Titel des Servers</i></font></td>
						<td width='55%' align='center'><input type='text' name='title' maxlength='20' value='".$setting['title']."'></td>
					</tr>
					<tr>
						<td align='center'><b>Slogan</b><bR><font size=2><i>Der Slogan des Servers</i></font></td>
						<td width='55%' align='center'><input type='text' name='slogan' maxlength='50' value='".$setting['slogan']."'</td>
					</tr>
					<tr>
						<td align='center'><b>Seiten Titel</b><bR><font size=2><i>Der Titel der Seite</i></font></td>
						<td width='55%' align='center'><input type='text' name='page_title' maxlength='60' value='".$setting['page_title']."'></td>
					</tr>
					<tr>
						<td align='center'><b>Footer</b><bR><font size=2><i>Wird unten-rechts angezeigt</i></font></td>
						<td width='55%' align='center'><input type='text' name='footer' maxlength='100' value='".$setting['footer']."'</td>
					</tr>
					<tr>
						<td align='center'><b>Server Adresse</b><bR><font size=2><i>Die IP/DNS des Servers</i></font></td>
						<td width='55%' align='center'><input type='text' name='host_add' maxlength='60' value='".$setting['host_add']."'></td>
					</tr>
					<tr>
						<td align='center'><b>Bestelladresse</b><bR><font size=2><i>Die Adresse um <br>\"einen Server zu bestellen\"</i></font></td>
						<td width='55%' align='center'><input type='text' name='newlink' maxlength='200' value='".$setting['newlink']."'></td>
					</tr>
					<tr>
						<td align='center'><b>Inhalts Kontrolle</b><bR><font size=2><i>Kontrolle der Bitrate</i></font></td>
						<td width='55%' align='center'><select style='width: 143' name='abuse_control'><option value='on'>On</option><option value='off' "; if ($setting['abuse_control']=="off") echo "selected"; echo ">Off</option></select></td>
					</tr>
					<tr>
						<td align='center'><b>Block Limit</b><bR><font size=2><i>Zeiten bevor man gelockt wird</i></font></td>
						<td width='55%' align='center'><input type='text' name='abuse_max_count' maxlength='2' value='".$setting['abuse_max_count']."' size='13'> Times</td>
					</tr>
					<tr>
						<td align='center'><b>Block E-Mail</b><bR><font size=2><i>E-Mail auf Block</i></font></td>
						<td width='55%' align='center'><select style='width: 143' name='suspended_email'><option value='on'>On</option><option value='off' "; if ($setting['suspended_email']=="off") echo "selected"; echo ">Off</option></select></td>
					</tr>
					<tr>
						<td align='center'><b>Block auf Tage</b><bR><font size=2><i>Die gesamten Tage auf die ein User geblockt wird</i></font></td>
						<td width='55%' align='center'><input type='text' name='suspended_days' maxlength='2' value='".$setting['suspended_days']."' size='14'> Days</td>
					</tr>
			</table>
			<center><input type='submit' name='submit' value='Aktualisieren'>
			</form>
		";
		closetable();
	}



}
if ($m == "users")
{

	//check permissions
	if ($user_level != "Super Administrator")
	{
		table("Achtung!");
		echo "Zugriff verweigert";
		closetable();
		exit;
	}

	if ($action == "none" && !isset($_GET['id']) && !isset($_GET['delete']))
	{
		table("Administration - Benutzer");
		echo "
			<table border='0' align='center' width='100%'>
				<tr>
					<td>
					<p align='center'><b><font size=4>Benutzername</font></b></td>
					<td width='45%'>
					<p align='center'><b><font size=4>Funktionen</font></b></td>
					</tr>
			";

		$limit = $setting['display_limit'];
		if (!isset($_POST['p']))
			$p = 0;
		else
			$p = $_POST['p'] * $limit;
		
			$l = $p + $limit;
		$page = mysql_num_rows(mysql_query("SELECT * FROM users"));


			$get_users = mysql_query("SELECT * FROM users order by id ASC limit $p,$limit");
		while($data = mysql_fetch_array($get_users))
		{
			$get_servers = mysql_query("SELECT * FROM servers WHERE owner='".$data['username']."'");
			echo "
					<tr>
						<td align='center'><b>".$data['username']."</b><bR><font size=2><i>Benutzer hat ".mysql_num_rows($get_servers)." Server</i></font></td>
						<td width='55%' align='center'>[ <a href='index.php?page=admin&m=users&id=".$data['id']."'>Einstellen</a> ] - [ <a href='index.php?page=admin&m=users&delete=".$data['id']."'>L&ouml;schen</a> ]</td>
					</tr>
			";
		}



		echo "
				</table>
				<center><a href='index.php?page=admin&m=users&action=add'>Benutzer hinzuf&uuml;gen</a></center>

			
			<form method='POST' action='index.php?page=admin&m=users'>
				<center>Seite:<select name='p'>";
		$i = 0;
		while($page > "0")
		{


				echo "
			<option "; if (($p / $limit) == $i){echo "selected ";} echo ">$i</option>
				";
			$i++;
			$page -= $limit;
		}
		echo "
				</select><input type='submit' value='ausw&auml;hlen'></center>
		";

	}	
	
	if ($action == "none" && isset($_GET['delete']))
	{
		$userid = mysql_query("SELECT username FROM users WHERE id='".$_GET['delete']."'");
		$userslevel = mysql_query("SELECT user_level FROM users WHERE id='".$_GET['delete']."'");

		if (mysql_result($userid,0)==$loginun)
		{
			table("Achtung!");
			echo "Benutzer kann sich nicht selbst l&ouml;schen<br>Bitte gehe <a href='index.php?page=admin&m=users'>zur&uuml;ck</a>";
			closetable();
			exit;
		}
		

		if (mysql_result($userslevel,0) == "Super Administrator")
		{
			if (!isset($_POST['submit']))
			{
				table("Administrator - Benutzer - L&ouml;schen - Best&auml;tigen");
				echo "
				<form method='POST' action='index.php?page=admin&m=users&delete=".$_GET['delete']."'>
				Um einen Super-Admin zu l&ouml;schen brauchst du das Datenbank Passwort<br>
				<center><input type=password name='c'><input type='submit' name='submit' value='L&ouml;schen'>
				";
			}else if (isset($_POST['submit']) && $_POST['c']== $db_password){
				if (mysql_query("DELETE FROM users WHERE id='".$_GET['delete']."'"))
				{
					table("Administrator - Benutzer - L&ouml;schen");
					echo "Benutzer gel&ouml;scht<br>Klicke <a href='index.php?page=admin&m=users'>hier</a> um zur&uuml;ck zu kommen";
				}else{
					table("Achtung!");
					echo "User konnte nicht gel&ouml;scht werden<br>MYSQL ERROR:<br><font color='red'>".mysql_error()."</font>";
					closetable();
					exit;
				}
			}else{
				table("Achtung!");
				echo "Datenbank Zugangsdaten sind nicht korrekt.<br>Bitte gehe <a href='index.php?page=admin&m=users&delete=".$_GET['delete']."'>zur&uuml;ck</a>";
				closetable();
				exit;
			}
		}else{
			if (!isset($_GET['c']))
			{
				table("Administrator - Benutzer - L&ouml;schen - Best&auml;tigen");
				echo "Sind Sie sicher diesen Benutzer l&ouml;schen zu wollen?<br><a href='index.php?page=admin&m=users&delete=".$_GET['delete']."&c=yes'>Ja</a> - <a href='index.php?page=admin&m=users'>Nein</a>";
			}else{
				if (mysql_query("DELETE FROM users WHERE id='".$_GET['delete']."'"))
				{
					table("Administrator - Benutzer - L&ouml;schen");
					echo "Benutzer gel&ouml;scht<br>Klicke <a href='index.php?page=admin&m=users'>hier</a> um zur&uuml;ck zu kommen";
				}else{
					table("Achtung!");
					echo "Konnte Benutzer nicht l&ouml;schen<br>MYSQL ERROR:<br><font color='red'>".mysql_error()."</font>";
					closetable();
					exit;
				}
			}
		}

	}

	if ($action == "none" && isset($_GET['id']))
	{
		$user = mysql_query("SELECT username FROM users WHERE id='".$_GET['id']."'");
		if (mysql_num_rows($user)==0)
		{
		table("Achtung!");
		echo "<center>Benutzer existiert nicht<BR>Bitte gehe <a href='index.php?page=admin&m=users'>zur&uuml;ck</a>";
		closetable();
		exit;
		}
		table("Administrator - Benutzer - Einstellungen");
		$userq = mysql_query("SELECT * FROM users WHERE id='".$_GET['id']."'");
		foreach(mysql_fetch_array($userq) as $key => $pref)
		{
			if (!is_numeric($key))
			{
				if ($pref != "")
					$userdata[$key] = $pref;
				else
					$userdata[$key] = "none";

			}
		}
	
		echo "
				<form action='index.php?page=admin&m=users&action=update&id=".$_GET['id']."' method='POST'>
				<table border='0' align='center' width='100%'>
					<tr>
						<td>
						<p align='center'><b><font size=4>Inhalte</font></b></td>
						<td width='45%'>
						<p align='center'><b><font size=4>Eigenschaften</font></b></td>
					</tr>
					<tr>
						<td align='center'><b>Benutzername</b><bR><font size=2><i>Der Name des Benutzers</i></font></td>
						<td width='55%' align='center'>".$userdata['username']."</td>
					</tr>
					<tr>
						<td align='center'><b>Passwort</b><bR><font size=2><i>Das Passwort des Benutzers</i></font></td>
						<td width='55%' align='center'><input type='password' name='euser_password' value='".$userdata['user_password']."' maxlength='50'></td>
					</tr>
					<tr>
						<td align='center'><b>Benutzer Status</b><bR><font size=2><i>Zugriffsber&auml;chtigung des Benutzers</i></font></td>
						<td width='55%' align='center'><select name='euser_level'><option "; if($userdata['user_level']=="Super Administrator"){echo "selected ";} echo ">Super Administrator</option><option "; if($userdata['user_level']=="Administrator"){echo "selected ";} echo ">Administrator</option><option "; if($userdata['user_level']=="User"){echo "selected ";} echo ">Benutzer</option></select></td>
					</tr>
					<tr>
						<td align='center'><b>Telefonnummer</b><bR><font size=2><i>Die Telefonnummer des Benutzers</i></font></td>
						<td width='55%' align='center'><input type='text' name='econtact_number' value='".$userdata['contact_number']."' maxlength='10'></td>
					</tr>
					<tr>
						<td align='center'><b>Handynummer</b><bR><font size=2><i>Die Handynummer des Benutzers</i></font></td>
						<td width='55%' align='center'><input type='text' name='emobile_number' value='".$userdata['mobile_number']."' maxlength='50'></td>
					</tr>
					<tr>
						<td align='center'><b>E-Mail</b><bR><font size=2><i>Die E-Mail Adresse des Benutzers/i></font></td>
						<td width='55%' align='center'><input type='text' name='euser_email' value='".$userdata['user_email']."' maxlength='50'></td>
					</tr>
					<tr>
						<td align='center'><b>Vorname</b><bR><font size=2><i>Der Vorname des Benutzer</i></font></td>
						<td width='55%' align='center'><input type='text' name='ename' value='".$userdata['name']."' maxlength='50'></td>
					</tr>
					<tr>
						<td align='center'><b>Nachname</b><bR><font size=2><i>Der Nachname des Benutzer</i></font></td>
						<td width='55%' align='center'><input type='text' name='esurname' value='".$userdata['surname']."' maxlength='50'></td>
					</tr>
					<tr>
						<td align='center'><b>Alter</b><bR><font size=2><i>Das Alter des Benuters</i></font></td>
						<td width='55%' align='center'><input type='text' name='eage' value='".$userdata['age']."' maxlength='50'></td>
					</tr>
					<tr>
						<td align='center'><b>Konto Zusatznote</b><bR><font size=2><i>Nur Super-Admin Zugriff</i></font></td>
						<td width='55%' align='center'><textarea cols=15 rows=5 name='eaccount_notes'>".$userdata['account_notes']."</textarea></td>
					</tr>
				</table>
				<center><input type='submit' name='submit' value='Aktualisieren'></center>
		";
	}

	if ($action == "update" && isset($_GET['id']))
	{
		$user = mysql_query("SELECT username FROM users WHERE id='".$_GET['id']."' ");
		if (mysql_num_rows($user)==0)
		{
			table("Warning!");
			echo "User Does not exist";
			closetable();
			exit;
		}
		table("Administration - Users - Update ".mysql_result($user,0));
		if (mysql_query("UPDATE users SET user_password='".$_POST['euser_password']."', md5_hash='".md5(strtolower(mysql_result($user,0).$_POST['euser_password']))."', user_level='".$_POST['euser_level']."', contact_number='".$_POST['econtact_number']."', mobile_number='".$_POST['emobile_number']."', user_email='".$_POST['euser_email']."', name='".$_POST['ename']."', surname='".$_POST['esurname']."', age='".$_POST['eage']."', account_notes='".$_POST['eaccount_notes']."' WHERE id='".$_GET['id']."'"))
			echo "User ".mysql_result($user,0)." updated successfully<br>Click <a href='index.php?page=admin&m=users'>here</a> to go back to the users page";
		else
			echo "There was an error updating user ".mysql_result($user,0)."<br>MYSQL ERROR:<bR><font color=red>".mysql_error()."</font>";

	}

	if ($action == "add")
	{
		if (!isset($_POST['submit']))
		{
			table("Administration - Users - Add user");
			echo "
			<form method='POST' action='index.php?page=admin&m=users&action=add'>
				<table border='0' align='center' width='100%'>
					<tr>
						<td>
						<p align='center'><b><font size=4>Inhalte</font></b></td>
						<td width='45%'>
						<p align='center'><b><font size=4>Eigenschaften</font></b></td>
					</tr>
					<tr>
						<td align='center'><b>Benutzername</b><bR><font size=2><i>Der Name des Benutzers</i></font></td>
						<td width='55%' align='center'><input type='text' name='cusername' maxlength='15'>
						</td>
					</tr>
					<tr>
						<td align='center'><b>Passwort</b><bR><font size=2><i>Das Passwort des Benutzers</i></font></td>
						<td width='55%' align='center'><input type='password' name='cuser_password' maxlength='50'></td>
					</tr>
					<tr>
						<td align='center'><b>Passwort Wiederholung</b><bR><font size=2><i>Passwort &Uuml;berpr&uuml;fung</i></font></td>
						<td width='55%' align='center'><input type='password' name='ccuser_password' maxlength='50'></td>
					</tr>
					<tr>
						<td align='center'><b>Benutzer Status</b><bR><font size=2><i>Zugriffsber&auml;chtigung des Benutzers</i></font></td>
						<td width='55%' align='center'><select name='cuser_level'><option>Super Administrator</option><option>Administrator</option><option selected>Benutzer</option></select></td>
					</tr>
					<tr>
						<td align='center'><b>Telefonnummer</b><bR><font size=2><i>Die Telefonnummer des Benutzers</i></font></td>
						<td width='55%' align='center'><input type='text' name='ccontact_number'  maxlength='10'></td>
					</tr>
					<tr>
						<td align='center'><b>Handynummer</b><bR><font size=2><i>Die Handynummer des Benutzers</i></font></td>
						<td width='55%' align='center'><input type='text' name='cmobile_number' maxlength='50'></td>
					</tr>
					<tr>
						<td align='center'><b>E-Mail</b><bR><font size=2><i>Die E-Mail Adresse des Benutzers</i></font></td>
						<td width='55%' align='center'><input type='text' name='cuser_email' maxlength='50'></td>
					</tr>
					<tr>
						<td align='center'><b>Vorname</b><bR><font size=2><i>Der Vorname des Benutzers</i></font></td>
						<td width='55%' align='center'><input type='text' name='cname' maxlength='50'></td>
					</tr>
					<tr>
						<td align='center'><b>Nachname</b><bR><font size=2><i>Der Nachname des Benutzers</i></font></td>
						<td width='55%' align='center'><input type='text' name='csurname' maxlength='50'></td>
					</tr>
					<tr>
						<td align='center'><b>Alter</b><bR><font size=2><i>Das Alter des Benutzers</i></font></td>
						<td width='55%' align='center'><input type='text' name='cage' maxlength='50'></td>
					</tr>
					<tr>
						<td align='center'><b>Konto Zusatznote</b><bR><font size=2><i>Nur Super-Admin Zugriff</i></font></td>
						<td width='55%' align='center'><textarea cols=15 rows=5 name='caccount_notes'></textarea></td>
					</tr>
				</table>
				<center><input type='submit' name='submit' value='Benutzer Erstellen'></center>
			";
		}else{
			table("Administration - Users - Create account");
			if (mysql_num_rows(mysql_query("SELECT * FROM users WHERE username='".$_POST['cusername']."'")) == 1)
			{
				echo "Benutzer existiert schon.";
				closetable();
				exit;
			}
			$id = mysql_result(mysql_query("SELECT id FROM users order by id DESC"),0) + 1;
			
			if ($_POST['cuser_password']!=$_POST['ccuser_password'])
			{
				echo "Passw&ouml;rter passen nicht &uuml;berein.<br>Bitte gehe <a href='index.php?page=admin&m=users&action=add'>zur&uuml;ck.</a>";
				closetable();
				exit;
			}
			
			if (mysql_query("INSERT INTO users (username,user_password,md5_hash,user_level,user_email,contact_number,mobile_number,account_notes,name,surname,age) VALUES('".$_POST['cusername']."', '".$_POST['cuser_password']."','".md5(strtolower($_POST['cusername'].$_POST['cuser_password']))."','".$_POST['cuser_level']."', '".$_POST['cuser_email']."', '".$_POST['ccontact_number']."', '".$_POST['cmobile_number']."', '".$_POST['caccount_notes']."', '".$_POST['cname']."', '".$_POST['csurname']."', '".$_POST['cage']."') "))
			{
				echo "<center>Account '".$_POST['cusername']."' erfolgreich erstellt.<br><br>Klicke <a href='index.php?page=admin&m=users'>hier</a> um zur&uuml;ck zu kommen<bR>oder<br>klicke <a href='index.php?page=admin&m=servers&action=create&o=".$id."'>hier</a> um einen Server f&uuml;r diesen Benutzer zu erstellen.";
			}else{
				echo "Es ist ein Fehler aufgetreten.<br>MYSQL ERROR:<br><font color=red>".mysql_error()."</font>";
			}
		}
	}
	
	closetable();

}



if ($m == "servers")
{
	if (!isset($_GET['manage']) && !isset($_GET['delete']) && $action == "none")
	{
		table("Administrator - Server");

		echo "
				<table border='0' align='center' width='530'>
					<tr>
						<td width=150>
						<p align='left'><b><font size=4>Inhaber</font></b></td>
						<td align=center width='80'>
						<p><b><font size=4>Port</font></b></td>
						<td width='300' align=center>
						<p align='center'><b><font size=4>Funktionen</font></b></td>
					</tr>
		";

		$limit = $setting['display_limit'];
		if (!isset($_POST['p']))
			$p = 0;
		else
			$p = $_POST['p'] * $limit;
		
			$l = $p + $limit;

		$listq = mysql_query("SELECT * FROM servers order by id ASC limit $p,$limit");
		while($data = mysql_fetch_array($listq))
		{

				echo "

					<tr>
						<td align='left'>".$data['owner']."</td>
						<td align='center'>".$data['portbase']."</td>
						<td align='center'>[ <a href='index.php?page=admin&m=servers&manage=".$data['id']."'>Einstellen</a> ] - [ <a href='index.php?page=admin&m=servers&delete=".$data['id']."'>L&ouml;schen</a> ] - [ <a href='index.php?page=servers&view=".$data['id']."&action=start'>Starten</a> ] - [ <a href='index.php?page=servers&view=".$data['id']."&action=stop'>Stoppen</a> ] </td>
					</tr>


				";

		}
		echo "
				</table>
				<br><center><a href='index.php?page=admin&m=servers&action=create'>Server erstellen</a>
		";
		$page = mysql_num_rows(mysql_query("SELECT * FROM servers"));
		echo "
			<form method='POST' action='index.php?page=admin&m=servers'>
				<center>Seiten:<select name='p'>";
		$i = 0;
		while($page > "0")
		{


				echo "
			<option "; if (($p / $limit) == $i){echo "selected ";} echo ">$i</option>
				";
			$i++;
			$page -= $limit;
		}
		echo "
				</select><input type='submit' value='ausw&auml;hlen'></center>
		";
	}

	if ($action == "create")
	{
		if (!isset($_POST['submit']))
		{
			$nextportq = mysql_query("SELECT portbase FROM servers order by portbase DESC");
			if (mysql_num_rows($nextportq)>=1)
				$nextport = mysql_result($nextportq,0) + 2;
			else
				$nextport = "8000";

			if (isset($_GET['o']))
				$owner = mysql_result(mysql_query("SELECT username FROM users WHERE id='".$_GET['o']."' "),0);
			else
				$owner = "";
			
			table("Administrator - Server - Erstellen");
			echo "
			<form method='POST' action='index.php?page=admin&m=servers&action=create'>
					<table border='0' align='center' width='100%'>
						<tr>
							<td>
							<p align='center'><b><font size=4>Inhalte</font></b></td>
							<td width='45%'>
							<p align='center'><b><font size=4>Einstellen</font></b></td>
						</tr>

			";

			$ini_settings = mysql_query("SELECT * FROM ini_sets order by id");
			while ($data = mysql_fetch_array($ini_settings))
			{

				if ($data['type']==1)
				{
					if ($data['value'] == "nextport")
						$data['value'] = $nextport;
					if ($data['value'] == "getowner")
					{
						$data['value'] = $owner;
						echo "
							<tr>
								<td align='center'><b>Benutzername</b><bR><font size=2><i>".$data['description']."</i></font></td>
								<td align='center'>
									<br><select name=\"c_owner\" size='6' length='50' >
						";
						$users_query = mysql_query("SELECT * FROM users");
						while($data = mysql_fetch_array($users_query))
						{
							echo "<option";
							if ($data['username'] == $owner)
								echo " selected"; 
							echo ">".$data['username']."</option>\n";
						}
						echo "
									</select>
							</td>
						</tr>

						";
					}else{
						echo "
							<tr>
								<td align='center'><b>".$data['title']."</b><bR><font size=2><i>".$data['description']."</i></font></td>
								<td width='55%' align='center'><input type='text' name='".$data['field']."' value='".$data['value']."' maxlength='50'></td>
							</tr>
						";
					}
				}else{
					echo "
						<tr>
							<td align='center'><b>".$data['title']."</b></td>
							<td width='55%' height=80 align='center'>".$data['value']."</td>
						</tr>
					";
				}
				
				
			}
			echo "

					</table>
					<center><input type='submit' name='submit' value='submit'>
			";
		}else{
			$portexist = mysql_query("SELECT * FROM servers WHERE portbase='".$_POST['c_portbase']."'");
			if (mysql_num_rows($portexist)>0)
			{
				$nextportq = mysql_query("SELECT portbase FROM servers order by portbase DESC");
				$newport = mysql_result($nextportq,0) + 2;
				table("Warnung");
				echo "Port ".$_POST['c_portbase']." wird schon benutzt<br>Port wurde ge&auml;ndert in: $newport";
				$_POST['c_portbase'] = $newport;
				closetable();
				echo "<br>";
			}			
			
			
			$fields = "";
			$values = "";
			foreach($_POST as $key => $value)
			{
				if ($key == "c_logfile")
					$value = ereg_replace("{port}", $_POST['c_portbase'], $value);

				if ($key != "submit" && $value!="")
				{
					$key = explode("c_", $key);
					$key = $key['1'];
					$fields .= $key.",";
					$lastfield = $key;
					$values .= "'".$value."',";
					$lastvalue = "'".$value."'";
				}
			}
			$fields = explode($lastfield,$fields);
			$fields = $fields['0'].$lastfield;
			$values = explode($lastvalue,$values);
			$values = $values['0'].$lastvalue;

			// open port on firewall and restart firewall
			if ($setting['open_ports_firewall'] == 1)
			{
				$firewall_file = "firewall.txt";
				$inbound = "# Common ingress (inbound) TCP ports";
				$outbound = "# Common egress (outbound) TCP ports";
	
				$ports = $_POST['c_portbase'];
				$ports = $ports.",".($ports + 1);

				$nxt = 0;
				$fc=file($firewall_file);
				$f=fopen($firewall_file,"w");
				foreach($fc as $line)
				{
					if ($nxt=="1")
					{
						$nxt = 0;
						$line = explode("\"",$line);
						$line = $line['0']."\"".$line['1'].",".$ports."\"
";
						fputs($f,$line);
					}else{
						if (strstr($line,$inbound) || strstr($line,$outbound))
						{
							$nxt = 1;
						}
						fputs($f,$line); 
					}
				}
				fclose($f);
			}

			if ( mysql_query(" INSERT INTO servers ($fields) VALUES($values) ") )
			{
				table("Administrator - Server - Erstellt");
				echo "Server wurde erfolgreich erstellt.<br>Klicke <a href='index.php?page=admin&m=servers'>hier</> um zur&uuml;ck zu kommen";
			}else{
				table("Achtung");
				echo "Server konnte nicht erstellt werden<br>MYSQL ERROR:<br><font color=red>".mysql_error()."</font>";
			}
		}


	}

	if (isset($_GET['manage']))
	{
		$serverq = mysql_query("SELECT * FROM servers WHERE id='".$_GET['manage']."'");
		if (mysql_num_rows($serverq)==0)
		{
			table("Achtung");
			echo "Server existiert nicht<br>Bitte gehe <a href='index.php?page=admin&m=servers'>zur&uuml;ck</a>";
			closetable();
			exit;
		}
		
		if (!isset($_POST['submit']))
		{
			
			table("Administrator - Server - &Uuml;berblick");
			echo "
				<form method='POST' action='index.php?page=admin&m=servers&manage=".$_GET['manage']."'>
					<table border='0' align='center' width='100%'>
						<tr>
							<td>
							<p align='center'><b><font size=4>&Uuml;berblick</font></b></td>
							<td width='45%'>
							<p align='center'><b><font size=4>Einstellungen</font></b></td>
						</tr>

			";
			
			$server= mysql_query("SELECT * FROM servers WHERE id='".$_GET['manage']."'");
			foreach (mysql_fetch_array($server) as $field => $value)
			{
				$type = mysql_query("SELECT type FROM ini_sets WHERE field='c_".$field."'");
				if (mysql_num_rows($type)==1)
					$type = mysql_result($type,0);
				else
					$type = 3; // non-existant

				if ($user_level=="Administrator")
				{
							$ae = mysql_query("SELECT admin_editable FROM ini_sets WHERE field='c_".$field."'");
							if (mysql_num_rows($ae)==1 && mysql_result($ae,0)==0)
								$type=0;
				}

				if (!is_numeric($field) && $type==1)
				{
					$q = mysql_query("SELECT description FROM ini_sets WHERE field='c_".$field."'");
					echo "
						<tr>
							<td align='center'><b>".$field."</b><bR><font size=2><i>".mysql_result($q,0)."</i></font></td>
							<td width='55%' align='center'><input type='text' name='".$field."' value='".$value."' size=10 maxlength='50'></td>
						</tr>
					";			
				}else if (!is_numeric($field) && $type==0 ){
					$q = mysql_query("SELECT description FROM ini_sets WHERE field='c_".$field."'");
					echo "
						<tr>
							<td align='center'><b>".$field."</b><bR><font size=2><i>".mysql_result($q,0)."</i></font></td>
							<td width='55%' align='center'>".$value."</td>
						</tr>
					";
				}
			}
			echo "

					</table>
					<center><input type='submit' name='submit' value='Aktualisieren'>
			";

		}else{


			$fields = "";
			$values = "";
			foreach($_POST as $key => $value)
			{
				if ($key != "submit" && $value!="" && $key!="id")
				{
					$fields .= $key."='".$value."', ";
					$lastfield = $key;
					$lastvalue = $value;
				}
			}
			$fields = explode($lastfield,$fields);
			$fields = $fields['0'].$lastfield."='".$lastvalue."'";

			if (mysql_query("UPDATE servers SET $fields WHERE id='".$_GET['manage']."'"))
			{
				table("Administrator - Server - Aktualisierung");
				echo "Server wurde erfolgreich akutalisiert<br>&Auml;nderungen werden ab dem n&auml;chsten Neustart aktiv.<br>Klicke <a href='index.php?page=admin&m=servers'>hier</a> um zur&uuml;ck zu kommen";
			}else{
				table("Administrator - Server - Aktualisierung - FEHLER");
				echo "Es ist ein Fehler aufgetreten<br>MYSQL ERROR:<br><font color=red>".mysql_error()."</font><br>Klicke <a href='index.php?page=admin&m=servers&manage=".$_GET['manage']."'>hier</a> um zur&uuml;ck zu kommen";
				echo "<br>".$fields;
			}
			closetable();
		}
	}


	if (isset($_GET['delete']))
	{
		$exist = mysql_query("SELECT * FROM servers WHERE id='".$_GET['delete']."'");
		if (mysql_num_rows($exist)==0)
		{
			table("Achtung");
			echo "Der Server existiert nicht<br>Bitte gehe <a href='index.php?page=admin&m=servers'>zur&uuml;ck</a>";
			closetable();
			exit;
		}
		if (!isset($_GET['c']))
		{
			table("Administrator - Server - L&ouml;schen");
			echo "Sind Sie sich wirklich sicher diesen Server l&ouml;schen zu wollen?<br>[ <a href='index.php?page=admin&m=servers&delete=".$_GET['delete']."&c=y'>JA</a> ] - [ <a href='index.php?page=admin&m=servers'>Nein</a> ]";
		}else if ($_GET['c']=='y'){
			
			if (mysql_query("DELETE FROM servers WHERE id='".$_GET['delete']."'"))
			{
				table("Administrator - Server - L&ouml;schen");
				echo "Server ID ".$_GET['delete']." wurde erfolgreich gel&ouml;scht<br>Klicke <a href='index.php?page=admin&m=servers'>hier</a> um zur&uuml;ck zu kommen";
			}
		}
		
	}
closetable();
echo "<br>";
}


if ($m == "headlines")
{
	if (!isset($_GET['delete']) && !isset($_GET['add']))
	{
		table("Administrator - Mitteilungen");
		$headlines = mysql_query("SELECT * FROM headlines");
		if (mysql_num_rows($headlines)==0)
		{
			echo "<center>Es sind keine Mitteilungen vorhanden.</center>";
		}
		while($data = mysql_fetch_array($headlines))
		{
			echo $data['title']." [ <a href='?page=admin&m=headlines&delete=".$data['id']."'>L&Ouml;SCHEN</a> ]<br>";
		}
		echo "<br><center><a href='?page=admin&m=headlines&add=new'>Eine neue Mitteilung</a><br><br>
			Klicke <a href='?page=admin'>hier</a> um zur&uuml;ck zu kommen</center>";
		closetable();
	}

	if (isset($_GET['delete']) && $_GET['delete']!="")
	{
		$headline = mysql_query("SELECT * FROM headlines WHERE id='".$_GET['delete']."'");
		if (mysql_num_rows($headline)==0)
		{
			table("Achtung");
			echo "Mitteilung mit der ID ".$_GET['delete']." existiert nicht<br>Bitte gehe <a href='?page=admin&m=headlines'>zur&uuml;ck</a>";
		}else{
			if (mysql_query("DELETE FROM headlines WHERE id='".$_GET['delete']."'"))
			{
				table("Administrator - Mitteilungen - L&ouml;schen");
				echo "Mitteilung wurde erfolgreich gel&ouml;scht<br>Bitte gehe <a href='?page=admin&m=headlines'>zur&uuml;ck</a>";
			}else{
				table("Achtung");
				echo "Mitteilung konnte nicht gel&ouml;scht werden<br>MYSQL ERROR:<br>".mysql_error();
			}
			
		}
		closetable();
	}

	if (isset($_GET['add']) && $_GET['add']=="new")
	{
		if (!isset($_POST['submit']))
		{
			table("Administrator - Mitteilung - Neue Mitteilung");
			echo "
				<form action='?page=admin&m=headlines&add=new' method=post>
				Titel: <input type='text' name='title1'> <input type='text' name='title2' value='- von ".$loginun."' size=15 maxlength=23><br>
				<br>Text: (HTML erlaubt)<br>
				<textarea rows=13 cols=43 name='text'></textarea>
				<br><center><input type='submit' name='submit' value='&Uuml;bernehmen'></center>
				";
			closetable();
		}else{
			if (mysql_query("INSERT INTO headlines (username,title,text) VALUES('".$loginun."','".stripslashes($_POST['title1'].$_POST['title2'])."', '".stripslashes($_POST['text'])."')"))
			{
				table("Administrator - Mitteilung - Erstellt");
				echo "Ihre Mitteilung wurde erfolgreich erstellt<br>Bitte gehe <a href='?page=admin&m=headlines'>zur&uuml;ck</a>";
				closetable();
			}else{
				table("Achtung");
				echo "Es ist ein Fehler aufgetreten<br>MYSQL ERROR:<br>
				".mysql_error();
				closetable();
			}
		}
	}
}


if ($m == "permissions")
{
	//check permissions
	if ($user_level != "Super Administrator")
	{
		table("Achtung!");
		echo "Zugriff Verweigert";
		closetable();
		exit;
	}
	$ini_sets = mysql_query("SELECT * FROM ini_sets WHERE field!='other'");

	if (!isset($_POST['submit']))
	{
		table("Administrator - Zugriff");
		echo "
			<form action='?page=admin&m=permissions' method='POST'>
			<table border='0' align='center' width='100%'>
				<tr>
					<td>
					<p align='center'><b><font size=4>Inhalt</font></b></td>
					<td width='45%'>
					<p align='center'><b><font size=4>Admin Zugriff</font></b></td>
					<td width='45%'>
					<p align='center'><b><font size=4>User Zugriff</font></b></td>
				</tr>
		";

		while($data = mysql_fetch_array($ini_sets))
		{
			echo "
				<tr>
					<td align='center'>
						<b>".$data['title']."</b><bR><font size=2><i>".$data['description']."</i></font>
					</td>
					<td align='center'>
						<input type='checkbox' name='admin_".$data['field']."'"; if ($data['admin_editable']==1) echo " checked"; echo ">	
					</td>
					<td align='center'>
						<input type='checkbox' name='user_".$data['field']."'"; if ($data['user_editable']==1) echo " checked"; echo ">	
					</td>
				</tr>
			";
		}
		echo "
				<tr>
					<td height='70' valign='middle' align='center' colspan='3'>
						<input type='submit' name='submit' value='Zugriff setzen'>
					</td>
				</tr>
			</table>
		";
	}else{
		while($data = mysql_fetch_array($ini_sets))
		{
			if (isset($_POST['user_'.$data['field']]))
			{
				if (!isset($user_on))
					$user_on = "field='".$data['field']."'";
				else
					$user_on .= " OR field='".$data['field']."'";
			}else if (!isset($_POST['user_'.$data['field']])){
				if (!isset($user_off))
					$user_off = "field='".$data['field']."'";
				else
					$user_off .= " OR field='".$data['field']."'";
			}

			if (isset($_POST['admin_'.$data['field']]))
			{
				if (!isset($admin_on))
					$admin_on = "field='".$data['field']."'";
				else
					$admin_on .= " OR field='".$data['field']."'";
			}else if (!isset($_POST['admin_'.$data['field']])){
				if (!isset($admin_off))
					$admin_off = "field='".$data['field']."'";
				else
					$admin_off .= " OR field='".$data['field']."'";
			}

		}
		if (!isset($end) 
		&& mysql_query("UPDATE ini_sets SET user_editable='1' WHERE ".$user_on) 
		&& mysql_query("UPDATE ini_sets SET user_editable='0' WHERE ".$user_off) 
		&& mysql_query("UPDATE ini_sets SET admin_editable='1' WHERE ".$admin_on) 
		&& mysql_query("UPDATE ini_sets SET admin_editable='0' WHERE ".$admin_off) 
		){
			table("Administrator - Zugriff - Aktualisierung");
			echo "Zugriffsrechte erfolgreich aktualisiert<br>Klicke <a href='?page=admin'>hier</a> um zur&uuml;ck zu kommen";
			closetable();
		}else{
			table("Administration - Zugriff - Aktualisierung");
			echo "Es ist ein Fehler aufgetreten<br>MYSQL ERROR:<font color=red>".mysql_error()."</font>";
			closetable();
		}
	}
	closetable();
}

if ($m == "custom_pages")
{
	table("Custom Pages");
	echo "Ist bald erreichbar";
	closetable();
}

