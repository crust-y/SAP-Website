<?php


//
//	
//	WallCityServer
//	Shoutcast Admin Panel	
//	
//	Copyright 2008 
//
////////////////////////////////


$limit = $setting['display_limit'];
if (!isset($_POST['p']))
	$p = 0;
else
	$p = $_POST['p'] * $limit;

$l = $p + $limit;

$select = mysql_query("SELECT * FROM servers WHERE sitepublic='1' ORDER BY id ASC LIMIT $p,$limit");

table("&Ouml;ffentliche Server");

		echo "			<center>";

		if (mysql_num_rows($select)==0)
			echo "			Es sind keine &Ouml;ffentliche Server vorhanden.";
		else{
		
			while($data = mysql_fetch_array($select))
				echo "				<a href='http://".$setting['host_add'].":".$data['portbase']."'>Server von ".$data['owner']." auf Port ".$data['portbase']."</a><br>\n";
		}

		$page = mysql_num_rows(mysql_query("SELECT * FROM servers WHERE sitepublic='1'"));
		echo "\n<BR>
			<form method='POST' action='index.php?page=pservers'>
				<center>Seite:&nbsp;<select name='p'>";
		$i = 0;
		$page = mysql_num_rows(mysql_query("SELECT * FROM servers"));
		while($page > "0")
		{
				echo "
			<option "; if (($p / $limit) == $i){echo "selected ";} echo ">$i</option>
				";
			$i++;
			$page -= $limit;
		}
		echo "
				</select><input type='submit' value='Auflisten'>
				</center>
		";
closetable();