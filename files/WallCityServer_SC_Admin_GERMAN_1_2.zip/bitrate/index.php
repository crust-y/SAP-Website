<?php

// Determine if script is being run through a webserver
// or directly through php

if ( $_SERVER["argv"]["0"] == "" || !isset($_SERVER["argv"]["0"]) )
{	$include = "../database.php"; 	$break = "<br>";	}
else
{	$include = ereg_replace( "bitrate/index.php", "database.php", $_SERVER["argv"]["0"] );	$break = "\n";	}

// Include the database file to be used in connection below

if ( !include($include) )
{	die("Database include failed{$break}{$break}Cannot continue{$break}{$break}Bitrate checker failed");	}
else
{	echo "{$break}database.php loaded successfully{$break}";	}



echo "Scanning....{$break}{$break}";

// Lookup settings from database then assign as an array

$setting_query = mysql_query("SELECT * FROM ".$db_prefix."settings");
$setting = mysql_fetch_array( $setting_query );
// Assign functions for use in bitrate checker

	function serv_query( $serv_address, $serv_port )
	{
		$serv_address = gethostbyname( $serv_address );
		$connection = @fsockopen( $serv_address, $serv_port, $errno, $errstr, 1);
		$serv_data = "";
		
		if ( !$connection )
		{ return false;	}
		else
		{
			fputs( $connection, "GET /7.html HTTP/1.1\r\nAccept: */*\r\nAccept-Encoding: gzip, deflate\r\nUser-Agent: Cast-Control.net (Mozilla Compatible)\r\nConnection: Keep-Alive\r\n\r\n");
			while( !feof($connection) )
			{	$serv_data .= fread($connection, 500);	}
			fclose( $connection );
			$query = substr( $serv_data, strpos($serv_data, "\r\n\r\n") + 4);
			return $query;
		}
	}

	function serv_kick($serv_address, $serv_port, $serv_pass)
	{
		//$serv_address = gethostbyname( $serv_address );
		//$connection = @fsockopen( $serv_address, $serv_port, $errno, $errstr, 1);
		//if ( $connection )
		//{echo "Attempting to kick server";
   		//      fputs($connection, "GET http://admin:{$serv_pass}@{$serv_address}:{$serv_port}/admin.cgi?mode=kicksrc  HTTP/1.0\r\nUser-Agent: Mozilla\r\n\r\n");
		//	return true;
		//}else{ echo "2";
		//	return false;
		//}

		echo "Kicking is currently disabled";
	}

	function serv_stop( $process_id )
	{
		global $setting;

		if ( trim($process_id) == "" )
		{
			echo "PID NOT FOUND FOR THIS SERVER{$break}";
			return false;
		}
		
		if ( $setting["os"] == "windows" )
		{
			$output = array();
			exec("taskkill /pid ".$process_id." /f", $output);
			if ( !strstr($output["0"], "SUCCESS") )
			{
				echo $output["0"];
				return false;
			}	
		}
		if ( $setting["os"]=="linux" )
		{
			$output = shell_exec("kill ".$process_id);
		}
		return true;
	}


// Comfirm abuse control is activated
// abuse_control will never equal on
// either stop, kick or off

if ( $setting["abuse_control"] != "off" )
{
	$reported = 0;
	$select_server = mysql_query("SELECT * FROM ".$db_prefix."servers");
	while( $serverdata = mysql_fetch_array( $select_server ) )
	{
		$server_query = serv_query( $setting["host_add"], $serverdata["portbase"] );
		if ( $server_query )
		{
			if ( $serverdata["suspended"] != "" )
			{
				if ( serv_stop($serverdata["pid"]) )
				{
					mysql_query("UPDATE ".$db_prefix."servers SET pid='' WHERE id='".$serverdata["id"]."'");
				}else{
					mysql_query("INSERT INTO ".$db_prefix."notices (username, reason, message, ip, time) VALUES ('Bitrate Checker', 'BITRATE CHECK FAIL', 'Bitrate checker failed to stop server on port ".$serverdata["portbase"].".<br>', 'localhost', '".time()."' )");
				}
				$skip = true;
			}
	
			$query_data = explode( "," , $server_query );
			if ($query_data["1"] == "1" && !isset($skip))
			{
				$bitrate = $query_data["5"];
				if ( $bitrate > $serverdata["bitrate"] )
				{
					$reported++;
					mysql_query("UPDATE ".$db_prefix."servers SET abuse='".($serverdata['abuse'] + 1)."' WHERE id='".$serverdata['id']."'");

					if ( ($serverdata["abuse"] + 1) >= $setting["abuse_max_count"] )
					{
						// Set abuse_control to stop the server
						$setting["abuse_control"] = "stop";
						// Suspend server
						mysql_query("UPDATE ".$db_prefix."servers SET suspended='reason: breaking bitrate limit\ntimestamp: ".time()." days: ".$setting["suspended_days"]."', abuse='0' WHERE id='".$serverdata['id']."'");
	
						// Should we email the owner?
						if ( $setting["suspended_email"] == "on" )
						{
							$userdata_query = mysql_query("SELECT * FROM ".$db_prefix."users WHERE username='".$serverdata["owner"]."' ");
							$userdata = mysql_fetch_array( $userdata_query );
							if ( mysql_num_rows($userdata_query) == 1 && $userdata["user_email"] != "none")
							$headers  = "From: \"Admin\"<".$setting["admin_email"].">\n";
 							$headers .= "MIME-Version: 1.0\n";
							$headers .= "Content-Type: text/plain; boundary=\"-----=".md5(uniqid(rand()))."\"";
							mail($userdata["user_email"], "SHOUTcast Server", "Your server on port \"".$serverdata["portbase"]."\" has been suspended for disobeying bitrate rules\n\n".$setting["title"]."\n".$setting["slogan"]."\nEmail sent by Cast-Control.net bitrate checker", $headers);
						}
					}

					if ( $setting["abuse_control"] == "kick" )
					{
						if ( !serv_kick($setting["host_add"], $serverdata["portbase"], $serverdata["adminpassword"]) )
						{
							mysql_query("INSERT INTO ".$db_prefix."notices (username, reason, message, ip, time) VALUES ('Bitrate Checker', 'BITRATE CHECK FAIL', 'Bitrate checker failed to kick source on port ".$serverdata["portbase"].".<br>', 'localhost', '".time()."' )");
						}
					}
					if ( $setting["abuse_control"] == "stop" )
					{
						if ( serv_stop($serverdata["pid"]) )
						{
							mysql_query("UPDATE ".$db_prefix."servers SET pid='' WHERE id='".$serverdata["id"]."'");
						}else{
							mysql_query("INSERT INTO ".$db_prefix."notices (username, reason, message, ip, time) VALUES ('Bitrate Checker', 'BITRATE CHECK FAIL', 'Bitrate checker failed to stop source on port ".$serverdata["portbase"].".<br>', 'localhost', '".time()."' )");
						}
					}
				}
			}
		}
	}
	echo "{$break}{$break}Scan complete{$break}$reported servers broke the bitrate";
}else{
	echo "Abuse control is disabled";
}

