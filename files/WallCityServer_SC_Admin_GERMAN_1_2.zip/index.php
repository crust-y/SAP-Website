<?PHP


//
//	
//	WallCityServer
//	Shoutcast Admin Panel	
//	
//	Copyright 2008 
//
////////////////////////////////

session_start();


$version = "0.12";

if (!include("database.php"))
	die("database.php konnte nicht gefunden werden.");

if ($db_host == "" || !isset($db_host))
	header("Location: ./install/install.php");

$connection = mysql_connect($db_host, $db_username, $db_password) or die ('MySQL Server nicht erreichbar. Bitte Administrator kontaktieren.');
$db = mysql_select_db($database) or die ("Datenbank nicht gefunden.<br>Bitte neu installieren.");


if (!isset($_GET['page']))
{
	$page = "main";
}else{
	$page = $_GET['page'];
}


// Get settings
$settingsq = mysql_query("SELECT * FROM settings WHERE id='0'") or die("Datenbank Fehler<br>Bitte spanel.sql erneut in die Datenbank hinzuf&uuml;gen.");
foreach(mysql_fetch_array($settingsq) as $key => $pref)
{
	if (!is_numeric($key))
	{
		$setting[$key] = stripslashes($pref);
	}
}



$loggedin = FALSE;

if (isset($_SESSION['username']) && isset($_SESSION['user_password']) || isset($_POST['username']) && isset($_POST['user_password']))
{
	if (isset($_POST['login_submit']))
	{
		$loginun = $_POST['username'];
		$loginpw = $_POST['user_password'];
	}else{
		$loginun = $_SESSION['username'];
		$loginpw = $_SESSION['user_password'];
	}
	$hash = md5($loginun.$loginpw);
	$selectuser = mysql_query("SELECT * FROM users WHERE md5_hash='$hash'");
	if (mysql_num_rows($selectuser)==1)
	{
		$_SESSION['username'] = $loginun;
		$_SESSION['user_password'] = $loginpw;
		$userdata = mysql_fetch_array($selectuser);
		$loginun = $userdata['username'];
		$user_level = $userdata['user_level'];
		$user_id = $userdata['id'];
		$loggedin = TRUE;
	}else{
		session_destroy();
		$loggedin = FALSE;
	}
}



//clean temp dir

$dir = ".\\temp\\";
$files = glob($dir."*");
if ($files != "")
{
	foreach (glob($dir."*") as $filename)
	{
		$tmptime = explode("_",$filename);
		$tmptime = $tmptime['1'];
		$tmptime = ereg_replace(".ini","",$tmptime);
		$tmp = time() - 100;
		if ($tmp > $tmptime)
		{
			if (!unlink($filename) && isset($user_level))
				echo "Datei konnte nicht gel&ouml;scht werden ".$filename;
		}
	}
}


function table($title,$width="90%")
{
	if (isset($_GET['page']))
		$page = $_GET['page'];
	else
		$page = "main";

	if ($page=="admin" && strstr($title,"Administration"))
	{
		$title = ereg_replace("Administration", "<a href='index.php?page=admin'>Administration</a>", $title);
		$title = ereg_replace("Settings", "<a href='index.php?page=admin&m=settings'>Settings</a>", $title);
		$title = ereg_replace("Servers", "<a href='index.php?page=admin&m=servers'>Servers</a>", $title);
		$title = ereg_replace("Users", "<a href='index.php?page=admin&m=users'>Users</a>", $title);
		$title = ereg_replace("Headlines", "<a href='index.php?page=admin&m=headlines'>Headlines</a>", $title);
		$title = ereg_replace("Permissions", "<a href='index.php?page=admin&m=permissions'>Permissions</a>", $title);

	}else{
		$title = ereg_replace("Servers", "<a href='index.php?page=servers'>Servers</a>", $title);
		$title = ereg_replace("Accounts", "<a href='index.php?page=accounts'>Accounts</a>", $title);

	}

?>
				<table border="1" width="<?=$width?>" style="border:1px solid #A0A0A0; border-collapse: collapse" bordercolor="#808080">
					<tr>
						<td style="padding: 6px;" bgcolor="#F7F7F7" align="left" valign="top">
						 <font color="#FF9D3C"><?=$title?></font>
						</td>
					</tr>
					<tr>
						<td style="padding: 18px;">
<?PHP
}

function closetable()
{
?>
						</td>
					</tr>
				</table>
<?PHP
}
if (isset($_GET['action']) && $_GET['action'] == "logout")
{
	$loggedin = FALSE;
	session_destroy();
}


?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta name="description" content="Der Shoutcast Admin Panel ist ein webbasierendes Admin Kontrollzentrum um einen Radioserver basierend auf Shoutcast zu steuern. Funktioniert ohne vorinstallierten Shoutcast Server auf Windows und Linux Server.">
<meta name="keywords" content="WallCity-Server, WallCity, Shoutcast, Admin, Panel, Server, Admin Panel, WinAmp, djcrackhome">
<meta name="copyright" content="Copyright 2008 - Wallcity-Server ">
<meta name="author" content="djcrackhome">
<meta name="Charset" content="UTF-8">
<meta name="Distribution" content="Global">
<meta name="Rating" content="General">
<meta name="Robots" content="INDEX,FOLLOW">
<meta name="Revisit-after" content="31 Days">
<title><?=$setting['page_title']?></title>
<script language="javascript" src="system/progressbar.js"></script>
<link href="system/style.css" rel="stylesheet" type="text/css" />
</head>
<body>
<div id="container">
	<!-- header -->
    <div id="header">
    	<div id="logo"><a href="index.php">SHOUTCAST | ADMIN PANEL</a></div>
<div id="menu">
        	<ul>
              <li><a href="index.php">Home</a></li>
              <li><a href="index.php?page=contact">Kontakt</a></li>
              <li><a href="index.php?page=pservers">&Ouml;ffentlich</a></li>
              <li><?php if ($loggedin == TRUE){
						echo "

				<a href=\"index.php?page=servers\">Server</a>
							";
			
							$servers = mysql_query("SELECT * FROM servers WHERE owner='$loginun'");
							$i = 0;
							echo "";
							while($data = mysql_fetch_array($servers))
							{
								$i++;
							}
					}else{
						echo "<a href=\"index.php?page=login\">Server</a>";}?></li>
              <li><?php if ($loggedin == TRUE)
					echo "
				<a href=\"index.php?page=account\">Mein Konto</a>";?></li>
                <?PHP
			if ($loggedin == TRUE)
			{
				if ($user_level == "Administrator" || $user_level == "Super Administrator")
				{
					?>
              <li><a href="index.php?page=admin">Admin</a></li>
              <?PHP
				}
			}

			if ($loggedin == TRUE)
			{?>
            <li><a href="index.php?page=login&action=logout">Abmelden</a></li>
            	<?PHP }
			?>             

      </ul>
      </div>
  </div>
    <!--end header -->
    <!-- main -->
    <div id="main">
    	<div id="content">

   	    <?PHP if(!include("pages/".$page.".php"))
							{
								table("Achtung!");
								echo "Die Seite existiert nicht!"; 
								closetable();
							}
						?>

   	  </div>
    </div>
    <div id="footer">
    <div id="left_footer">&copy; Copyright 2008 | Wallcityserver | shoutcast admin panel | Version 1.2</div>
    <div id="right_footer"><?=$setting['footer']?></div>
    </div>
</div>
</body>
</html>
