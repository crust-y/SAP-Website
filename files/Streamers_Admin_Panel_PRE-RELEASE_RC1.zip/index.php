<?php
//	Streamers Admin Panel 3.2
//
//	Developer:
//	Main Coding: djcrackhome [Sebastian Graebner]
//	Thanks to all VIP Users for their support and all translators, and a special thanks to:
//	Raimund Barendt, resh [Mathias Simon], peaceman2305, hansy [Rico Reinheckel], Largo [Michael Savino] 
//
//	License:
//	Creative Commons Attribution-ShareAlike 3.0 Unported License
//		This work is licensed under the Creative Commons Attribution-ShareAlike 3.0 Unported License.
//		To view a copy of this license, visit http://creativecommons.org/licenses/by-sa/3.0/ or
//		send a letter to Creative Commons, 171 Second Street, Suite 300, San Francisco, California, 94105, USA.
//
//	URL:		http://www.streamerspanel.com
//	SUPPORT:	http://support.streamerspanel.com
//	MAIL:		info@streamerspanel.com
///////////////////////////////////////////////
//
//	FILENAME: ./index.php
//

error_reporting(0);
ini_set('session.use_only_cookies', '1');
session_start();
$_SESSION['security_session_captcha_rand'] = rand(10000,99999);
$usermessage_gre = array();
$usermessage_red = array();
if (!require_once(dirname(__FILE__)."/include/database.php")) die("database.php could not be loaded!");
if ($config_mysql_host == "" || !isset($config_mysql_host)) header ("Location: ./install/install.php");
$establish_db_connect = mysql_connect($config_mysql_host, $config_mysql_username, $config_mysql_password) or die ("database could not be connected");
$establish_db_connect_selection = mysql_select_db($config_mysql_database) or die ("database could not be selected");
$language_request_query = mysql_query("SELECT system_lang FROM internal_system_db_mainsetting WHERE id='0'");
$language_request_result = mysql_result($language_request_query,0);
$language_donwload_perm = mysql_query("SELECT system_premium FROM internal_system_db_mainsetting WHERE id='0'");
if (($_GET['download']=="latest_win_tool") && (mysql_result($language_donwload_perm,0)=="1")) {
	$download_cloud_server_number=rand(1,9);
	header('Location: http://s'.$download_cloud_server_number.'.streamerspanel.com/'.base64_decode("cHVibGljL1dhbGxDaXR5U2VydmVyX1NDX0FkbWluX01VTFRJXzNfMS56aXA=").'');
	if(ini_get('zlib.output_compression')) ini_set('zlib.output_compression', 'Off');
	header("Pragma: public");
	header("Expires: 0");
	header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
	header("Cache-Control: private",false);
	header("Content-Type: \"application/zip\"");
	header("Content-Disposition: attachment; filename=\"".basename('http://s'.$download_cloud_server_number.'.streamerspanel.com/'.base64_decode("cHVibGljL1dhbGxDaXR5U2VydmVyX1NDX0FkbWluX01VTFRJXzNfMS56aXA=").'')."\";" );
	header("Content-Transfer-Encoding: binary");
	header("Content-Length: ".filesize('http://s'.$download_cloud_server_number.'.streamerspanel.com/'.base64_decode("cHVibGljL1dhbGxDaXR5U2VydmVyX1NDX0FkbWluX01VTFRJXzNfMS56aXA=").''));
	readfile("http://s".$download_cloud_server_number.".streamerspanel.com/".base64_decode('cHVibGljL1dhbGxDaXR5U2VydmVyX1NDX0FkbWluX01VTFRJXzNfMS56aXA=')."");
	exit();
}
/*
if ($_GET['system_login']=="serverscan") {
	$internal_system_scan_query=mysql_query("SELECT * FROM internal_system_db_servers ORDER BY id");
	while($internal_system_scan_data=mysql_fetch_array($internal_system_scan_query)){
		$internal_system_scan_fsockopen = @fsockopen ("localhost", $internal_system_scan_data["portbase"], &$errno, &$errstr, 5);
		if ($internal_system_scan_fsockopen) {
			fputs($internal_system_scan_fsockopen, "GET /7.html HTTP/1.0\r\nUser-Agent: XML Getter (Mozilla Compatible)\r\n\r\n");
			while(!feof($internal_system_scan_fsockopen))
			$internal_system_scan_replace .= fgets($internal_system_scan_fsockopen, 2000);
			fclose($internal_system_scan_fsockopen);
			$internal_system_scan_replace = str_replace("<body>", "", $internal_system_scan_replace);
			$internal_system_scan_replace = str_replace("</body>", ",", $internal_system_scan_replace);
			$internal_system_scan_val = explode(",", $internal_system_scan_replace);
			if($internal_system_scan_val[1]==1) {
				$internal_system_scan_query=mysql_query("SELECT bitrate FROM internal_system_db_servers WHERE id='".mysql_real_escape_string($internal_system_scan_data["id"])."'");
				if (mysql_result($internal_system_scan_query,0)<($internal_system_scan_val[5]*1000)) {
					$internal_system_scan_violate_stop = mysql_query("SELECT system_stop FROM internal_system_db_mainsetting WHERE id='0'");
					if (mysql_result($internal_system_scan_violate_stop,0)=="1") {
						internal_function_server_kick($internal_system_scan_data["id"], $internal_system_scan_data["owner"]);
						internal_function_sctrans_stop($internal_system_scan_data["id"], $internal_system_scan_data["owner"]);
						internal_function_shoutcast_stop($internal_system_scan_data["id"], $internal_system_scan_data["owner"]);
						internal_function_mail("bitrate", $internal_system_scan_data["id"]);
					}
				}
			}
			else {
				$internal_system_scan_start_query = mysql_query("SELECT system_start FROM internal_system_db_mainsetting WHERE id='0'");
				if (mysql_result($internal_system_scan_start_query,0)=="1") {
					$internal_system_scan_start_autopid = mysql_query("SELECT autopid FROM internal_system_db_servers WHERE id='".$internal_system_scan_data["id"]."");
					if (mysql_result($internal_system_scan_start_autopid,0)!="0") {
						$internal_system_scan_violate_stop = mysql_query("SELECT start_play FROM internal_system_db_servers WHERE id='".$internal_system_scan_data["id"]."'");
						internal_function_sctrans_start($internal_system_scan_data["id"], mysql_result($internal_system_scan_violate_stop,0), $internal_system_scan_data["owner"]);
					}
				}
			}
		}
		else {
			$internal_system_scan_start_off_query = mysql_query("SELECT system_start FROM internal_system_db_mainsetting WHERE id='0'");
			if (mysql_result($internal_system_scan_start_off_query,0)=="1") {
				$internal_system_scan_start_pid = mysql_query("SELECT pid FROM internal_system_db_servers WHERE id='".$internal_system_scan_data["id"]."'");
				if (mysql_result($internal_system_scan_start_pid,0)!="0")
					internal_function_shoutcast_start($internal_system_scan_data["id"], $internal_system_scan_data["owner"]);
				$internal_system_scan_start_autopid = mysql_query("SELECT autopid FROM internal_system_db_servers WHERE id='".$internal_system_scan_data["id"]."'");
				if (mysql_result($internal_system_scan_start_autopid,0)!="0") {
					$internal_system_scan_start_playlist = mysql_query("SELECT start_play FROM internal_system_db_servers WHERE id='".$internal_system_scan_data["id"]."'");
					internal_function_sctrans_start($internal_system_scan_data["id"], mysql_result($internal_system_scan_start_playlist,0), $internal_system_scan_data["owner"]);
				}
			}
		}
	}
	die();
}
*/
if (!is_file(dirname(__FILE__)."/include/languages/".$language_request_result.".php")) {
	$usermessage_red[] = "<h2>The language file could not be found, English is the default language!</h2>";
	$language_request_result = "english";
	if (!is_file(dirname(__FILE__)."/include/languages/english.php")) die("Language file could not be loaded!");
}
include_once (dirname(__FILE__)."/include/languages/".$language_request_result.".php");
$internal_captcha_query = mysql_query("SELECT system_captcha FROM internal_system_db_mainsetting WHERE id='0'");
$internal_captcha_result = mysql_result($internal_captcha_query,0);
$internal_systemtitle_query = mysql_query("SELECT system_title FROM internal_system_db_mainsetting WHERE id='0'");
if (isset($_GET['system_login'])) {
	if (preg_match("!^[a-z0-9]{32}$!", $_GET['system_login'])) {
		switch ($_GET['system_login']) {
			case md5(md5("data").date("H:i").$_SERVER['REMOTE_ADDR']):
				$usermessage_red[] = "<h2>".$language_message[1]."</h2>";
				break;
			case md5(md5("captcha").date("H:i").$_SERVER['REMOTE_ADDR']):
				$usermessage_red[] = "<h2>".$language_message[2]."</h2>";
				break;
			case md5(md5("logout").date("H:i").$_SERVER['REMOTE_ADDR']):
				$usermessage_gre[] = "<h2>".$language_message[3]."</h2>";
				break;
			case md5(md5("access").date("H:i").$_SERVER['REMOTE_ADDR']):
				$usermessage_red[] = "<h2>".$language_message[4]."</h2>";
				break;
		}
	}
}
if (isset($_SESSION['security_session_username']) && isset($_SESSION['security_session_password'])) {
	$security_check_login_username = $_SESSION['security_session_username'];
	$security_check_login_password = $_SESSION['security_session_password'];
	$security_check_user_check_query = mysql_query("SELECT * FROM internal_system_db_users WHERE md5_hash='".md5(mysql_real_escape_string(trim($security_check_login_username)).mysql_real_escape_string(trim($security_check_login_password)))."' AND username='".mysql_real_escape_string(trim($security_check_login_username))."'");
	if (mysql_num_rows($security_check_user_check_query)==1) header('Location: content.php');
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" dir="ltr">

<head>
	<title>Streamers Admin Panel 3 - <?php echo $language_message[5]; ?></title>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<link rel="stylesheet" type="text/css" href="./include/css/framework.css" />
	<link rel="icon" href="./images/favicon.ico" type="image/x-icon" />
	<link rel="shortcut icon" href="./images/favicon.ico" type="image/x-icon" />
    <!-- [if lt IE 9]>
   		<style type="text/css">
			input.loginfield {
				padding: 9px 6px 0px 6px !important;
				height: 24px !important;
				width: 161px !important;
			}
		</style>
	<![endif]-->
</head>

<body>
<div id="container">
	<div id="header_top">
		<div class="header logo_login">
			<a href="index.php" title=""><img src="./images/logo.png" alt="" /></a>
		</div>
	</div>
	<div id="primary_login">
		<?php
		if(count($usermessage_red) > 0) {
			$usermessage_red_list=NULL;
			foreach($usermessage_red as $usermessage_red_cont) {
				$usermessage_red_list.="<div class=\"error_log\">".$usermessage_red_cont."</div>";
				echo ($usermessage_red_list);
			}
		}
		if(count($usermessage_gre) > 0) {
			$usermessage_gre_list=NULL;
			foreach($usermessage_gre as $usermessage_gre_cont) {
				$usermessage_gre_list.="<div class=\"correct_log\">".$usermessage_gre_cont."</div>";
				echo ($usermessage_gre_list);
			}
		}
		echo "\n";
		?>
		<div id="content">
			<div class="box">
				<h2><?php echo $language_message[6]; ?></h2>
				<p><?php echo $language_message[7]; ?></p>
				<form method="post" action="content.php<?php if (isset($_GET['redir'])) echo "?include=".htmlspecialchars(trim(base64_decode($_GET['redir'])));?>">
					<fieldset>
						<legend><?php echo $language_message[8]; ?></legend>
						<div class="input_field">
							<label><?php echo $language_message[9]; ?></label>
							<input class="loginfield" name="index_username" type="text" />
							<span class="field_desc"><?php echo $language_message[10]; ?></span>
						</div>
						<div class="input_field">
							<label><?php echo $language_message[11]; ?></label>
							<input class="loginfield" name="index_user_password" type="password" />
							<span class="field_desc"><?php echo $language_message[12]; ?></span>
						</div>
                        <?php
						if ($internal_captcha_result== "1") {
						?>
						<div class="input_field">
							<label><?php echo $language_message[13]; ?></label>
							<input class="loginfield" name="index_security_captcha_field" type="text" maxlength="5" />
							<span class="field_desc"><span class="captchaspan"><img class="field_desc" alt="" src="./images/captcha/code.php" /></span></span>
						</div>
                        <?php }?>
						<center>
							<input class="loginsubmit" type="submit" name="index_login_submit" value="<?php echo $language_message[14]; ?>" />
							<input class="loginsubmit" type="reset" value="<?php echo $language_message[15]; ?>" />
						</center>
					</fieldset>
				</form>
			</div>
		</div>
	</div>
	<div class="clear"></div>
	<?php // DO NOT CHANGE this content of the footer, this is a license requirement, otherwise you would violate the program license, this could be reported!?>
	<div id="footer">
		<p><?php echo htmlspecialchars(mysql_result($internal_systemtitle_query,0)); ?> | djcrackhome | <a href="http://www.streamerspanel.com">http://www.streamerspanel.com</a> | <a href="http://www.nagualmedia.de/">Design by Zephon</a> | <?php echo $language_message[0];?></p>
	</div>
	<?php // END OF FOOTER ?>
</div>
</body>

</html>
<?php
mysql_close($establish_db_connect);
?>