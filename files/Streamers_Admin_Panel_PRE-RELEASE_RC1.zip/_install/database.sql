-- 
-- Tabellenstruktur für Tabelle `internal_system_db_mainsetting`
-- 

CREATE TABLE `internal_system_db_mainsetting` (
  `id` int(11) NOT NULL DEFAULT '0',
  `system_title` varchar(50) NOT NULL,
  `system_slogan` varchar(50) NOT NULL,
  `system_limit` int(11) NOT NULL DEFAULT '10',
  `system_host` varchar(100) NOT NULL DEFAULT '192.168.0.1',
  `system_dir` varchar(100) NOT NULL,
  `system_contact_email` varchar(1) DEFAULT NULL,
  `system_contact_email_adress` varchar(255) DEFAULT NULL,
  `system_logourl` varchar(256) DEFAULT NULL,
  `system_scs_config` varchar(1) NOT NULL,
  `system_adj_config` varchar(1) NOT NULL,
  `system_premium` varchar(1) DEFAULT NULL,
  `system_win` varchar(1) DEFAULT NULL,
  `system_php_mp3` varchar(50) NOT NULL DEFAULT '10',
  `system_php_exe` varchar(50) NOT NULL DEFAULT '250',
  `system_update` varchar(1) NOT NULL DEFAULT '1',
  `system_news` varchar(1) DEFAULT NULL,
  `system_captcha` varchar(1) NOT NULL DEFAULT '1',
  `system_connection_type` varchar(5) NOT NULL,
  `system_ssh_user` varchar(256) NOT NULL,
  `system_ssh_pass` varchar(256) NOT NULL,
  `system_ssh_port` varchar(11) NOT NULL DEFAULT '22',
  `system_lang` varchar(256) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Daten für Tabelle `internal_system_db_mainsetting`
-- 

INSERT INTO `internal_system_db_mainsetting` (`id`, `system_title`, `system_slogan`, `system_limit`, `system_host`, `system_dir`, `system_contact_email`, `system_contact_email_adress`, `system_logourl`, `system_scs_config`, `system_adj_config`, `system_premium`, `system_win`, `system_php_mp3`, `system_php_exe`, `system_update`, `system_news`, `system_captcha`, `system_connection_type`, `system_ssh_user`, `system_ssh_pass`, `system_ssh_port`, `system_lang`) VALUES 
(0, 'Streamers Admin Panel', 'Demopanel', 10, '____URL_____', '____FULLPATH_____', '1', '____EMAIL_____', '', '1', '0', '1', '', '0', '230', '1', '1', '1', 'bash', '', '', '', 'german');

-- --------------------------------------------------------

-- 
-- Tabellenstruktur für Tabelle `internal_system_db_notices`
-- 

CREATE TABLE `internal_system_db_notices` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL DEFAULT '',
  `reason` varchar(100) NOT NULL DEFAULT '',
  `message` varchar(10240) NOT NULL,
  `ip` varchar(100) NOT NULL DEFAULT '',
  `time` varchar(100) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=111 ;

-- 
-- Daten für Tabelle `internal_system_db_notices`
-- 


-- --------------------------------------------------------

-- 
-- Tabellenstruktur für Tabelle `internal_system_db_servers`
-- 

CREATE TABLE `internal_system_db_servers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `owner` varchar(150) NOT NULL,
  `maxuser` varchar(30) NOT NULL,
  `portbase` int(11) NOT NULL DEFAULT '0',
  `bitrate` varchar(30) NOT NULL,
  `adminpassword` varchar(150) NOT NULL,
  `password` varchar(150) NOT NULL,
  `apivalue` varchar(150) NOT NULL,
  `logfile` varchar(255) NOT NULL DEFAULT '../../logs/sc_{port}.log',
  `realtime` varchar(1) NOT NULL DEFAULT '1',
  `screenlog` varchar(1) NOT NULL DEFAULT '0',
  `showlastsongs` varchar(50) NOT NULL DEFAULT '10',
  `tchlog` varchar(10) NOT NULL DEFAULT 'Yes',
  `weblog` varchar(10) NOT NULL DEFAULT 'no',
  `w3cenable` varchar(10) NOT NULL DEFAULT 'Yes',
  `w3clog` varchar(255) NOT NULL DEFAULT 'sc_w3c.log',
  `srcip` varchar(50) NOT NULL DEFAULT 'ANY',
  `destip` varchar(50) NOT NULL DEFAULT 'ANY',
  `yport` varchar(10) NOT NULL DEFAULT '80',
  `namelookups` varchar(1) NOT NULL DEFAULT '0',
  `relayport` varchar(10) NOT NULL DEFAULT '0',
  `relayserver` varchar(155) NOT NULL DEFAULT 'empty',
  `autodumpusers` varchar(1) NOT NULL DEFAULT '0',
  `autodumpsourcetime` varchar(30) NOT NULL DEFAULT '30',
  `contentdir` varchar(255) NOT NULL,
  `introfile` varchar(255) NOT NULL,
  `backupfile` varchar(255) NOT NULL,
  `titleformat` varchar(150) NOT NULL,
  `publicserver` varchar(10) NOT NULL DEFAULT 'default',
  `allowrelay` varchar(10) NOT NULL DEFAULT 'Yes',
  `allowpublicrelay` varchar(10) NOT NULL DEFAULT 'Yes',
  `metainterval` varchar(50) NOT NULL DEFAULT '32768',
  `pid` varchar(100) NOT NULL,
  `autopid` varchar(100) NOT NULL,
  `webspace` varchar(100) NOT NULL,
  `serverip` varchar(100) NOT NULL,
  `serverport` varchar(100) NOT NULL,
  `streamtitle` varchar(255) NOT NULL DEFAULT 'AutoDJ',
  `streamurl` varchar(255) NOT NULL DEFAULT 'http://www.domain.com/website/',
  `shuffle` int(1) NOT NULL DEFAULT '1',
  `samplerate` varchar(100) NOT NULL DEFAULT '44100',
  `channels` int(1) NOT NULL DEFAULT '2',
  `genre` varchar(100) NOT NULL DEFAULT 'Pop, Techno',
  `quality` int(1) NOT NULL DEFAULT '1',
  `crossfademode` varchar(100) NOT NULL DEFAULT '1',
  `crossfadelength` varchar(100) NOT NULL DEFAULT '8000',
  `useid3` int(1) NOT NULL DEFAULT '1',
  `public` int(1) NOT NULL DEFAULT '1',
  `aim` varchar(100) NOT NULL,
  `icq` varchar(100) NOT NULL,
  `irc` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=189 ;

-- 

-- 
-- Tabellenstruktur für Tabelle `internal_system_db_users`
-- 

CREATE TABLE `internal_system_db_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL DEFAULT '',
  `md5_hash` varchar(100) NOT NULL DEFAULT '',
  `user_level` varchar(100) NOT NULL DEFAULT '',
  `user_email` varchar(200) NOT NULL DEFAULT '',
  `firstname` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  `dateofbirth` varchar(11) NOT NULL,
  `street` varchar(200) NOT NULL,
  `city` varchar(200) NOT NULL,
  `zipcode` varchar(20) NOT NULL,
  `state` varchar(100) NOT NULL,
  `country` varchar(100) NOT NULL,
  `phone` varchar(100) NOT NULL,
  `wwwurl` varchar(200) NOT NULL,
  `facebook` varchar(100) NOT NULL,
  `twitter` varchar(100) NOT NULL,
  `timestamp` varchar(25) NOT NULL,
  `secretkey` varchar(25) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=30 ;

-- 
-- Daten für Tabelle `internal_system_db_users`
-- 

INSERT INTO `internal_system_db_users` (`id`, `username`, `md5_hash`, `user_level`, `user_email`, `firstname`, `lastname`, `dateofbirth`, `street`, `city`, `zipcode`, `state`, `country`, `phone`, `wwwurl`, `facebook`, `timestamp`, `secretkey`) VALUES 
(1, 'admin', '___MD5_HASH___', 'Super Administrator', '___ADMINEMAIL___', '', '', '', '', '', '', '', '', '', '', '', '', '');
