<?PHP
//	Streamers Admin Panel 3.2
//
//	Developer:
//	Main Coding: djcrackhome [Sebastian Graebner]
//	Thanks 2 Raimund Barendt, resh [Mathias Simon], hansy [Rico Reinheckel], Largo [Michael Savino] 
//
//	License:
//	Creative Commons Attribution-ShareAlike 3.0 Unported License
//		This work is licensed under the Creative Commons Attribution-ShareAlike 3.0 Unported License.
//		To view a copy of this license, visit http://creativecommons.org/licenses/by-sa/3.0/ or
//		send a letter to Creative Commons, 171 Second Street, Suite 300, San Francisco, California, 94105, USA.
//
//	URL:		http://www.streamerspanel.com
//	SUPPORT:	http://support.streamerspanel.com
//	MAIL:		info@streamerspanel.com
///////////////////////////////////////////////
//
//	FILENAME: ./include/admradio_bottom.php
//

error_reporting(0);
if ((!defined("_include_security")) || (!preg_match("/content.php/i", $_SERVER['PHP_SELF']))) {
    header('Location: ./../index.php?system_login='.md5(md5("access").date("H:i").$_SERVER['REMOTE_ADDR']));
	die();
}
$internal_listing_limit = mysql_real_escape_string(trim($internal_setting['system_limit']));
if (!isset($_GET['listing_query'])) $listing_query = 0;
else $listing_query = $_GET['listing_query'] * $internal_listing_limit;
$listing_query_limitery = $listing_query + $internal_listing_limit;
$listing_sql_query = mysql_query("SELECT * FROM internal_system_db_servers ORDER BY id ASC LIMIT $listing_query,$internal_listing_limit");
?>
<div id="content">
	<div class="box">
		<h2><?php echo $language_message[107];?></h2>
		<div class="contact_top_menu">
			<div class="tool_top_menu">
				<div class="main_shorttool"><?php echo $language_message[108];?></div>
				<div class="main_righttool">
					<h2><?php echo $language_message[109];?></h2>
					<p><?php echo $language_message[110];?></p>
					<p>&nbsp;</p>
				</div>
			</div>
			<table cellspacing="0" cellpadding="0">
				<thead>
					<tr>
						<th><?php echo $language_message[111];?></th>
						<th><?php echo $language_message[112];?></th>
						<th><?php echo $language_message[113];?></th>
						<th><a class="selector" href="content.php?include=admradio&system_action=new_server"><?php echo $language_message[114];?></a></th>
					</tr>
				</thead>
				<tbody>
					<?php
					if (mysql_num_rows($listing_sql_query)==0) {
						echo "<tr>
							<td colspan=\"5\">".$language_message[115]."</td>
							</tr>";
					}
					else {
						while($internal_admradio_sqlfetch = mysql_fetch_array($listing_sql_query)) {
							$internal_space_owner = mysql_query("SELECT * FROM internal_system_db_users WHERE username='".$internal_admradio_sqlfetch['owner']."'");
							
      		                echo '<tr>
                        		<td><a href="http://'.$internal_setting['system_host'].':'.$internal_admradio_sqlfetch['portbase'].'/" target="_blank">'.$internal_admradio_sqlfetch['owner'].'</a></td>
      		                  	<td><a href="http://'.$internal_setting['system_host'].':'.$internal_admradio_sqlfetch['portbase'].'/" target="_blank">'.$internal_admradio_sqlfetch['portbase'].'</a></td>
            	            	<td><div class="space_show" style="background-position:'; 	
							$negative_background_pos = ((internal_folder_space($internal_setting['system_dir']."/clients/".mysql_result($internal_space_owner,0)."/".$internal_admradio_sqlfetch['portbase']."/uploads/audio/")+internal_folder_space($internal_setting['system_dir']."/clients/".mysql_result($internal_space_owner,0)."/".$internal_admradio_sqlfetch['portbase']."/uploads/video/"))/$internal_admradio_sqlfetch['webspace'])*120;
							echo '-'.$negative_background_pos.'px 0px;"></div></td>
								<td><a class="delete" href="content.php?include=admradio&edit='.$internal_admradio_sqlfetch["id"].'&system_action=delete">'.$language_message[116].'</a><a class="selector" href="content.php?include=admradio&edit='.$internal_admradio_sqlfetch["id"].'&system_action=restart">'.$language_message[117].'</a><a class="edit" href="content.php?include=admradio&edit='.$internal_admradio_sqlfetch["id"].'&system_action=update">'.$language_message[118].'</a></td>
								</tr>';
						}
					}
					?>
				</tbody>
			</table>
				<?php
					if (mysql_num_rows($listing_sql_query)!=0) {
						echo "<ul class=\"paginator\">";
					$listing_limit_page = mysql_num_rows(mysql_query("SELECT * FROM internal_system_db_servers"));
					$i = 0;
					while($listing_limit_page > "0") { echo "<li><a href=\"content.php?include=admradio"; if ($_GET['system_action'] == "new_server") echo "&system_action=new_server"; if ($_GET['system_action'] == "update") echo "&system_action=update"; if (is_numeric($_GET['edit'])) echo "&edit=".htmlspecialchars($_GET['edit']); echo "&listing_query="; if (($listing_query / $internal_listing_limit) == $i) { echo ""; } echo "$i\">$i</a></li>"; $i++; $listing_limit_page -= $internal_listing_limit; }
						echo "</ul>";
					}
					?>
			<?php
			if (($_GET['system_action'] == "new_server") || (($_GET['system_action'] == "update") && (mysql_num_rows($internal_data_update)!=0))) {
			?>
			<br />
			<h2><?php if ($_GET['system_action'] == "new_server") echo $language_message[119]; else echo $language_message[120];?></h2>
			<form method="post" action="content.php?include=admradio&<?php if ($_GET['system_action'] == "new_server") echo "system_action=new_server"; elseif ($_GET['system_action'] == "update") echo '&edit='.$_GET['edit'].'&system_action=update'; ?>">
			<?php 
			if ($_GET['system_action'] == "update") {
				while($updateget_var = mysql_fetch_array($internal_data_update)) { $updateget_var_t_owner = $updateget_var['owner']; $updateget_var_t_adminpassword = $updateget_var['adminpassword']; $updateget_var_t_password = $updateget_var['password']; $updateget_var_t_portbase = $updateget_var['portbase']; $updateget_var_t_maxuser = $updateget_var['maxuser']; $updateget_var_t_bitrate = $updateget_var['bitrate']; $updateget_var_t_autopid = $updateget_var['autopid']; $updateget_var_t_logfile = $updateget_var['logfile']; $updateget_var_t_screenlog = $updateget_var['screenlog']; $updateget_var_t_realtime = $updateget_var['realtime']; $updateget_var_t_showlastsongs = $updateget_var['showlastsongs']; $updateget_var_t_tchlog = $updateget_var['tchlog']; $updateget_var_t_weblog = $updateget_var['weblog']; $updateget_var_t_webspace = $updateget_var['webspace']; $updateget_var_t_w3clog = $updateget_var['w3clog']; $updateget_var_t_w3cenable = $updateget_var['w3cenable']; $updateget_var_t_srcip = $updateget_var['srcip']; $updateget_var_t_destip = $updateget_var['destip']; $updateget_var_t_yport = $updateget_var['yport']; $updateget_var_t_relayport = $updateget_var['relayport']; $updateget_var_t_namelookups = $updateget_var['namelookups']; $updateget_var_t_relayserver = $updateget_var['relayserver']; $updateget_var_t_autodumpusers = $updateget_var['autodumpusers']; $updateget_var_t_autodumpsourcetime = $updateget_var['autodumpsourcetime']; $updateget_var_t_contentdir = $updateget_var['contentdir']; $updateget_var_t_introfile = $updateget_var['introfile']; $updateget_var_t_backupfile = $updateget_var['backupfile']; $updateget_var_t_titleformat = $updateget_var['titleformat']; $updateget_var_t_publicserver = $updateget_var['publicserver']; $updateget_var_t_metainterval = $updateget_var['metainterval']; $updateget_var_t_allowrelay = $updateget_var['allowrelay']; $updateget_var_t_allowpublicrelay = $updateget_var['allowpublicrelay'];
					}
				}
				$internal_id_owner = mysql_query("SELECT id FROM internal_system_db_users WHERE username='".mysql_real_escape_string($updateget_var_t_owner)."'");
				?>
				<fieldset>
					<legend><?php echo $language_message[121];?></legend>
					<div class="input_field">
						<label for="a"><?php echo $language_message[122];?></label>
						<?php
						$internal_users_query = mysql_query("SELECT * FROM internal_system_db_users");
						echo '<select name="owner" class="formselect_loca"';
						if ($_GET['system_action'] == "update") echo ' disabled="disabled"';
						echo '>';
						while($internal_users_query_dataset = mysql_fetch_array($internal_users_query)) {
							echo "<option";
							if ($_GET['system_action'] == "update") {
								if ($internal_users_query_dataset['username'] == $updateget_var_t_owner)
									echo " selected"; 
							}
							else {
							if ($internal_users_query_dataset['username'] == $internal_user_name)
									echo " selected"; 
							}
							echo ">".htmlspecialchars($internal_users_query_dataset['username'])."</option>\n";
						}
						echo '</select>';
						?>                    
						<span class="field_desc"><?php echo $language_message[123];?></span>
					</div>
					<div class="input_field">
						<label for="a"><?php echo $language_message[124];?></label>
						<input class="mediumfield" name="adminpassword" type="text" value="<?php if ($_GET['system_action'] == "update") echo htmlspecialchars($updateget_var_t_adminpassword); else echo $language_message[125];?>" />
					<span class="field_desc"><?php echo $language_message[126];?></span>
				</div>
				<div class="input_field">
					<label for="a"><?php echo $language_message[127];?></label>
					<input class="mediumfield" name="password" type="text" value="<?php if ($_GET['system_action'] == "update") echo htmlspecialchars($updateget_var_t_password); else echo $language_message[125]; ?>" />
					<span class="field_desc"><?php echo $language_message[128];?></span>
				</div>
				<div class="input_field">
					<?php
					$internal_port_request_query = mysql_query("SELECT portbase FROM internal_system_db_servers order by portbase DESC");
					if (mysql_num_rows($internal_port_request_query)>=1)
						$internal_port_up = mysql_result($internal_port_request_query,0) + 2;
					else
						$internal_port_up = "8000";
					?>
			    <label for="a"><?php echo $language_message[129];?></label>
					<input class="mediumfield" name="portbase" type="text"<?php if ($_GET['system_action'] == "update") echo ' disabled="disabled"'; ?> value="<?php if ($_GET['system_action'] == "update") echo htmlspecialchars($updateget_var_t_portbase); else echo $internal_port_up; ?>" />
					<span class="field_desc"><?php echo $language_message[130];?></span>
				</div>
				<div class="input_field">
					<label for="a"><?php echo $language_message[131];?></label>
					<input class="mediumfield" name="maxuser" type="text" value="<?php if ($_GET['system_action'] == "update") echo htmlspecialchars($updateget_var_t_maxuser); else echo "32"; ?>" />
					<span class="field_desc"><?php echo $language_message[132];?></span>
				</div>
				<div class="input_field">
					<label for="a"><?php echo $language_message[133];?></label>
                    <select class="formselect_loca" name="bitrate">
                        <option value="320000"<?php if ($updateget_var_t_bitrate=="320000") echo " selected=\"selected\"";?>>320 kbps</option>
                        <option value="256000"<?php if ($updateget_var_t_bitrate=="256000") echo " selected=\"selected\"";?>>256 kbps</option>
                        <option value="224000"<?php if ($updateget_var_t_bitrate=="224000") echo " selected=\"selected\"";?>>224 kbps</option>
                        <option value="192000"<?php if ($updateget_var_t_bitrate=="192000") echo " selected=\"selected\"";?>>192 kbps</option>
                        <option value="160000"<?php if ($updateget_var_t_bitrate=="160000") echo " selected=\"selected\"";?>>160 kbps</option>
                        <option value="128000"<?php if ($updateget_var_t_bitrate=="128000") echo " selected=\"selected\"";?>>128 kbps</option>
                        <option value="112000"<?php if ($updateget_var_t_bitrate=="112000") echo " selected=\"selected\"";?>>112 kbps</option>
                        <option value="96000"<?php if ($updateget_var_t_bitrate=="96000") echo " selected=\"selected\"";?>>96 kbps</option>
                        <option value="80000"<?php if ($updateget_var_t_bitrate=="80000") echo " selected=\"selected\"";?>>80 kbps</option>
                        <option value="64000"<?php if ($updateget_var_t_bitrate=="64000") echo " selected=\"selected\"";?>>64 kbps</option>
                        <option value="56000"<?php if ($updateget_var_t_bitrate=="56000") echo " selected=\"selected\"";?>>56 kbps</option>
                        <option value="48000"<?php if ($updateget_var_t_bitrate=="48000") echo " selected=\"selected\"";?>>48 kbps</option>
                        <option value="40000"<?php if ($updateget_var_t_bitrate=="40000") echo " selected=\"selected\"";?>>40 kbps</option>
                        <option value="32000"<?php if ($updateget_var_t_bitrate=="32000") echo " selected=\"selected\"";?>>32 kbps</option>
                    </select>
					<span class="field_desc"><?php echo $language_message[134];?></span>
				</div>
				<div class="input_field">
					<label for="a"><?php echo $language_message[135];?></label>
					<?php echo '<select name="autopid" class="formselect_loca" onchange="autodj_setup(value);"><option'; if ($updateget_var_t_autopid != "9999999") { echo ' selected="selected" value="'.htmlspecialchars($updateget_var_t_autopid).'"'; } echo '>'.$language_message[136].'</option><option value="9999999"'; if ($updateget_var_t_autopid == "9999999") { echo ' selected="selected"';} echo '>'.$language_message[137].'</option></select>';
					?>
					<span class="field_desc"><?php echo $language_message[138];?></span>
				</div>
				<div class="input_field" id="autodj_setup_id_1"<?php if ($updateget_var_t_autopid == "9999999") echo " style=\"display:none;\""; ?>>
					<label for="a"><?php echo $language_message[139];?></label>
					<input class="mediumfield" name="webspace" type="text" value="<?php if ($_GET['system_action'] == "update") echo (htmlspecialchars($updateget_var_t_webspace)/1024); else echo "20"; ?>" />
					<span class="field_desc"><?php echo $language_message[140];?></span>
				</div>
				<div class="input_field" id="view_setting_show_logfile">
			    <label for="a"><?php echo $language_message[141];?></label>
					<select class="formselect_loca" name="logfile" onchange="log_setup(value);"><option value="<?php if ($_GET['system_action'] == "update") { if (preg_match("/clients/i", $updateget_var_t_logfile)) { echo htmlspecialchars($updateget_var_t_logfile)."\" selected=\"selected"; } else { echo $internal_setting['system_dir']."clients/".mysql_result($internal_id_owner,0)."/".htmlspecialchars($updateget_var_t_portbase)."/logs/sc_log.log"; } } else { echo $internal_setting['system_dir']."clients/_id_/_port_/logs/sc_log.log"; } ?>"><?php if ($_GET['system_action'] == "update") { $updateget_var_t_logfile=preg_replace("#".$internal_setting['system_dir']."#","./", $updateget_var_t_logfile); if (preg_match("/clients/i", $updateget_var_t_logfile)) { echo htmlspecialchars($updateget_var_t_logfile); } else { echo "./clients/".mysql_result($internal_id_owner,0)."/".htmlspecialchars($updateget_var_t_portbase)."/logs/sc_log.log"; } } else { echo "./clients/_id_/_port_/logs/sc_log.log"; } ?></option><option value="/dev/null"<?php if ($_GET['system_action'] == "update") { if (!preg_match("/clients/i", $updateget_var_t_logfile)) { echo " selected=\"selected\""; } }?>><?php echo $language_message[164];?></option></select>
					<span class="field_desc"><?php echo $language_message[142];?></span>
				</div>
				<div class="input_field" id="log_setup_id_1"<?php if ($updateget_var_t_logfile=="/dev/null") echo " style=\"display:none;\""; ?>>
					<label for="a"><?php echo $language_message[143];?></label>
                    <select class="formselect_loca" name="realtime"><option value="1"<?php if ($_GET['system_action'] == "update") { if ($updateget_var_t_realtime=="1") { echo " selected=\"selected\""; } } else { echo " selected=\"selected\""; } ?>><?php echo $language_message[144];?></option><option value="0"<?php if ($_GET['system_action'] == "update") { if ($updateget_var_t_realtime=="0") { echo " selected=\"selected\""; } } ?>><?php echo $language_message[145];?></option></select>
					<span class="field_desc"><?php echo $language_message[146];?></span>
				</div>
				<div class="input_field" id="log_setup_id_2"<?php if ($updateget_var_t_logfile=="/dev/null") echo " style=\"display:none;\""; ?>>
					<label for="a"><?php echo $language_message[147];?></label>
                    <select class="formselect_loca" name="tchlog"><option value="Yes"<?php if ($_GET['system_action'] == "update") { if ($updateget_var_t_tchlog=="Yes") { echo " selected=\"selected\""; } } else { echo " selected=\"selected\""; } ?>><?php echo $language_message[148];?></option><option value="No"<?php if ($_GET['system_action'] == "update") { if ($updateget_var_t_tchlog=="No") { echo " selected=\"selected\""; } } ?>><?php echo $language_message[149];?></option></select>
					<span class="field_desc"><?php echo $language_message[150];?></span>
				</div> 
				<div class="input_field" id="log_setup_id_3"<?php if ($updateget_var_t_logfile=="/dev/null") echo " style=\"display:none;\""; ?>>
					<label for="a"><?php echo $language_message[151];?></label>
                    <select class="formselect_loca" name="weblog"><option value="Yes"<?php if ($_GET['system_action'] == "update") { if ($updateget_var_t_weblog=="Yes") { echo " selected=\"selected\""; } } ?>><?php echo $language_message[152];?></option><option value="No"<?php if ($_GET['system_action'] == "update") { if ($updateget_var_t_weblog=="No") { echo " selected=\"selected\""; }  } else { echo " selected=\"selected\""; } ?>><?php echo $language_message[153];?></option></select>
					<span class="field_desc"><?php echo $language_message[154];?></span>
				</div>
				<div class="input_field" id="log_setup_id_4"<?php if ($updateget_var_t_logfile=="/dev/null") echo " style=\"display:none;\""; ?>>
					<label for="a"><?php echo $language_message[155];?></label>
                    <select class="formselect_loca" name="screenlog"><option value="1"<?php if ($_GET['system_action'] == "update") { if ($updateget_var_t_screenlog=="1") { echo " selected=\"selected\""; } } else { echo " selected=\"selected\""; } ?>><?php echo $language_message[156];?></option><option value="0"<?php if ($_GET['system_action'] == "update") { if ($updateget_var_t_screenlog=="0") { echo " selected=\"selected\""; } } ?>><?php echo $language_message[157];?></option></select>
					<span class="field_desc"><?php echo $language_message[158];?></span>
				</div>
				<div class="input_field" id="w3c_enable">
					<label for="a"><?php echo $language_message[159];?></label>
                    <select class="formselect_loca" name="w3cenable" onchange="w3c_enable(value);"><option value="Yes"<?php if ($_GET['system_action'] == "update") { if ($updateget_var_t_w3cenable=="Yes") { echo " selected=\"selected\""; } } else { echo " selected=\"selected\""; } ?>><?php echo $language_message[160];?></option><option value="No"<?php if ($_GET['system_action'] == "update") { if ($updateget_var_t_w3cenable=="No") { echo " selected=\"selected\""; } } ?>><?php echo $language_message[161];?></option></select>
					<span class="field_desc"><?php echo $language_message[162];?></span>
				</div>
				<div class="input_field" id="view_setting_show_w3c"<?php if ($updateget_var_t_w3cenable=="No") echo " style=\"display:none;\""; ?>>
					<label for="a"><?php echo $language_message[163];?></label>
                    <select class="formselect_loca" name="w3clog"><option value="<?php 
					if ($_GET['system_action'] == "update") { if (preg_match("/clients/i", $updateget_var_t_w3clog)) { echo htmlspecialchars($updateget_var_t_w3clog)."\" selected=\"selected"; } else { echo $internal_setting['system_dir']."clients/".mysql_result($internal_id_owner,0)."/".htmlspecialchars($updateget_var_t_portbase)."/logs/w3c_log.log"; } } else { echo $internal_setting['system_dir']."clients/_id_/_port_/logs/w3c_log.log"; } ?>"><?php  if ($_GET['system_action'] == "update") { $updateget_var_t_w3clog=preg_replace("#".$internal_setting['system_dir']."#","./",$updateget_var_t_w3clog); if (preg_match("/clients/i", $updateget_var_t_w3clog)) echo htmlspecialchars($updateget_var_t_w3clog); else echo "./clients/".mysql_result($internal_id_owner,0)."/".htmlspecialchars($updateget_var_t_portbase)."/logs/w3c_log.log"; } else echo "./clients/_id_/_port_/logs/w3c_log.log"; ?></option><option value="/dev/null"<?php if ($_GET['system_action'] == "update") { if (!preg_match("/clients/i", $updateget_var_t_w3clog)) { echo " selected=\"selected\""; } }?>><?php echo $language_message[164];?></option></select>
					<span class="field_desc"><?php echo $language_message[165];?></span>
				</div>
				<div class="input_field" id="view_setting_show_lastsongs">
			    <label for="a"><?php echo $language_message[166];?></label>
					<input class="mediumfield" name="showlastsongs" type="text" value="<?php if ($_GET['system_action'] == "update") echo htmlspecialchars($updateget_var_t_showlastsongs); else echo "10";?>" />
					<span class="field_desc"><?php echo $language_message[167];?></span>
				</div>
				<div class="input_field" id="view_setting_show_src">
					<label for="a"><?php echo $language_message[168];?></label>
					<input class="mediumfield" name="srcip" type="text" value="<?php if ($_GET['system_action'] == "update") echo htmlspecialchars($updateget_var_t_srcip); else echo "ANY"; ?>" />
					<span class="field_desc"><?php echo $language_message[169];?></span>
				</div>            
				<div class="input_field" id="view_setting_show_dest">
					<label for="a"><?php echo $language_message[170];?></label>
					<input class="mediumfield" name="destip" type="text" value="<?php if ($_GET['system_action'] == "update") echo htmlspecialchars($updateget_var_t_destip); else echo "ANY"; ?>" />
					<span class="field_desc"><?php echo $language_message[171];?></span>
				</div>
               	<div class="input_field" id="view_setting_show_yport">
					<label for="a"><?php echo $language_message[172];?></label>
					<input class="mediumfield" name="yport" type="text" value="<?php if ($_GET['system_action'] == "update") echo htmlspecialchars($updateget_var_t_yport); else echo "80"; ?>" />
					<span class="field_desc"><?php echo $language_message[173];?></span>
				</div>
				<div class="input_field" id="view_setting_show_name">
					<label for="a"><?php echo $language_message[174];?></label>
                    <select class="formselect_loca" name="namelookups"><option value="1"<?php if ($_GET['system_action'] == "update") { if ($updateget_var_t_namelookups=="1") { echo " selected=\"selected\""; } } ?>><?php echo $language_message[175];?></option><option value="0"<?php if ($_GET['system_action'] == "update") { if ($updateget_var_t_namelookups=="0") { echo " selected=\"selected\""; }  } else echo " selected=\"selected\""; ?>><?php echo $language_message[176];?></option></select>
					<span class="field_desc"><?php echo $language_message[177];?></span>
				</div>                       
				<div class="input_field" id="view_setting_show_autodump">
					<label for="a"><?php echo $language_message[178];?></label>
                    <select class="formselect_loca" name="autodumpusers" onchange="setting_show_autodumpsrc(value);"><option value="1"<?php if ($_GET['system_action'] == "update") { if ($updateget_var_t_namelookups=="1") { echo " selected=\"selected\""; } } ?>><?php echo $language_message[179];?></option><option value="0"<?php if ($_GET['system_action'] == "update") { if ($updateget_var_t_namelookups=="0") { echo " selected=\"selected\""; }  } else { echo " selected=\"selected\""; } ?>><?php echo $language_message[180];?></option></select>
					<span class="field_desc"><?php echo $language_message[181];?></span>
				</div>  
				<div class="input_field" id="view_setting_show_autodumpsrc"<?php if ($updateget_var_t_namelookups=="0") echo " style=\"display:none;\""; ?>>
					<label for="a"><?php echo $language_message[182];?></label>
					<input class="mediumfield" name="autodumpsourcetime" type="text" value="<?php if ($_GET['system_action'] == "update")  echo htmlspecialchars($updateget_var_t_autodumpsourcetime); else echo "30"; ?>" />
					<span class="field_desc"><?php echo $language_message[183];?></span>
				</div>  
				<div class="input_field" id="shout_server_setup_id_21">
					<label for="a"><?php echo $language_message[184];?></label>
                    <select class="formselect_loca" name="contentdir"><option value="/dev/null"<?php if ($_GET['system_action'] == "update") { if (!preg_match("/clients/i", $updateget_var_t_contentdir)) { echo " selected=\"selected\""; } }?>><?php echo $language_message[185];?></option><option value="<?php 
					if ($_GET['system_action'] == "update") { if (preg_match("/clients/i", $updateget_var_t_contentdir)) { echo htmlspecialchars($updateget_var_t_contentdir)."\" selected=\"selected"; } else { echo $internal_setting['system_dir']."clients/".mysql_result($internal_id_owner,0)."/".htmlspecialchars($updateget_var_t_portbase)."/contentdir/"; } } else { echo $internal_setting['system_dir']."clients/_id_/_port_/contentdir/";}
					?>"><?php if ($_GET['system_action'] == "update") { $updateget_var_t_contentdir=preg_replace("#".$internal_setting['system_dir']."#","./", $updateget_var_t_contentdir); if (preg_match("/clients/i", $updateget_var_t_contentdir)) { echo htmlspecialchars($updateget_var_t_contentdir); } else { echo "./clients/".mysql_result($internal_id_owner,0)."/".htmlspecialchars($updateget_var_t_portbase)."/contentdir/"; } } else { echo "./clients/_id_/_port_/contentdir/"; } ?></option></select>
					<span class="field_desc"><?php echo $language_message[186];?></span>
				</div>      
				<div class="input_field" id="view_setting_show_intro">
					<label for="a"><?php echo $language_message[187];?></label>
                    <select class="formselect_loca" name="introfile"><option value=""<?php if (($_GET['system_action'] != "update") || ($updateget_var_t_introfile=="")) echo " selected=\"selected\"";?>><?php echo $language_message[188];?></option><option value="<?php if ($_GET['system_action'] == "update") { if (preg_match("/clients/i", $updateget_var_t_introfile)) { echo htmlspecialchars($updateget_var_t_introfile)."\" selected=\"selected"; } else { echo $internal_setting['system_dir']."clients/".mysql_result($internal_id_owner,0)."/".htmlspecialchars($updateget_var_t_portbase)."/soundfiles/intro.mp3"; } } else { echo $internal_setting['system_dir']."clients/_id_/_port_/soundfiles/intro.mp3"; } ?>"><?php if ($_GET['system_action'] == "update") { $updateget_var_t_introfile=preg_replace("#".$internal_setting['system_dir']."#","./", $updateget_var_t_introfile); if (preg_match("/clients/i", $updateget_var_t_introfile)) { echo $updateget_var_t_introfile; } else { echo "./clients/".mysql_result($internal_id_owner,0)."/".htmlspecialchars($updateget_var_t_portbase)."/soundfiles/intro.mp3"; } } else { echo "./clients/_id_/_port_/soundfiles/intro.mp3"; } ?></option></select>
					<span class="field_desc"><?php echo $language_message[189];?></span>
				</div>  
				<div class="input_field" id="view_setting_show_backup">
					<label for="a"><?php echo $language_message[190];?></label>
                    <select class="formselect_loca" name="backupfile"><option value=""<?php if (($_GET['system_action'] != "update") || ($updateget_var_t_backupfile=="")) echo " selected=\"selected\"";?>><?php echo $language_message[191];?></option><option value="<?php if ($_GET['system_action'] == "update") { if (preg_match("/clients/i", $updateget_var_t_backupfile)) { echo htmlspecialchars($updateget_var_t_backupfile)."\" selected=\"selected"; } else { echo $internal_setting['system_dir']."clients/".mysql_result($internal_id_owner,0)."/".htmlspecialchars($updateget_var_t_portbase)."/soundfiles/backup.mp3"; } } else { echo $internal_setting['system_dir']."clients/_id_/_port_/soundfiles/backup.mp3"; } ?>"><?php if ($_GET['system_action'] == "update") { $updateget_var_t_backupfile=preg_replace("#".$internal_setting['system_dir']."#","./", $updateget_var_t_backupfile); if (preg_match("/clients/i", $updateget_var_t_backupfile)) { echo $updateget_var_t_backupfile; } else { echo "./clients/".mysql_result($internal_id_owner,0)."/".htmlspecialchars($updateget_var_t_portbase)."/soundfiles/backup.mp3"; } } else { echo "./clients/_id_/_port_/soundfiles/backup.mp3"; } ?></option></select>
					<span class="field_desc"><?php echo $language_message[192];?></span>
				</div>  
				<div class="input_field">
					<label for="a"><?php echo $language_message[193];?></label>
					<input class="mediumfield" name="titleformat" type="text" value="<?php if ($_GET['system_action'] == "update") echo htmlspecialchars($updateget_var_t_titleformat); else echo "Radio Station Name: %s";?>" />
					<span class="field_desc"><?php echo $language_message[194];?></span>
				</div>  
				<div class="input_field">
					<label for="a"><?php echo $language_message[195];?></label>
                    <select class="formselect_loca" name="publicserver"><option value="always"<?php if ($_GET['system_action'] == "update") { if ($updateget_var_t_publicserver=="always") { echo ' selected="selected"'; }} else echo ' selected="selected"'; ?>><?php echo $language_message[196];?></option><option value="never"<?php if ($_GET['system_action'] == "update") { if ($updateget_var_t_publicserver=="never") { echo ' selected="selected"'; }} ?>><?php echo $language_message[197];?></option></select>
					<span class="field_desc"><?php echo $language_message[198];?></span>
				</div>
				<div class="input_field" id="yp_shoutcast_setup_id_9">
			    <label for="a"><?php echo $language_message[199];?></label>
					<input class="mediumfield" name="relayserver" type="text" value="<?php if ($_GET['system_action'] == "update") echo htmlspecialchars($updateget_var_t_relayserver);?>" />
					<span class="field_desc"><?php echo $language_message[200];?></span>
				</div>  
				<div class="input_field" id="yp_shoutcast_setup_id_8">
					<label for="a"><?php echo $language_message[201];?></label>
					<input class="mediumfield" name="relayport" type="text" value="<?php if ($_GET['system_action'] == "update") echo htmlspecialchars($updateget_var_t_relayport); else echo "0";?>" />
					<span class="field_desc"><?php echo $language_message[202];?></span>
				</div>   
				<div class="input_field" id="view_setting_show_allowpublic">
					<label for="a"><?php echo $language_message[203];?></label>
                    <select class="formselect_loca" name="allowpublicrelay"><option value="Yes"<?php if ($_GET['system_action'] == "update") { if ($updateget_var_t_allowpublicrelay=="Yes") { echo " selected=\"selected\""; } } else { echo " selected=\"selected\""; } ?>><?php echo $language_message[204];?></option><option value="No"<?php if ($_GET['system_action'] == "update") { if ($updateget_var_t_allowpublicrelay=="No") { echo " selected=\"selected\""; } } ?>><?php echo $language_message[205];?></option></select>
					<span class="field_desc"><?php echo $language_message[206];?></span>
				</div> 
				<div class="input_field" id="view_setting_show_metainterval">
					<label for="a"><?php echo $language_message[207];?></label>
					<input class="mediumfield" name="metainterval" type="text" value="<?php if ($_GET['system_action'] == "update") echo htmlspecialchars($updateget_var_t_metainterval); else echo "32768"; ?>" />
					<span class="field_desc"><?php echo $language_message[208];?></span>
				</div>
				<input class="submit" type="submit" name="submit" value="<?php echo $language_message[209];?>" />
			</fieldset>
			</form>
			<?php }?>
		</div>
	</div>
</div>