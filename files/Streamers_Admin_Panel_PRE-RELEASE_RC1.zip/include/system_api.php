<?PHP
//	Streamers Admin Panel 3.2
//
//	Developer:
//	Main Coding: djcrackhome [Sebastian Graebner]
//	Thanks 2 Raimund Barendt, resh [Mathias Simon], hansy [Rico Reinheckel],
//	 Largo [Michael Savino], Marcel Weinberg, and all translators!
//
//	License:
//	Creative Commons Attribution-ShareAlike 3.0 Unported License
//		This work is licensed under the Creative Commons Attribution-ShareAlike 3.0 Unported License.
//		To view a copy of this license, visit http://creativecommons.org/licenses/by-sa/3.0/ or
//		send a letter to Creative Commons, 171 Second Street, Suite 300, San Francisco, California, 94105, USA.
//
//	URL:		http://www.streamerspanel.com
//	SUPPORT:	http://support.streamerspanel.com
//	MAIL:		info@streamerspanel.com
///////////////////////////////////////////////
//
//	FILENAME: ./include/system_api.php
//

if (mysql_real_escape_string(strip_tags(strtolower($_GET['external_api']))) == "1") {
	$external_api_db_check_userid = mysql_real_escape_string(strip_tags(strtolower($_GET['authhash_compare'])));
	$external_api_db_check_md5 = mysql_real_escape_string(strip_tags(strtolower($_GET['authhash_compare_md5'])));
	header('Content-type: text/xml; charset=utf-8'); 
	header('Pragma: public'); 
	header('Cache-control: private'); 
	header('Expires: -1'); 
	echo "<?xml version=\"1.0\" encoding=\"utf-8\"?>"; 
	echo '<!-- Streamers Admin Panel 3.2 -->';
	echo '<!-- FILENAME: ./include/system_api.php | API XML -->';
	if (isset($_GET['authhash_compare'])) {
		$external_api_db_check_data = mysql_query("SELECT * FROM internal_system_db_users WHERE username='".$external_api_db_check_userid."' AND md5_hash='".$external_api_db_check_md5."'");
		if (mysql_num_rows($external_api_db_check_data)!=0) {
			if (!isset($_GET['authhash_function'])) {
				mysql_query("UPDATE internal_system_db_users SET timestamp='".time()."' WHERE username='".$external_api_db_check_userid."'");
			}
			$external_api_db_check_data_after_timestamp = mysql_query("SELECT * FROM internal_system_db_users WHERE username='".$external_api_db_check_userid."' AND md5_hash='".$external_api_db_check_md5."'");
			while($external_api_db_check_var = mysql_fetch_array($external_api_db_check_data_after_timestamp, MYSQL_ASSOC)) {
				$external_api_db_check_id			= $external_api_db_check_var['id'];
				$external_api_db_check_passwordmd5	= $external_api_db_check_var['passwordmd5'];
				$external_api_db_check_firstname	= $external_api_db_check_var['firstname'];
				$external_api_db_check_lastname		= $external_api_db_check_var['lastname'];
				$external_api_db_check_dateofbirth	= $external_api_db_check_var['dateofbirth'];
				$external_api_db_check_street		= $external_api_db_check_var['street'];
				$external_api_db_check_city			= $external_api_db_check_var['city'];
				$external_api_db_check_zipcode		= $external_api_db_check_var['zipcode'];
				$external_api_db_check_state		= $external_api_db_check_var['state'];
				$external_api_db_check_country		= $external_api_db_check_var['country'];
				$external_api_db_check_phone		= $external_api_db_check_var['phone'];
				$external_api_db_check_email		= $external_api_db_check_var['user_email'];
				$external_api_db_check_wwwurl		= $external_api_db_check_var['wwwurl'];
				$external_api_db_check_facebook		= $external_api_db_check_var['facebook'];
				$external_api_db_check_userauth		= $external_api_db_check_var['userauth'];
				$external_api_db_check_timestamp	= $external_api_db_check_var['timestamp'];
				$external_api_db_check_secretkey	= $external_api_db_check_var['secretkey'];
			}
			$external_api_db_check_server = mysql_query("SELECT * FROM internal_system_db_servers WHERE owner='".mysql_real_escape_string(strip_tags($external_api_db_check_userid))."' ORDER BY portbase");
			$external_api_db_check_server_numrows = mysql_num_rows($external_api_db_check_server);
			if ($external_api_db_check_server_numrows!=0) { 
				while($external_api_db_check_server_row = mysql_fetch_array($external_api_db_check_server)) {
					$external_api_db_server_array[] = array('port' => $external_api_db_check_server_row['portbase'], 'djpass' => $external_api_db_check_server_row['password'], 'bitrate' => $external_api_db_check_server_row['bitrate'], 'adminpass' => $external_api_db_check_server_row['adminpassword'], 'id' => $external_api_db_check_server_row['id']);
				}
				if (!isset($_GET['authhash_function'])) {
					echo '<xml>'; 
					echo '	<userinfo>';
					echo '		<userid>'.base64_encode($external_api_db_check_id).'</userid>';
					echo '		<firstname>'.base64_encode($external_api_db_check_firstname).'</firstname>';
					echo '		<lastname>'.base64_encode($external_api_db_check_lastname).'</lastname>';
					echo '		<dateofbirth>'.base64_encode($external_api_db_check_dateofbirth).'</dateofbirth>';
					echo '		<street>'.base64_encode($external_api_db_check_street).'</street>';
					echo '		<city>'.base64_encode($external_api_db_check_city).'</city>';
					echo '		<zipcode>'.base64_encode($external_api_db_check_zipcode).'</zipcode>';
					echo '		<state>'.base64_encode($external_api_db_check_state).'</state>';
					echo '		<country>'.base64_encode($external_api_db_check_country).'</country>';
					echo '		<phone>'.base64_encode($external_api_db_check_phone).'</phone>';
					echo '		<email>'.base64_encode($external_api_db_check_email).'</email>';
					echo '		<wwwurl>'.base64_encode($external_api_db_check_wwwurl).'</wwwurl>';
					echo '		<facebook>'.base64_encode($external_api_db_check_facebook).'</facebook>';
					echo '	</userinfo>';
					echo '	<info>';
					echo '		<servercount>'.base64_encode(mysql_num_rows($external_api_db_check_server)).'</servercount>';
					echo '		<timestamp>'.$external_api_db_check_timestamp.'</timestamp>';
					echo '		<serverhost>'.base64_encode($internal_setting['system_host']).'</serverhost>';
					echo '		<servertitle>'.base64_encode($internal_setting['system_title']).'</servertitle>';
					echo '		<serverslogan>'.base64_encode($internal_setting['system_slogan']).'</serverslogan>';
					echo '	</info>';
					echo '	<streams>';
					for($external_api_db_xml_array_i=0, $external_api_db_xml_array_max = count($external_api_db_server_array); $external_api_db_xml_array_i< $external_api_db_xml_array_max; $external_api_db_xml_array_i++) {	
						echo '			<server>';
						echo '				<ip_dns>'.$_SERVER['SERVER_ADDR'].'</ip_dns>';
						echo '				<port>'.$external_api_db_server_array[$external_api_db_xml_array_i]["port"].'</port>';
						echo '				<dj_pass>'.$external_api_db_server_array[$external_api_db_xml_array_i]["djpass"].'</dj_pass>';
						echo '				<bitrate>'.($external_api_db_server_array[$external_api_db_xml_array_i]["bitrate"]/1000).'kbps</bitrate>';
						echo '				<playlists>';
						echo '					<default_pls>YXV0b2RqLmxzdA==</default_pls>';
						echo '				</playlists>';
						echo '			</server>';
					}
					echo '	</streams>';
					echo '	<status>';
					echo '		<code>yapix001</code>';
					echo '		<message>SUCCESSFULLY LOGGED IN</message>';
					echo '	</status>'; 
					echo '</xml>';
					die();
				}
				else {
					for($external_api_function_hash_i=0; $external_api_function_hash_i<count($external_api_db_server_array); $external_api_function_hash_i++) {
						switch (mysql_real_escape_string(strip_tags(strtolower($_GET['authhash_function'])))) {
							case md5($external_api_db_check_secretkey.md5(md5($external_api_db_server_array[$external_api_function_hash_i]["port"]).md5($external_api_db_check_timestamp).md5($external_api_db_check_id).md5("shout_start"))):
								mysql_query("UPDATE internal_system_db_users SET timestamp='00' WHERE username='".$external_api_db_check_userid."'");
								$return_internal_function=internal_function_shoutcast_start($external_api_db_server_array[$external_api_function_hash_i]["id"], $external_api_db_check_userid);
								if ($return_internal_function=="yfssx001-SERVER_WAS_SUCCESSFULLY_STARTED") {
									$return_internal_function_message = substr($return_internal_function, 9);
									echo '<xml>'; 
									echo '	<status>';
									echo '		<code>'.$return_internal_function.'</code>';
									echo '		<message>'.$return_internal_function_message.'</message>';
									echo '	</status>'; 
									echo '</xml>';
									die();
								}
								else {
									$return_internal_function_code = substr($return_internal_function, 0, 7);
									$return_internal_function_message = substr($return_internal_function, 9);
									echo '<xml>'; 
									echo '	<status>';
									echo '		<code>'.$return_internal_function_code.'</code>';
									echo '		<message>'.$return_internal_function_message.'</message>';
									echo '	</status>'; 
									echo '</xml>';
									die();
								}
								break;
							case md5($external_api_db_check_secretkey.md5(md5($external_api_db_server_array[$external_api_function_hash_i]["port"]).md5($external_api_db_check_timestamp).md5($external_api_db_check_id).md5("shout_stop"))):
								$return_internal_function=internal_function_shoutcast_stop($external_api_db_server_array[$external_api_function_hash_i]["id"], $external_api_db_check_userid);
								mysql_query("UPDATE internal_system_db_users SET timestamp='00' WHERE username='".$external_api_db_check_userid."'");
								if ($return_internal_function=="yfstx001") {
									$return_internal_function_message = substr($return_internal_function, 9);
									echo '<xml>'; 
									echo '	<status>';
									echo '		<code>'.$return_internal_function.'</code>';
									echo '		<message>'.$return_internal_function_message.'</message>';
									echo '	</status>'; 
									echo '</xml>';
									die();
								}
								else {
									$return_internal_function_code = substr($return_internal_function, 0, 8);
									$return_internal_function_message = substr($return_internal_function, 9);
									echo '<xml>'; 
									echo '	<status>';
									echo '		<code>'.$return_internal_function_code.'</code>';
									echo '		<message>'.$return_internal_function_message.'</message>';
									echo '	</status>'; 
									echo '</xml>';
									die();
								}
								break;
							case md5($external_api_db_check_secretkey.md5(md5($external_api_db_server_array[$external_api_function_hash_i]["port"]).md5($external_api_db_check_timestamp).md5($external_api_db_check_id).md5("trans_start"))):
								if (isset($_GET['authhash_function_playlist'])) {
									internal_function_sctrans_start($external_api_db_server_array[$external_api_function_hash_i]["port"],  mysql_real_escape_string(strip_tags(base64_decode($_GET['authhash_function_playlist']))), $external_api_db_check_userid);
								}
								else {
								}
								break;
							case md5($external_api_db_check_secretkey.md5(md5($external_api_db_server_array[$external_api_function_hash_i]["port"]).md5($external_api_db_check_timestamp).md5($external_api_db_check_id).md5("trans_stop"))):
								internal_function_sctrans_stop($external_api_db_server_array[$external_api_function_hash_i]["port"], $external_api_db_check_userid);
								break;
							case md5($external_api_db_check_secretkey.md5(md5($external_api_db_server_array[$external_api_function_hash_i]["port"]).md5($external_api_db_check_timestamp).md5($external_api_db_check_id).md5("shout_kick"))):
								internal_function_server_kick($external_api_db_server_array[$external_api_function_hash_i]["port"], $external_api_db_check_userid, $external_api_db_server_array[$external_api_function_hash_i]["adminpass"]);
								break;
						}
					}
					echo '<xml>'; 
					echo '	<status>';
					echo '		<code>xapix004</code>';
					echo '		<message>WRONG_AUTH_FUNCTION_CODE</message>';
					echo '	</status>'; 
					echo '</xml>';
				}
			}
			else {
				echo '<xml>'; 
				echo '	<status>';
				echo '		<code>xapix003</code>';
				echo '		<message>NO_SERVER_REGISTERED_FOR_THIS_USER</message>';
				echo '	</status>'; 
				echo '</xml>';
			}
		}
		else {
			echo '<xml>'; 
			echo '	<status>';
			echo '		<code>xapix002</code>';
			echo '		<message>WRONG_AUTHENTIFICATION_CODE</message>';
			echo '	</status>'; 
			echo '</xml>';
		}
	}
	else {
		echo '<xml>'; 
		echo '	<status>';
		echo '		<code>xapix001</code>';
		echo '		<message>NO_AUTHENTIFICATION_CODE</message>';
		echo '	</status>'; 
		echo '</xml>';
	}
}
mysql_close($external_function_db_connect);
?>