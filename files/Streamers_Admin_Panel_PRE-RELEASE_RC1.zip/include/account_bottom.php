<?PHP
//	Streamers Admin Panel 3.2
//
//	Developer:
//	Main Coding: djcrackhome [Sebastian Graebner]
//	Thanks 2 Raimund Barendt, resh [Mathias Simon], hansy [Rico Reinheckel], Largo [Michael Savino] 
//
//	License:
//	Creative Commons Attribution-ShareAlike 3.0 Unported License
//		This work is licensed under the Creative Commons Attribution-ShareAlike 3.0 Unported License.
//		To view a copy of this license, visit http://creativecommons.org/licenses/by-sa/3.0/ or
//		send a letter to Creative Commons, 171 Second Street, Suite 300, San Francisco, California, 94105, USA.
//
//	URL:		http://www.streamerspanel.com
//	SUPPORT:	http://support.streamerspanel.com
//	MAIL:		info@streamerspanel.com
///////////////////////////////////////////////
//
//	FILENAME: ./include/account_bottom.php
//

error_reporting(0);
if ((!defined("_include_security")) || (!preg_match("/content.php/i", $_SERVER['PHP_SELF']))) {
    header('Location: ./../index.php?system_login='.md5(md5("access").date("H:i").$_SERVER['REMOTE_ADDR']));
	die();
}
$internal_account_query = mysql_query("SELECT * FROM internal_system_db_users WHERE id='".$internal_user_id."'");
foreach(mysql_fetch_array($internal_account_query) as $internal_account_query_key => $internal_account_query_pref) {
	if (!is_numeric($internal_account_query_key)) {
		if ($internal_account_query_pref != "")
			$internal_account[$internal_account_query_key] = $internal_account_query_pref;
		else
			$internal_account[$internal_account_query_key] = "";
	}
}
?>
<div id="content">
	<div class="box">
		<h2><?php echo $language_message['60'];?></h2>
		<div class="contact_top_menu">
			<div class="tool_top_menu">
				<div class="main_shorttool"><?php echo $language_message[61];?></div>
				<div class="main_righttool">
					<h2><?php echo $language_message[62];?></h2>
					<p><?php echo $language_message[63];?></p>
					<p>&nbsp;</p>
				</div>
			</div>
			<form method="post" action="content.php?include=account">
				<fieldset>
					<legend><?php echo $language_message[64];?></legend>
					<div class="input_field">
						<label for="a"><?php echo $language_message[65];?></label>
						<input class="mediumfield" name="account_username" type="text" value="<?php echo htmlspecialchars($internal_user_name);?>" disabled="disabled" />
						<span class="field_desc"><?php echo $language_message[66];?></span>
					</div>
					<div class="input_field">
						<label for="a"><?php echo $language_message[67];?></label>
						<input class="mediumfield" name="account_level" type="text" value="<?php echo $internal_user_level;?>" disabled="disabled" />
						<span class="field_desc"><?php echo $language_message[68];?></span>
					</div>
					<div class="input_field">
						<label for="a"><?php echo $language_message[69];?></label>
						<input class="mediumfield" name="account_password" type="password" value="***********" />
						<span class="field_desc"><?php echo $language_message[70];?></span>
					</div>
					<div class="input_field">
						<label for="a"><?php echo $language_message[71];?></label>
						<input class="mediumfield" name="account_password_repeat" type="password" />
						<span class="field_desc"><?php echo $language_message[72];?></span>
					</div>
					<div class="input_field">
						<label for="a"><?php echo $language_message[73];?></label>
						<input class="mediumfield" name="account_email" type="text" value="<?php echo htmlspecialchars($internal_account['user_email']);?>" />
						<span class="field_desc"><?php echo $language_message[74];?></span>
					</div>
					<div class="input_field">
						<label for="a6"><?php echo $language_message[75];?></label>
						<input class="mediumfield" name="account_firstname" type="text" value="<?php echo htmlspecialchars($internal_account['firstname']);?>" />
						<span class="field_desc"><?php echo $language_message[76];?></span>
					</div>
					<div class="input_field">
						<label for="a7"><?php echo $language_message[77];?></label>
						<input class="mediumfield" name="account_lastname" type="text" value="<?php echo htmlspecialchars($internal_account['lastname']);?>" />
						<span class="field_desc"><?php echo $language_message[78];?></span>
					</div>
					<div class="input_field">
						<label for="a8"><?php echo $language_message[79];?></label>
						<input class="mediumfield" name="account_dateofbirth" type="text" value="<?php echo htmlspecialchars($internal_account['dateofbirth']);?>" />
						<span class="field_desc"><?php echo $language_message[80];?></span>
					</div>
					<div class="input_field">
						<label for="a10"><?php echo $language_message[81];?></label>
						<input class="mediumfield" name="account_street" type="text" value="<?php echo htmlspecialchars($internal_account['street']);?>" />
						<span class="field_desc"><?php echo $language_message[82];?></span>
					</div>
					<div class="input_field">
						<label for="a11"><?php echo $language_message[83];?></label>
						<input class="mediumfield" name="account_city" type="text" value="<?php echo htmlspecialchars($internal_account['city']);?>" />
						<span class="field_desc"><?php echo $language_message[84];?></span>
					</div>
					<div class="input_field">
						<label for="a11"><?php echo $language_message[85];?></label>
						<input class="mediumfield" name="account_zipcode" type="text" value="<?php echo htmlspecialchars($internal_account['zipcode']);?>" />
						<span class="field_desc"><?php echo $language_message[86];?></span>
					</div>
					<div class="input_field">
						<label for="a11"><?php echo $language_message[87];?></label>
						<input class="mediumfield" name="account_state" type="text" value="<?php echo htmlspecialchars($internal_account['state']);?>" />
						<span class="field_desc"><?php echo $language_message[88];?></span>
					</div>
					<div class="input_field">
						<label for="a11"><?php echo $language_message[89];?></label>
                        <select name="account_country" class="formselect_loca">
                            <option value="AF"<?php if ($internal_account['country']=="AF") echo " selected=\"selected\"";?>>Afghanistan</option>
                            <option value="AX"<?php if ($internal_account['country']=="AX") echo " selected=\"selected\"";?>>Aland Islands</option>
                            <option value="AL"<?php if ($internal_account['country']=="AL") echo " selected=\"selected\"";?>>Albania</option>
                            <option value="DZ"<?php if ($internal_account['country']=="DZ") echo " selected=\"selected\"";?>>Algeria</option>
                            <option value="AS"<?php if ($internal_account['country']=="AS") echo " selected=\"selected\"";?>>American Samoa</option>
                            <option value="AD"<?php if ($internal_account['country']=="AD") echo " selected=\"selected\"";?>>Andorra</option>
                            <option value="AO"<?php if ($internal_account['country']=="AO") echo " selected=\"selected\"";?>>Angola</option>
                            <option value="AI"<?php if ($internal_account['country']=="AI") echo " selected=\"selected\"";?>>Anguilla</option>
                            <option value="AQ"<?php if ($internal_account['country']=="AQ") echo " selected=\"selected\"";?>>Antarctica</option>
                            <option value="AG"<?php if ($internal_account['country']=="AG") echo " selected=\"selected\"";?>>Antigua And Barbuda</option>
                            <option value="AR"<?php if ($internal_account['country']=="AR") echo " selected=\"selected\"";?>>Argentina</option>
                            <option value="AM"<?php if ($internal_account['country']=="AM") echo " selected=\"selected\"";?>>Armenia</option>
                            <option value="AW"<?php if ($internal_account['country']=="AW") echo " selected=\"selected\"";?>>Aruba</option>
                            <option value="AU"<?php if ($internal_account['country']=="AU") echo " selected=\"selected\"";?>>Australia</option>
                            <option value="AT"<?php if ($internal_account['country']=="AT") echo " selected=\"selected\"";?>>Austria</option>
                            <option value="AZ"<?php if ($internal_account['country']=="AZ") echo " selected=\"selected\"";?>>Azerbaijan</option>
                            <option value="BS"<?php if ($internal_account['country']=="BS") echo " selected=\"selected\"";?>>Bahamas</option>
                            <option value="BH"<?php if ($internal_account['country']=="BH") echo " selected=\"selected\"";?>>Bahrain</option>
                            <option value="BD"<?php if ($internal_account['country']=="BD") echo " selected=\"selected\"";?>>Bangladesh</option>
                            <option value="BB"<?php if ($internal_account['country']=="BB") echo " selected=\"selected\"";?>>Barbados</option>
                            <option value="BY"<?php if ($internal_account['country']=="BY") echo " selected=\"selected\"";?>>Belarus</option>
                            <option value="BE"<?php if ($internal_account['country']=="BE") echo " selected=\"selected\"";?>>Belgium</option>
                            <option value="BZ"<?php if ($internal_account['country']=="BZ") echo " selected=\"selected\"";?>>Belize</option>
                            <option value="BJ"<?php if ($internal_account['country']=="BJ") echo " selected=\"selected\"";?>>Benin</option>
                            <option value="BM"<?php if ($internal_account['country']=="BM") echo " selected=\"selected\"";?>>Bermuda</option>
                            <option value="BT"<?php if ($internal_account['country']=="BT") echo " selected=\"selected\"";?>>Bhutan</option>
                            <option value="BO"<?php if ($internal_account['country']=="BO") echo " selected=\"selected\"";?>>Bolivia</option>
                            <option value="BA"<?php if ($internal_account['country']=="BA") echo " selected=\"selected\"";?>>Bosnia And Herzegovina</option>
                            <option value="BW"<?php if ($internal_account['country']=="BW") echo " selected=\"selected\"";?>>Botswana</option>
                            <option value="BV"<?php if ($internal_account['country']=="BV") echo " selected=\"selected\"";?>>Bouvet Island</option>
                            <option value="BR"<?php if ($internal_account['country']=="BR") echo " selected=\"selected\"";?>>Brazil</option>
                            <option value="IO"<?php if ($internal_account['country']=="IO") echo " selected=\"selected\"";?>>British Indian Ocean Ter.</option>
                            <option value="BN"<?php if ($internal_account['country']=="BN") echo " selected=\"selected\"";?>>Brunei Darussalam</option>
                            <option value="BG"<?php if ($internal_account['country']=="BG") echo " selected=\"selected\"";?>>Bulgaria</option>
                            <option value="BF"<?php if ($internal_account['country']=="BF") echo " selected=\"selected\"";?>>Burkina Faso</option>
                            <option value="BI"<?php if ($internal_account['country']=="BI") echo " selected=\"selected\"";?>>Burundi</option>
                            <option value="KH"<?php if ($internal_account['country']=="KH") echo " selected=\"selected\"";?>>Cambodia</option>
                            <option value="CM"<?php if ($internal_account['country']=="CM") echo " selected=\"selected\"";?>>Cameroon</option>
                            <option value="CA"<?php if ($internal_account['country']=="CA") echo " selected=\"selected\"";?>>Canada</option>
                            <option value="CV"<?php if ($internal_account['country']=="CV") echo " selected=\"selected\"";?>>Cape Verde</option>
                            <option value="KY"<?php if ($internal_account['country']=="KY") echo " selected=\"selected\"";?>>Cayman Islands</option>
                            <option value="CF"<?php if ($internal_account['country']=="CF") echo " selected=\"selected\"";?>>Central African Republic</option>
                            <option value="TD"<?php if ($internal_account['country']=="TD") echo " selected=\"selected\"";?>>Chad</option>
                            <option value="CL"<?php if ($internal_account['country']=="CL") echo " selected=\"selected\"";?>>Chile</option>
                            <option value="CN"<?php if ($internal_account['country']=="CN") echo " selected=\"selected\"";?>>China</option>
                            <option value="CX"<?php if ($internal_account['country']=="CX") echo " selected=\"selected\"";?>>Christmas Island</option>
                            <option value="CC"<?php if ($internal_account['country']=="CC") echo " selected=\"selected\"";?>>Cocos (Keeling) Islands</option>
                            <option value="CO"<?php if ($internal_account['country']=="CO") echo " selected=\"selected\"";?>>Colombia</option>
                            <option value="KM"<?php if ($internal_account['country']=="KM") echo " selected=\"selected\"";?>>Comoros</option>
                            <option value="CG"<?php if ($internal_account['country']=="CG") echo " selected=\"selected\"";?>>Congo</option>
                            <option value="CD"<?php if ($internal_account['country']=="CD") echo " selected=\"selected\"";?>>Congo, Democratic Republic</option>
                            <option value="CK"<?php if ($internal_account['country']=="CK") echo " selected=\"selected\"";?>>Cook Islands</option>
                            <option value="CR"<?php if ($internal_account['country']=="CR") echo " selected=\"selected\"";?>>Costa Rica</option>
                            <option value="CI"<?php if ($internal_account['country']=="CI") echo " selected=\"selected\"";?>>Côte D'Ivoire</option>
                            <option value="HR"<?php if ($internal_account['country']=="HR") echo " selected=\"selected\"";?>>Croatia</option>
                            <option value="CU"<?php if ($internal_account['country']=="CU") echo " selected=\"selected\"";?>>Cuba</option>
                            <option value="CY"<?php if ($internal_account['country']=="CY") echo " selected=\"selected\"";?>>Cyprus</option>
                            <option value="CZ"<?php if ($internal_account['country']=="CZ") echo " selected=\"selected\"";?>>Czech Republic</option>
                            <option value="DK"<?php if ($internal_account['country']=="DK") echo " selected=\"selected\"";?>>Denmark</option>
                            <option value="DJ"<?php if ($internal_account['country']=="DJ") echo " selected=\"selected\"";?>>Djibouti</option>
                            <option value="DM"<?php if ($internal_account['country']=="DM") echo " selected=\"selected\"";?>>Dominica</option>
                            <option value="DO"<?php if ($internal_account['country']=="DO") echo " selected=\"selected\"";?>>Dominican Republic</option>
                            <option value="EC"<?php if ($internal_account['country']=="EC") echo " selected=\"selected\"";?>>Ecuador</option>
                            <option value="EG"<?php if ($internal_account['country']=="EG") echo " selected=\"selected\"";?>>Egypt</option>
                            <option value="SV"<?php if ($internal_account['country']=="SV") echo " selected=\"selected\"";?>>El Salvador</option>
                            <option value="GQ"<?php if ($internal_account['country']=="GQ") echo " selected=\"selected\"";?>>Equatorial Guinea</option>
                            <option value="ER"<?php if ($internal_account['country']=="ER") echo " selected=\"selected\"";?>>Eritrea</option>
                            <option value="EE"<?php if ($internal_account['country']=="EE") echo " selected=\"selected\"";?>>Estonia</option>
                            <option value="ET"<?php if ($internal_account['country']=="ET") echo " selected=\"selected\"";?>>Ethiopia</option>
                            <option value="FK"<?php if ($internal_account['country']=="FK") echo " selected=\"selected\"";?>>Falkland Islands (Malvinas)</option>
                            <option value="FO"<?php if ($internal_account['country']=="FO") echo " selected=\"selected\"";?>>Faroe Islands</option>
                            <option value="FJ"<?php if ($internal_account['country']=="FJ") echo " selected=\"selected\"";?>>Fiji</option>
                            <option value="FI"<?php if ($internal_account['country']=="FI") echo " selected=\"selected\"";?>>Finland</option>
                            <option value="FR"<?php if ($internal_account['country']=="FR") echo " selected=\"selected\"";?>>France</option>
                            <option value="GF"<?php if ($internal_account['country']=="GF") echo " selected=\"selected\"";?>>French Guiana</option>
                            <option value="PF"<?php if ($internal_account['country']=="PF") echo " selected=\"selected\"";?>>French Polynesia</option>
                            <option value="TF"<?php if ($internal_account['country']=="TF") echo " selected=\"selected\"";?>>French Southern Territories</option>
                            <option value="GA"<?php if ($internal_account['country']=="GA") echo " selected=\"selected\"";?>>Gabon</option>
                            <option value="GM"<?php if ($internal_account['country']=="GM") echo " selected=\"selected\"";?>>Gambia</option>
                            <option value="GE"<?php if ($internal_account['country']=="GE") echo " selected=\"selected\"";?>>Georgia</option>
                            <option value="DE"<?php if ($internal_account['country']=="DE") echo " selected=\"selected\"";?>>Germany</option>
                            <option value="GH"<?php if ($internal_account['country']=="GH") echo " selected=\"selected\"";?>>Ghana</option>
                            <option value="GI"<?php if ($internal_account['country']=="GI") echo " selected=\"selected\"";?>>Gibraltar</option>
                            <option value="GR"<?php if ($internal_account['country']=="GR") echo " selected=\"selected\"";?>>Greece</option>
                            <option value="GL"<?php if ($internal_account['country']=="GL") echo " selected=\"selected\"";?>>Greenland</option>
                            <option value="GD"<?php if ($internal_account['country']=="GD") echo " selected=\"selected\"";?>>Grenada</option>
                            <option value="GP"<?php if ($internal_account['country']=="GP") echo " selected=\"selected\"";?>>Guadeloupe</option>
                            <option value="GU"<?php if ($internal_account['country']=="GU") echo " selected=\"selected\"";?>>Guam</option>
                            <option value="GT"<?php if ($internal_account['country']=="GT") echo " selected=\"selected\"";?>>Guatemala</option>
                            <option value="GG"<?php if ($internal_account['country']=="GG") echo " selected=\"selected\"";?>>Guernsey</option>
                            <option value="GN"<?php if ($internal_account['country']=="GN") echo " selected=\"selected\"";?>>Guinea</option>
                            <option value="GW"<?php if ($internal_account['country']=="GW") echo " selected=\"selected\"";?>>Guinea-Bissau</option>
                            <option value="GY"<?php if ($internal_account['country']=="GY") echo " selected=\"selected\"";?>>Guyana</option>
                            <option value="HT"<?php if ($internal_account['country']=="HT") echo " selected=\"selected\"";?>>Haiti</option>
                            <option value="HM"<?php if ($internal_account['country']=="HM") echo " selected=\"selected\"";?>>Heard Island And Mcdonald Islands</option>
                            <option value="HN"<?php if ($internal_account['country']=="HN") echo " selected=\"selected\"";?>>Honduras</option>
                            <option value="HK"<?php if ($internal_account['country']=="HK") echo " selected=\"selected\"";?>>Hong Kong</option>
                            <option value="HU"<?php if ($internal_account['country']=="HU") echo " selected=\"selected\"";?>>Hungary</option>
                            <option value="IS"<?php if ($internal_account['country']=="IS") echo " selected=\"selected\"";?>>Iceland</option>
                            <option value="IN"<?php if ($internal_account['country']=="IN") echo " selected=\"selected\"";?>>India</option>
                            <option value="ID"<?php if ($internal_account['country']=="ID") echo " selected=\"selected\"";?>>Indonesia</option>
                            <option value="IR"<?php if ($internal_account['country']=="IR") echo " selected=\"selected\"";?>>Iran, Islamic Republic Of</option>
                            <option value="IQ"<?php if ($internal_account['country']=="IQ") echo " selected=\"selected\"";?>>Iraq</option>
                            <option value="IE"<?php if ($internal_account['country']=="IE") echo " selected=\"selected\"";?>>Ireland</option>
                            <option value="IM"<?php if ($internal_account['country']=="IM") echo " selected=\"selected\"";?>>Isle Of Man</option>
                            <option value="IL"<?php if ($internal_account['country']=="IL") echo " selected=\"selected\"";?>>Israel</option>
                            <option value="IT"<?php if ($internal_account['country']=="IT") echo " selected=\"selected\"";?>>Italy</option>
                            <option value="JM"<?php if ($internal_account['country']=="JM") echo " selected=\"selected\"";?>>Jamaica</option>
                            <option value="JP"<?php if ($internal_account['country']=="JP") echo " selected=\"selected\"";?>>Japan</option>
                            <option value="JE"<?php if ($internal_account['country']=="JE") echo " selected=\"selected\"";?>>Jersey</option>
                            <option value="JO"<?php if ($internal_account['country']=="JO") echo " selected=\"selected\"";?>>Jordan</option>
                            <option value="KZ"<?php if ($internal_account['country']=="KZ") echo " selected=\"selected\"";?>>Kazakhstan</option>
                            <option value="KE"<?php if ($internal_account['country']=="KE") echo " selected=\"selected\"";?>>Kenya</option>
                            <option value="KI"<?php if ($internal_account['country']=="KI") echo " selected=\"selected\"";?>>Kiribati</option>
                            <option value="KP"<?php if ($internal_account['country']=="KP") echo " selected=\"selected\"";?>>Korea, Democratic Republic</option>
                            <option value="KR"<?php if ($internal_account['country']=="KR") echo " selected=\"selected\"";?>>Korea, Republic Of</option>
                            <option value="KW"<?php if ($internal_account['country']=="KW") echo " selected=\"selected\"";?>>Kuwait</option>
                            <option value="KG"<?php if ($internal_account['country']=="KG") echo " selected=\"selected\"";?>>Kyrgyzstan</option>
                            <option value="LA"<?php if ($internal_account['country']=="LA") echo " selected=\"selected\"";?>>Lao Democratic Republic</option>
                            <option value="LV"<?php if ($internal_account['country']=="LV") echo " selected=\"selected\"";?>>Latvia</option>
                            <option value="LB"<?php if ($internal_account['country']=="LB") echo " selected=\"selected\"";?>>Lebanon</option>
                            <option value="LS"<?php if ($internal_account['country']=="LS") echo " selected=\"selected\"";?>>Lesotho</option>
                            <option value="LR"<?php if ($internal_account['country']=="LR") echo " selected=\"selected\"";?>>Liberia</option>
                            <option value="LY"<?php if ($internal_account['country']=="LY") echo " selected=\"selected\"";?>>Libyan Arab Jamahiriya</option>
                            <option value="LI"<?php if ($internal_account['country']=="LI") echo " selected=\"selected\"";?>>Liechtenstein</option>
                            <option value="LT"<?php if ($internal_account['country']=="LT") echo " selected=\"selected\"";?>>Lithuania</option>
                            <option value="LU"<?php if ($internal_account['country']=="LU") echo " selected=\"selected\"";?>>Luxembourg</option>
                            <option value="MO"<?php if ($internal_account['country']=="MO") echo " selected=\"selected\"";?>>Macao</option>
                            <option value="MK"<?php if ($internal_account['country']=="MK") echo " selected=\"selected\"";?>>Macedonia, Republic Of</option>
                            <option value="MG"<?php if ($internal_account['country']=="MG") echo " selected=\"selected\"";?>>Madagascar</option>
                            <option value="MW"<?php if ($internal_account['country']=="MW") echo " selected=\"selected\"";?>>Malawi</option>
                            <option value="MY"<?php if ($internal_account['country']=="MY") echo " selected=\"selected\"";?>>Malaysia</option>
                            <option value="MV"<?php if ($internal_account['country']=="MV") echo " selected=\"selected\"";?>>Maldives</option>
                            <option value="ML"<?php if ($internal_account['country']=="ML") echo " selected=\"selected\"";?>>Mali</option>
                            <option value="MT"<?php if ($internal_account['country']=="MT") echo " selected=\"selected\"";?>>Malta</option>
                            <option value="MH"<?php if ($internal_account['country']=="MH") echo " selected=\"selected\"";?>>Marshall Islands</option>
                            <option value="MQ"<?php if ($internal_account['country']=="MQ") echo " selected=\"selected\"";?>>Martinique</option>
                            <option value="MR"<?php if ($internal_account['country']=="MR") echo " selected=\"selected\"";?>>Mauritania</option>
                            <option value="MU"<?php if ($internal_account['country']=="MU") echo " selected=\"selected\"";?>>Mauritius</option>
                            <option value="YT"<?php if ($internal_account['country']=="YT") echo " selected=\"selected\"";?>>Mayotte</option>
                            <option value="MX"<?php if ($internal_account['country']=="MX") echo " selected=\"selected\"";?>>Mexico</option>
                            <option value="FM"<?php if ($internal_account['country']=="FM") echo " selected=\"selected\"";?>>Micronesia, Federated States Of</option>
                            <option value="MD"<?php if ($internal_account['country']=="MD") echo " selected=\"selected\"";?>>Moldova, Republic Of</option>
                            <option value="MC"<?php if ($internal_account['country']=="MC") echo " selected=\"selected\"";?>>Monaco</option>
                            <option value="MN"<?php if ($internal_account['country']=="MN") echo " selected=\"selected\"";?>>Mongolia</option>
                            <option value="ME"<?php if ($internal_account['country']=="ME") echo " selected=\"selected\"";?>>Montenegro</option>
                            <option value="MS"<?php if ($internal_account['country']=="MS") echo " selected=\"selected\"";?>>Montserrat</option>
                            <option value="MA"<?php if ($internal_account['country']=="MA") echo " selected=\"selected\"";?>>Morocco</option>
                            <option value="MZ"<?php if ($internal_account['country']=="MZ") echo " selected=\"selected\"";?>>Mozambique</option>
                            <option value="MM"<?php if ($internal_account['country']=="MM") echo " selected=\"selected\"";?>>Myanmar</option>
                            <option value="NA"<?php if ($internal_account['country']=="NA") echo " selected=\"selected\"";?>>Namibia</option>
                            <option value="NR"<?php if ($internal_account['country']=="NR") echo " selected=\"selected\"";?>>Nauru</option>
                            <option value="NP"<?php if ($internal_account['country']=="NP") echo " selected=\"selected\"";?>>Nepal</option>
                            <option value="NL"<?php if ($internal_account['country']=="NL") echo " selected=\"selected\"";?>>Netherlands</option>
                            <option value="AN"<?php if ($internal_account['country']=="AN") echo " selected=\"selected\"";?>>Netherlands Antilles</option>
                            <option value="NC"<?php if ($internal_account['country']=="NC") echo " selected=\"selected\"";?>>New Caledonia</option>
                            <option value="NZ"<?php if ($internal_account['country']=="NZ") echo " selected=\"selected\"";?>>New Zealand</option>
                            <option value="NI"<?php if ($internal_account['country']=="NI") echo " selected=\"selected\"";?>>Nicaragua</option>
                            <option value="NE"<?php if ($internal_account['country']=="NE") echo " selected=\"selected\"";?>>Niger</option>
                            <option value="NG"<?php if ($internal_account['country']=="NG") echo " selected=\"selected\"";?>>Nigeria</option>
                            <option value="NU"<?php if ($internal_account['country']=="NU") echo " selected=\"selected\"";?>>Niue</option>
                            <option value="NF"<?php if ($internal_account['country']=="NF") echo " selected=\"selected\"";?>>Norfolk Island</option>
                            <option value="MP"<?php if ($internal_account['country']=="MP") echo " selected=\"selected\"";?>>Northern Mariana Islands</option>
                            <option value="NO"<?php if ($internal_account['country']=="NO") echo " selected=\"selected\"";?>>Norway</option>
                            <option value="OM"<?php if ($internal_account['country']=="OM") echo " selected=\"selected\"";?>>Oman</option>
                            <option value="PK"<?php if ($internal_account['country']=="PK") echo " selected=\"selected\"";?>>Pakistan</option>
                            <option value="PW"<?php if ($internal_account['country']=="PW") echo " selected=\"selected\"";?>>Palau</option>
                            <option value="PS"<?php if ($internal_account['country']=="PS") echo " selected=\"selected\"";?>>Palestinian Territory</option>
                            <option value="PA"<?php if ($internal_account['country']=="PA") echo " selected=\"selected\"";?>>Panama</option>
                            <option value="PG"<?php if ($internal_account['country']=="PG") echo " selected=\"selected\"";?>>Papua New Guinea</option>
                            <option value="PY"<?php if ($internal_account['country']=="PY") echo " selected=\"selected\"";?>>Paraguay</option>
                            <option value="PE"<?php if ($internal_account['country']=="PE") echo " selected=\"selected\"";?>>Peru</option>
                            <option value="PH"<?php if ($internal_account['country']=="PH") echo " selected=\"selected\"";?>>Philippines</option>
                            <option value="PN"<?php if ($internal_account['country']=="PN") echo " selected=\"selected\"";?>>Pitcairn</option>
                            <option value="PL"<?php if ($internal_account['country']=="PL") echo " selected=\"selected\"";?>>Poland</option>
                            <option value="PT"<?php if ($internal_account['country']=="PT") echo " selected=\"selected\"";?>>Portugal</option>
                            <option value="PR"<?php if ($internal_account['country']=="PR") echo " selected=\"selected\"";?>>Puerto Rico</option>
                            <option value="QA"<?php if ($internal_account['country']=="QA") echo " selected=\"selected\"";?>>Qatar</option>
                            <option value="RE"<?php if ($internal_account['country']=="RE") echo " selected=\"selected\"";?>>Réunion</option>
                            <option value="RO"<?php if ($internal_account['country']=="RO") echo " selected=\"selected\"";?>>Romania</option>
                            <option value="RU"<?php if ($internal_account['country']=="RU") echo " selected=\"selected\"";?>>Russian Federation</option>
                            <option value="RW"<?php if ($internal_account['country']=="RW") echo " selected=\"selected\"";?>>Rwanda</option>
                            <option value="BL"<?php if ($internal_account['country']=="BL") echo " selected=\"selected\"";?>>Saint Barthélemy</option>
                            <option value="SH"<?php if ($internal_account['country']=="SH") echo " selected=\"selected\"";?>>Saint Helena and Tristan Da Cunha</option>
                            <option value="KN"<?php if ($internal_account['country']=="KN") echo " selected=\"selected\"";?>>Saint Kitts And Nevis</option>
                            <option value="LC"<?php if ($internal_account['country']=="LC") echo " selected=\"selected\"";?>>Saint Lucia</option>
                            <option value="MF"<?php if ($internal_account['country']=="MF") echo " selected=\"selected\"";?>>Saint Martin</option>
                            <option value="PM"<?php if ($internal_account['country']=="PM") echo " selected=\"selected\"";?>>Saint Pierre And Miquelon</option>
                            <option value="VC"<?php if ($internal_account['country']=="VC") echo " selected=\"selected\"";?>>Saint Vincent And The Grenadines</option>
                            <option value="WS"<?php if ($internal_account['country']=="WS") echo " selected=\"selected\"";?>>Samoa</option>
                            <option value="SM"<?php if ($internal_account['country']=="SM") echo " selected=\"selected\"";?>>San Marino</option>
                            <option value="ST"<?php if ($internal_account['country']=="ST") echo " selected=\"selected\"";?>>Sao Tome And Principe</option>
                            <option value="SA"<?php if ($internal_account['country']=="SA") echo " selected=\"selected\"";?>>Saudi Arabia</option>
                            <option value="SN"<?php if ($internal_account['country']=="SN") echo " selected=\"selected\"";?>>Senegal</option>
                            <option value="RS"<?php if ($internal_account['country']=="RS") echo " selected=\"selected\"";?>>Serbia</option>
                            <option value="SC"<?php if ($internal_account['country']=="SC") echo " selected=\"selected\"";?>>Seychelles</option>
                            <option value="SL"<?php if ($internal_account['country']=="SL") echo " selected=\"selected\"";?>>Sierra Leone</option>
                            <option value="SG"<?php if ($internal_account['country']=="SG") echo " selected=\"selected\"";?>>Singapore</option>
                            <option value="SK"<?php if ($internal_account['country']=="SK") echo " selected=\"selected\"";?>>Slovakia</option>
                            <option value="SI"<?php if ($internal_account['country']=="SI") echo " selected=\"selected\"";?>>Slovenia</option>
                            <option value="SB"<?php if ($internal_account['country']=="SB") echo " selected=\"selected\"";?>>Solomon Islands</option>
                            <option value="SO"<?php if ($internal_account['country']=="SO") echo " selected=\"selected\"";?>>Somalia</option>
                            <option value="ZA"<?php if ($internal_account['country']=="ZA") echo " selected=\"selected\"";?>>South Africa</option>
                            <option value="GS"<?php if ($internal_account['country']=="GS") echo " selected=\"selected\"";?>>South Georgia And Sandwich Islands</option>
                            <option value="ES"<?php if ($internal_account['country']=="ES") echo " selected=\"selected\"";?>>Spain</option>
                            <option value="LK"<?php if ($internal_account['country']=="LK") echo " selected=\"selected\"";?>>Sri Lanka</option>
                            <option value="SD"<?php if ($internal_account['country']=="SD") echo " selected=\"selected\"";?>>Sudan</option>
                            <option value="SR"<?php if ($internal_account['country']=="SR") echo " selected=\"selected\"";?>>Suriname</option>
                            <option value="SJ"<?php if ($internal_account['country']=="SJ") echo " selected=\"selected\"";?>>Svalbard And Jan Mayen</option>
                            <option value="SZ"<?php if ($internal_account['country']=="SZ") echo " selected=\"selected\"";?>>Swaziland</option>
                            <option value="SE"<?php if ($internal_account['country']=="SE") echo " selected=\"selected\"";?>>Sweden</option>
                            <option value="CH"<?php if ($internal_account['country']=="CH") echo " selected=\"selected\"";?>>Switzerland</option>
                            <option value="SY"<?php if ($internal_account['country']=="SY") echo " selected=\"selected\"";?>>Syrian Arab Republic</option>
                            <option value="TW"<?php if ($internal_account['country']=="TW") echo " selected=\"selected\"";?>>Taiwan, Province Of China</option>
                            <option value="TJ"<?php if ($internal_account['country']=="TJ") echo " selected=\"selected\"";?>>Tajikistan</option>
                            <option value="TZ"<?php if ($internal_account['country']=="TZ") echo " selected=\"selected\"";?>>Tanzania, United Republic Of</option>
                            <option value="TH"<?php if ($internal_account['country']=="TH") echo " selected=\"selected\"";?>>Thailand</option>
                            <option value="TL"<?php if ($internal_account['country']=="TL") echo " selected=\"selected\"";?>>Timor-Leste</option>
                            <option value="TG"<?php if ($internal_account['country']=="TG") echo " selected=\"selected\"";?>>Togo</option>
                            <option value="TK"<?php if ($internal_account['country']=="TK") echo " selected=\"selected\"";?>>Tokelau</option>
                            <option value="TO"<?php if ($internal_account['country']=="TO") echo " selected=\"selected\"";?>>Tonga</option>
                            <option value="TT"<?php if ($internal_account['country']=="TT") echo " selected=\"selected\"";?>>Trinidad And Tobago</option>
                            <option value="TN"<?php if ($internal_account['country']=="TN") echo " selected=\"selected\"";?>>Tunisia</option>
                            <option value="TR"<?php if ($internal_account['country']=="TR") echo " selected=\"selected\"";?>>Turkey</option>
                            <option value="TM"<?php if ($internal_account['country']=="TM") echo " selected=\"selected\"";?>>Turkmenistan</option>
                            <option value="TC"<?php if ($internal_account['country']=="TC") echo " selected=\"selected\"";?>>Turks And Caicos Islands</option>
                            <option value="TV"<?php if ($internal_account['country']=="TV") echo " selected=\"selected\"";?>>Tuvalu</option>
                            <option value="UG"<?php if ($internal_account['country']=="UG") echo " selected=\"selected\"";?>>Uganda</option>
                            <option value="UA"<?php if ($internal_account['country']=="UA") echo " selected=\"selected\"";?>>Ukraine</option>
                            <option value="AE"<?php if ($internal_account['country']=="AE") echo " selected=\"selected\"";?>>United Arab Emirates</option>
                            <option value="GB"<?php if ($internal_account['country']=="GB") echo " selected=\"selected\"";?>>United Kingdom</option>
                            <option value="US"<?php if ($internal_account['country']=="US") echo " selected=\"selected\"";?>>United States</option>
                            <option value="UM"<?php if ($internal_account['country']=="UM") echo " selected=\"selected\"";?>>United States Minor Outlying Islands</option>
                            <option value="UY"<?php if ($internal_account['country']=="UY") echo " selected=\"selected\"";?>>Uruguay</option>
                            <option value="UZ"<?php if ($internal_account['country']=="UZ") echo " selected=\"selected\"";?>>Uzbekistan</option>
                            <option value="VU"<?php if ($internal_account['country']=="VU") echo " selected=\"selected\"";?>>Vanuatu</option>
                            <option value="VA"<?php if ($internal_account['country']=="VA") echo " selected=\"selected\"";?>>Vatican City State</option>
                            <option value="VE"<?php if ($internal_account['country']=="VE") echo " selected=\"selected\"";?>>Venezuela</option>
                            <option value="VN"<?php if ($internal_account['country']=="VN") echo " selected=\"selected\"";?>>Viet Nam</option>
                            <option value="VG"<?php if ($internal_account['country']=="VG") echo " selected=\"selected\"";?>>Virgin Islands, British</option>
                            <option value="VI"<?php if ($internal_account['country']=="VI") echo " selected=\"selected\"";?>>Virgin Islands, U.S.</option>
                            <option value="WF"<?php if ($internal_account['country']=="WF") echo " selected=\"selected\"";?>>Wallis And Futuna</option>
                            <option value="EH"<?php if ($internal_account['country']=="EH") echo " selected=\"selected\"";?>>Western Sahara</option>
                            <option value="YE"<?php if ($internal_account['country']=="YE") echo " selected=\"selected\"";?>>Yemen</option>
                            <option value="ZM"<?php if ($internal_account['country']=="ZM") echo " selected=\"selected\"";?>>Zambia</option>
                            <option value="ZW"<?php if ($internal_account['country']=="ZW") echo " selected=\"selected\"";?>>Zimbabwe</option>
                         </select>
						<span class="field_desc"><?php echo $language_message[90];?></span>
					</div>
					<div class="input_field">
						<label for="a11"><?php echo $language_message[91];?></label>
						<input class="mediumfield" name="account_phone" type="text" value="<?php echo htmlspecialchars($internal_account['phone']);?>" />
						<span class="field_desc"><?php echo $language_message[92];?></span>
					</div>
					<div class="input_field">
						<label for="a11"><?php echo $language_message[93];?></label>
						<input class="mediumfield" name="account_wwwurl" type="text" value="<?php echo htmlspecialchars($internal_account['wwwurl']);?>" />
						<span class="field_desc"><?php echo $language_message[94];?></span>
					</div>
					<div class="input_field">
						<label for="a11"><?php echo $language_message[95];?></label>
						<input class="mediumfield" name="account_facebook" type="text" value="<?php echo htmlspecialchars($internal_account['facebook']);?>" />
						<span class="field_desc"><?php echo $language_message[96];?></span>
					</div>
					<input class="submit" type="submit" name="account_internal_submit" value="<?php echo $language_message[97];?>" />
				</fieldset>
			</form>
			<form method="post" action="content.php?include=account">
				<fieldset>
					<legend><?php echo $language_message[98];?></legend>
					<div class="input_field" name="api_secretkey">
						<label for="a11"><?php echo $language_message[99];?></label>
						<input class="mediumfield" name="account_secretkey" type="text" value="<?php echo htmlspecialchars($internal_account['secretkey']);?>" />
						<span class="field_desc"><?php echo $language_message[100];?></span>
					</div>
					<input class="submit" type="submit" name="api_internal_submit" value="<?php echo $language_message[101];?>" />
				</fieldset>
			</form>
		</div>
	</div> 
</div>