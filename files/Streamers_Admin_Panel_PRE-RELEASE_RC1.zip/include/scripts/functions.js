function autodj_setup(configure) {
	switch (configure) {
		case '9999999' :
			$("#autodj_setup_id_1").fadeOut("slow");
			$("#content").animate({height:"100%"},1000);
		break;
		default :
			$("#autodj_setup_id_1").fadeIn("slow");
			$("#content").animate({height:"100%"},1000);
		break;
	}
}
function log_setup(configure) {
	switch (configure) {
		case '/dev/null' :
			$("#log_setup_id_1").fadeOut("slow");
			$("#log_setup_id_2").fadeOut("slow");
			$("#log_setup_id_3").fadeOut("slow");
			$("#log_setup_id_4").fadeOut("slow");
			$("#content").animate({height:"100%"},1000);
		break;
		default :
			$("#log_setup_id_1").fadeIn("slow");
			$("#log_setup_id_2").fadeIn("slow");
			$("#log_setup_id_3").fadeIn("slow");
			$("#log_setup_id_4").fadeIn("slow");
			$("#content").animate({height:"100%"},1000);
		break;
	}
}
function playlist_creation(version) {
	switch (version) {
		case '1' :
			$("#playlist_table_id").fadeIn("slow");
			$("#clear").fadeIn("slow");
			break;
		case '0' :
			$("#playlist_table_id").fadeOut("slow");
			$("#clear").fadeOut("slow");
			break;
	}
}
function setting_show(version) {
	switch (version) {
		case 'bash' :
			$("#ssh2_user").fadeOut("slow");
			$("#ssh2_pass").fadeOut("slow");
			$("#ssh2_port").fadeOut("slow");
			break;
		case 'ssh2' :
			$("#ssh2_user").fadeIn("slow");
			$("#ssh2_pass").fadeIn("slow");
			$("#ssh2_port").fadeIn("slow");
			break;
	}
}
function htaccess_create(version) {
	switch (version) {
		case '1' :
			$("#php_mp3").fadeIn("slow");
			$("#php_exe").fadeIn("slow");
			break;
		case '0' :
			$("#php_mp3").fadeOut("slow");
			$("#php_exe").fadeOut("slow");
			break;
	}
}
function w3c_enable(configure) {
	switch (configure) {
		case 'No' :
			$("#view_setting_show_w3c").fadeOut("slow");
		break;
		default :
			$("#view_setting_show_w3c").fadeIn("slow");
		break;
	}
}
function crossfade_enable(configure) {
	switch (configure) {
		case '1' :
			$("#crossfade_enable_hide").fadeIn("slow");
		break;
		default :
			$("#crossfade_enable_hide").fadeOut("slow");
		break;
	}
}
function setting_show_autodumpsrc(configure) {
	switch (configure) {
		case '0' :
			$("#view_setting_show_autodumpsrc").fadeOut("slow");
		break;
		default :
			$("#view_setting_show_autodumpsrc").fadeIn("slow");
		break;
	}
}