<?PHP
//	Streamers Admin Panel 3.2
//
//	Developer:
//	Main Coding: djcrackhome [Sebastian Graebner]
//	Thanks 2 Raimund Barendt, resh [Mathias Simon], hansy [Rico Reinheckel], Largo [Michael Savino] 
//
//	License:
//	Creative Commons Attribution-ShareAlike 3.0 Unported License
//		This work is licensed under the Creative Commons Attribution-ShareAlike 3.0 Unported License.
//		To view a copy of this license, visit http://creativecommons.org/licenses/by-sa/3.0/ or
//		send a letter to Creative Commons, 171 Second Street, Suite 300, San Francisco, California, 94105, USA.
//
//	URL:		http://www.streamerspanel.com
//	SUPPORT:	http://support.streamerspanel.com
//	MAIL:		info@streamerspanel.com
///////////////////////////////////////////////
//
//	FILENAME: ./include/autodj_bottom.php
//

error_reporting(0);
if ((!defined("_include_security")) || (!preg_match("/content.php/i", $_SERVER['PHP_SELF']))) {
    header('Location: ./../index.php?system_login='.md5(md5("access").date("H:i").$_SERVER['REMOTE_ADDR']));
	die();
}
if ($_GET['system_action']!="edit") {?>
<div id="content">
	<div class="box">
		<h2><?php echo $language_message["277"];?></h2>
		<div class="contact_top_menu">
			<div class="tool_top_menu">
				<div class="main_shorttool"><?php echo $language_message["278"];?></div>
				<div class="main_righttool">
					<h2><?php echo $language_message["279"];?></h2>
					<p><?php echo $language_message["280"];?></p>
				</div>
			</div>
			<table cellspacing="0" cellpadding="0">
				<thead>
					<tr>
						<th><?php echo $language_message["281"];?></th>
						<th><?php echo $language_message["282"];?></th>
						<th><?php echo $language_message["283"];?></th>
                        <th></th>
                        <th></th>
					</tr>
				</thead>
				<tbody>
					<?php
					if (mysql_num_rows($listing_sql_query)==0) {
						echo "<tr>
							<td colspan=\"5\">".$language_message["284"]."</td>
							</tr>";
					}
					else {
						while($internal_process_var = mysql_fetch_array($listing_sql_query)) {
							if ($internal_process_var['autopid'] != "9999999") {
								echo '<form action="content.php?include=autodj&edit='.htmlspecialchars($internal_process_var['id']).'&system_action=start" method="post" name="sc_transform'.htmlspecialchars($internal_process_var['portbase']).'">
									<tr>
									<td><a href="http://'.htmlspecialchars($internal_setting['system_host']).':'.htmlspecialchars($internal_process_var['portbase']).'/" target="_blank">'.htmlspecialchars($internal_setting['system_host']).'</a></td>
									<td><a href="http://'.htmlspecialchars($internal_setting['system_host']).':'.htmlspecialchars($internal_process_var['portbase']).'/" target="_blank">'.htmlspecialchars($internal_process_var['portbase']).'</a></td>
									<td><select name="pllist" class="playlistselect">';
								define('entries_per_page',100);
								if (!isset($_GET['filecount']) or !is_numeric($_GET['filecount'])) $offset = 1;
								else $offset = $_GET['filecount'];
								if ($offset == 1) {
									$listing_start = $offset * entries_per_page - entries_per_page;
								}
								else {
									$listing_start = $offset * entries_per_page - entries_per_page + 3;
								}
								$listing_end = $offset * entries_per_page + 2;
								$dirlisting = @scandir(dirname(__FILE__)."/../clients/".$internal_user_id."/".htmlspecialchars($internal_process_var['portbase'])."/configs/playlists/");
								if (!isset($dirlisting[$listing_start]));
								for($i=$listing_start;$i<=$listing_end;$i++) {
									if (($dirlisting[$i]!=".") && ($dirlisting[$i]!="..") && ($dirlisting[$i]!="")) {
										echo "<option class=\"playlistselectdrop\" value=\"".htmlspecialchars($dirlisting[$i])."\">".htmlspecialchars($dirlisting[$i])."</option>";
									}
								}
								if (count(scandir(dirname(__FILE__)."/../clients/".$internal_user_id."/".htmlspecialchars($internal_process_var['portbase'])."/configs/playlists/"))==2) {
									echo "<option class=\"playlistselectdrop\" value=\"\">Keine Playliste vorhanden</option>";
								}
								echo '</select>
									</td>
									<td><a class="selector" href="javascript:document.sc_transform'.htmlspecialchars($internal_process_var['portbase']).'.submit()">'.$language_message["285"].'</a></td>
									<td><a class="delete" href="content.php?include=autodj&edit='.htmlspecialchars($internal_process_var['id']).'&system_action=stop">'.$language_message["286"].'</a><a class="edit" href="content.php?include=autodj&edit='.htmlspecialchars($internal_process_var['id']).'&system_action=edit">'.$language_message["287"].'</a></td>
									</tr>
									</form>';
							}
						}
					}
					?>
				</tbody>
			</table>
			<?php
			if (mysql_num_rows($listing_sql_query)!=0) {
				echo "<ul class=\"paginator\">";
				$listing_limit_page = mysql_num_rows(mysql_query("SELECT * FROM internal_system_db_servers WHERE owner='".mysql_real_escape_string($internal_user_name)."'"));
				$i = 0;
				while($listing_limit_page > "0") {
					echo "<li><a href=\"content.php?include=server&listing_query=";
					if (($listing_query / $internal_listing_limit) == $i){
						echo "";
					}
					echo "$i\">$i</a></li>";
					$i++;
					$listing_limit_page -= $internal_listing_limit;
				}
				echo "</ul>";
			}
			?>
		</div>
	</div> 
</div>
<?php
} else {
?>
<div id="content">
	<div class="box">
		<h2><?php echo $language_message["288"]." ".htmlspecialchars($formedit_port);?></h2>
		<div class="contact_top_menu">
			<div class="tool_top_menu">
				<div class="main_shorttool"><?php echo $language_message["289"];?></div>
				<div class="main_righttool">
					<h2><?php echo $language_message["290"];?></h2>
					<p><?php echo $language_message["291"];?></p>
				</div>
			</div>
			<form method="post" action="content.php?include=autodj&edit=<?php echo htmlspecialchars($_GET['edit']);?>&system_action=edit">
				<fieldset>
					<legend><?php echo $language_message["292"];?></legend>
					<div class="input_field">
						<label for="a"><?php echo $language_message["293"];?></label>
						<input class="mediumfield" name="ip" type="text" value="<?php echo htmlspecialchars($internal_setting['system_host']);?>" disabled="disabled" />
						<span class="field_desc"><?php echo $language_message["294"];?></span>
					</div>
					<div class="input_field">
						<label for="a"><?php echo $language_message["295"];?></label>
						<input class="mediumfield" name="port" type="text" value="<?php echo htmlspecialchars($formedit_port);?>" disabled="disabled"  />
						<span class="field_desc"><?php echo $language_message["296"];?></span>
					</div>
					<div class="input_field">
						<label for="a"><?php echo $language_message["297"];?></label>
						<input class="mediumfield" name="pass" type="text" value="<?php echo htmlspecialchars($formedit_pass);?>" disabled="disabled" />
						<span class="field_desc"><?php echo $language_message["298"];?></span>
					</div>
					<div class="input_field">
						<label for="a"><?php echo $language_message["299"];?></label>
						<input class="mediumfield" name="bitr" type="text" value="<?php echo htmlspecialchars($formedit_bitr);?>" disabled="disabled"/>
						<span class="field_desc"><?php echo $language_message["300"];?></span>
					</div>
					<div class="input_field">
						<label for="a"><?php echo $language_message["301"];?></label>
						<input class="mediumfield" name="titl" type="text" value="<?php echo htmlspecialchars($formedit_titl);?>" />
						<span class="field_desc"><?php echo $language_message["302"];?></span>
					</div>
					<div class="input_field">
						<label for="a6"><?php echo $language_message["303"];?></label>
						<input class="mediumfield" name="surl" type="text" value="<?php echo htmlspecialchars($formedit_surl);?>" />
						<span class="field_desc"><?php echo $language_message["304"];?></span>
					</div>
					<div class="input_field">
						<label for="a7"><?php echo $language_message["305"];?></label>
						<input class="mediumfield" name="genr" type="text" value="<?php echo htmlspecialchars($formedit_genr);?>" />
						<span class="field_desc"><?php echo $language_message["306"];?></span>
					</div>
					<div class="input_field">
						<label for="a8"><?php echo $language_message["307"];?></label>
                        <select class="formselect_loca" name="shuf"><option value="1"<?php if ($formedit_shuf=="1") { echo ' selected="selected"'; } ?>>Musik wird zuf&auml;llig wiedergegeben</option><option value="0"<?php if ($formedit_shuf=="0") { echo ' selected="selected"'; } ?>>Musik wird in Reihenfolge wiedergegeben</option></select>
						<span class="field_desc"><?php echo $language_message["308"];?></span>
					</div>
					<div class="input_field">
						<label for="a10"><?php echo $language_message["309"];?></label>
                        <select class="formselect_loca" name="qual"><option value="1"<?php if ($formedit_qual=="1") { echo ' selected="selected"'; } ?>>Höchste Streaming Qualit&auml;t [1]</option><option value="3"<?php if ($formedit_qual=="3") { echo ' selected="selected"'; } ?>>Hohe Streaming Qualit&auml;t [3]</option><option value="5"<?php if ($formedit_qual=="5") { echo ' selected="selected"'; } ?>>Mittlere Streaming Qualit&auml;t [5]</option><option value="7"<?php if ($formedit_qual=="7") { echo ' selected="selected"'; } ?>>Niedrige Streaming Qualit&auml;t [7]</option><option value="10"<?php if ($formedit_qual=="10") { echo ' selected="selected"'; } ?>>Niedrigste Streaming Qualit&auml;t [10]</option></select>
						<span class="field_desc"><?php echo $language_message["310"];?></span>
					</div>
					<div class="input_field">
						<label for="a11"><?php echo $language_message["311"];?></label>
                        <select class="formselect_loca" name="crom" onchange="crossfade_enable(value);"><option value="1"<?php if ($formedit_crom=="1") { echo ' selected="selected"'; } ?>>Crossfade zwischen Songs aktiviert</option><option value="0"<?php if ($formedit_crom=="0") { echo ' selected="selected"'; } ?>>Crossfade zwischen Songs deaktiviert</option></select>
						<span class="field_desc"><?php echo $language_message["312"];?></span>
					</div>
					<div class="input_field" id="crossfade_enable_hide"<?php if ($formedit_crom=="0") echo " style=\"display:none;\""; ?>>
						<label for="a12"><?php echo $language_message["313"];?></label>
						<input class="mediumfield" name="crol" type="text" value="<?php echo htmlspecialchars($formedit_crol);?>" />
						<span class="field_desc"><?php echo $language_message["314"];?></span>
					</div>
					<div class="input_field">
						<label for="a13"><?php echo $language_message["315"];?></label>
						<input class="mediumfield" name="samp" type="text" value="<?php echo htmlspecialchars($formedit_samp);?>" />
						<span class="field_desc"><?php echo $language_message["316"];?></span>
					</div>
					<div class="input_field">
						<label for="a14"><?php echo $language_message["317"];?></label>
                        <select class="formselect_loca" name="uid3"><option value="1"<?php if ($formedit_uid3=="1") { echo " selected=\"selected\"";}?>>Medien ID3 wird f&uuml;r den Stream benutzt</option><option value="0"<?php if ($formedit_uid3=="0") { echo " selected=\"selected\"";}?>>Dateiname wird f&uuml;r den Stream benutzt</option></select>
						<span class="field_desc"><?php echo $language_message["318"];?></span>
					</div>
					<div class="input_field">
						<label for="a15"><?php echo $language_message["319"];?></label>
                        <select class="formselect_loca" name="publ"><option value="1"<?php if ($formedit_publ=="1") { echo " selected=\"selected\"";}?>>Medienstream wird in die YP gelistet</option><option value="0"<?php if ($formedit_publ=="0") { echo " selected=\"selected\"";}?>>Medienstream wird nicht in YP gelistet</option></select>
						<span class="field_desc"><?php echo $language_message["320"];?></span>
					</div>
					<div class="input_field">
						<label for="a5"><?php echo $language_message["321"];?></label>
                        <select class="formselect_loca" name="chan"><option value="1"<?php if ($formedit_chan=="1") { echo " selected=\"selected\"";}?>>AutoDJ wird in Mono ausgegeben</option><option value="2"<?php if ($formedit_chan=="2") { echo " selected=\"selected\"";}?>>AutoDJ wird in Stereo ausgegeben</option></select>
						<span class="field_desc"><?php echo $language_message["322"];?></span>
					</div>
					<div class="input_field">
						<label for="a16"><?php echo $language_message["323"];?></label>
						<input class="mediumfield" name="maim" type="text" value="<?php echo htmlspecialchars($formedit_maim);?>" />
						<span class="field_desc"><?php echo $language_message["324"];?></span>
					</div>
					<div class="input_field">
						<label for="a17"><?php echo $language_message["325"];?></label>
						<input class="mediumfield" name="micq" type="text" value="<?php echo htmlspecialchars($formedit_micq);?>" />
						<span class="field_desc"><?php echo $language_message["326"];?></span>
					</div>
					<div class="input_field">
						<label for="a18"><?php echo $language_message["327"];?></label>
						<input class="mediumfield" name="mirc" type="text" value="<?php echo htmlspecialchars($formedit_mirc);?>" />
						<span class="field_desc"><?php echo $language_message["328"];?></span>
					</div>
					<input class="submit" type="submit" name="submit" value="<?php echo $language_message["329"];?>" />
					<input class="submit" type="reset" value="<?php echo $language_message["330"];?>" onclick="document.location='content.php?include=autodj';" />
				</fieldset>
			</form>
		</div>
	</div>
</div>
<?php } ?>