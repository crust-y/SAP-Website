<?PHP
//	Streamers Admin Panel 3.2
//
//	Developer:
//	Main Coding: djcrackhome [Sebastian Graebner]
//	Thanks 2 Raimund Barendt, resh [Mathias Simon], hansy [Rico Reinheckel], Largo [Michael Savino] 
//
//	License:
//	Creative Commons Attribution-ShareAlike 3.0 Unported License
//		This work is licensed under the Creative Commons Attribution-ShareAlike 3.0 Unported License.
//		To view a copy of this license, visit http://creativecommons.org/licenses/by-sa/3.0/ or
//		send a letter to Creative Commons, 171 Second Street, Suite 300, San Francisco, California, 94105, USA.
//
//	URL:		http://www.streamerspanel.com
//	SUPPORT:	http://support.streamerspanel.com
//	MAIL:		info@streamerspanel.com
///////////////////////////////////////////////
//
//	FILENAME: ./include/admuser_top.php
//

error_reporting(0);
if ((!defined("_include_security")) || (!preg_match("/content.php/i", $_SERVER['PHP_SELF']))) {
    header('Location: ./../index.php?system_login='.md5(md5("access").date("H:i").$_SERVER['REMOTE_ADDR']));
	die();
}
$internal_setting_query = mysql_query("SELECT * FROM internal_system_db_mainsetting WHERE id='0'") or die($language_message["g5"]);
foreach(mysql_fetch_array($internal_setting_query) as $internal_setting_query_key => $internal_setting_query_preference) {
	if (!is_numeric($internal_setting_query_key)) {
		$internal_setting[$internal_setting_query_key] = stripslashes($internal_setting_query_preference);
	}
}
$internal_listing_limit = mysql_real_escape_string(trim($internal_setting['system_limit']));
if (!isset($_GET['listing_query'])) $listing_query = 0;
else $listing_query = mysql_real_escape_string($_GET['listing_query'] * $internal_listing_limit);
$listing_query_limitery = $listing_query + $internal_listing_limit;
$listing_sql_query = mysql_query("SELECT * FROM internal_system_db_servers WHERE owner='".$internal_user_name."' ORDER BY id ASC LIMIT $listing_query,$internal_listing_limit");
if ($_GET['system_action'] == "new_user" && $_GET['function'] == "update") {
	if (mysql_num_rows(mysql_query("SELECT * FROM internal_system_db_users WHERE username='".mysql_real_escape_string(strip_tags($_POST['username']))."'"))== 1) {
		$usermessage_red[] = "<h2>".$language_message[319]."</h2>";
	}
	else {
		$internal_user_create_id = mysql_result(mysql_query("SELECT id FROM internal_system_db_users order by id DESC"),0) + 1;
		if (($_POST['account_password']) == ($_POST['account_password_repeat'])) {
			if (mysql_query("INSERT INTO internal_system_db_users (username, md5_hash, user_level, user_email, firstname, lastname, dateofbirth, street, city, zipcode, state, country, phone, wwwurl, facebook, timestamp, secretkey) VALUES('".mysql_real_escape_string(strip_tags($_POST['username']))."', '".md5(mysql_real_escape_string($_POST['username']).mysql_real_escape_string($_POST['account_password']))."', '".mysql_real_escape_string(strip_tags($_POST['user_level']))."', '".mysql_real_escape_string(strip_tags($_POST['user_email']))."', '".mysql_real_escape_string(strip_tags($_POST['firstname']))."', '".mysql_real_escape_string(strip_tags($_POST['lastname']))."', '".mysql_real_escape_string(strip_tags($_POST['dateofbirth']))."', '".mysql_real_escape_string(strip_tags($_POST['street']))."', '".mysql_real_escape_string(strip_tags($_POST['city']))."', '".mysql_real_escape_string(strip_tags($_POST['zipcode']))."', '".mysql_real_escape_string(strip_tags($_POST['state']))."', '".mysql_real_escape_string(strip_tags($_POST['country']))."', '".mysql_real_escape_string(strip_tags($_POST['phone']))."', '".mysql_real_escape_string(strip_tags($_POST['wwwurl']))."', '".mysql_real_escape_string(strip_tags($_POST['facebook']))."', '".mysql_real_escape_string(time())."', '".mysql_real_escape_string(md5((time()*1.000458340231195-313499)))."') ")) {
				mail("".strip_tags($_POST['user_email'])."", "Streamers Admin Panel - Ihr neuer Benutzeraccount '".$internal_user_name."'", $language_message["588_1"]."'".htmlspecialchars($internal_user_name)."'".$language_message["588_2"].htmlspecialchars($internal_contact_reasonsql).$language_message["588_3"]."http".($_SERVER['HTTPS']?'s':null)."://".$_SERVER['HTTP_HOST'].$_SERVER['PHP_SELF'].$language_message["588_4"], "From: noreply@".$_SERVER['HTTP_HOST']."\r\n");
				$usermessage_gre[] = "<h2>".$language_message["268"]."</h2>";
				$internal_removal_user_server = mysql_query("SELECT id FROM internal_system_db_users WHERE owner='".mysql_real_escape_string(strip_tags($_POST['username']))."' ORDER BY id ASC");
				$internal_new_server_folder = umask(0);
				if (!file_exists("".$internal_setting["system_dir"]."clients/".mysql_result($internal_id_owner,0)."/")) @mkdir("".$internal_setting["system_dir"]."clients/".mysql_result($internal_id_owner,0)."/", 0777);
				umask($internal_new_server_folder);
			}
			else {
				$usermessage_red[] = "<h2>".$language_message["269"]."</h2>";
			}
		}
		else {
			$usermessage_yel[] = "<h2>".$language_message["82"]."</h2>";
		}
	}
}
if (($_GET['system_action'] == "edit") && ($_GET['function']=="update")) { 
	$internal_user_update_query = mysql_query("SELECT username FROM internal_system_db_users WHERE id='".mysql_real_escape_string(trim($_GET['edit']))."'");
	if (mysql_num_rows($internal_user_update_query)==0) {
		$usermessage_red[] = "<h2>".$language_message["270"]."</h2>";
	}
	else {
		if ($_POST['account_password']!="**********") {
			if ($_POST['account_password']==$_POST['account_password_repeat']) {
				if (mysql_query("UPDATE internal_system_db_users SET md5_hash='".md5(mysql_real_escape_string(mysql_result($internal_user_update_query,0).$_POST['account_password']))."' WHERE id='".mysql_real_escape_string(trim($_GET['edit']))."'")) {
						$internal_check_pass=TRUE;
				}
			}
			else {
				$usermessage_yel[] = "<h2>".$language_message["82"]."</h2>";
			}
		}
		if (mysql_query("UPDATE internal_system_db_users SET user_level='".mysql_real_escape_string(strip_tags($_POST['user_level']))."', user_email='".mysql_real_escape_string(strip_tags($_POST['user_email']))."', firstname='".mysql_real_escape_string(strip_tags($_POST['firstname']))."', lastname='".mysql_real_escape_string(strip_tags($_POST['lastname']))."', dateofbirth='".mysql_real_escape_string(strip_tags($_POST['dateofbirth']))."', street='".mysql_real_escape_string(strip_tags($_POST['street']))."', city='".mysql_real_escape_string(strip_tags($_POST['city']))."', zipcode='".mysql_real_escape_string(strip_tags($_POST['zipcode']))."', state='".mysql_real_escape_string(strip_tags($_POST['state']))."', country='".mysql_real_escape_string(strip_tags($_POST['country']))."', phone='".mysql_real_escape_string(strip_tags($_POST['phone']))."', wwwurl='".mysql_real_escape_string(strip_tags($_POST['wwwurl']))."', facebook='".mysql_real_escape_string(strip_tags($_POST['facebook']))."' WHERE id='".mysql_real_escape_string(trim($_GET['edit']))."'"))
				$usermessage_gre[] = "<h2>".$language_message["173"]."</h2>";
			else
			$usermessage_red[] = "<h2>".$language_message["174"]."</h2>";
		
	}
}
if (is_numeric($_GET['edit']) && ($_GET['function']=="delete")) { 
	$internal_removal_user_query = mysql_query("SELECT user_level FROM internal_system_db_users WHERE id='".mysql_real_escape_string(trim($_GET['edit']))."'");
	if (mysql_result($internal_removal_user_query,0)==$internal_user_name)
			$usermessage_red[] = "<h2>".$language_message["273"]."</h2>";
	else {
		if (mysql_result($internal_removal_user_query,0) == "Super Administrator")
			$usermessage_red[] = "<h2>".$language_message["274"]."</h2>";
		else {
			//	Found on 'ozzu.com' from the post by 'placid psychosis' on July 5th, 2005 --START
			function delete_directory($dirname) {
				if (is_dir($dirname))
					$dir_handle = opendir($dirname);
				if (!$dir_handle)
					return false;
				while($file = readdir($dir_handle)) {
					if ($file != "." && $file != "..") {
						if (!is_dir($dirname."/".$file))
							@unlink($dirname."/".$file);
						else
							delete_directory($dirname.'/'.$file); 
					}
				}
				@closedir($dir_handle);
				@rmdir($dirname);
			}
			//	--END
			$internal_removal_user = mysql_query("SELECT username FROM internal_system_db_users WHERE id='".mysql_real_escape_string(trim($_GET['edit']))."'");
			$internal_removal_user_server = mysql_query("SELECT id FROM internal_system_db_servers WHERE owner='".mysql_real_escape_string(mysql_result($internal_removal_user,0))."' ORDER BY id ASC");
			if (mysql_num_rows($internal_removal_user_server)!=0) {
				foreach(mysql_fetch_array($internal_removal_user_server) as $internal_removal_user_server_key => $internal_removal_user_server_preference) {
					$internal_removal_user_server = mysql_query("SELECT portbase FROM internal_system_db_servers WHERE id='".mysql_real_escape_string(trim($internal_removal_user_server_preference))."' ORDER BY id ASC");
					internal_function_sctrans_stop(mysql_real_escape_string(trim($internal_removal_user_server_preference)), mysql_real_escape_string(mysql_result($internal_removal_user,0)));
					internal_function_shoutcast_stop(mysql_real_escape_string(trim($internal_removal_user_server_preference)), mysql_real_escape_string(mysql_result($internal_removal_user,0)));
					delete_directory("".$internal_setting["system_dir"]."clients/".trim($internal_removal_user_server_preference)."/".mysql_result($internal_removal_user_server,0)."/uploads/audio");
					delete_directory("".$internal_setting["system_dir"]."clients/".trim($internal_removal_user_server_preference)."/".mysql_result($internal_removal_user_server,0)."/uploads/video");
					delete_directory("".$internal_setting["system_dir"]."clients/".trim($internal_removal_user_server_preference)."/".mysql_result($internal_removal_user_server,0)."/configs/playlists");
					sleep(1);
					delete_directory("".$internal_setting["system_dir"]."clients/".trim($internal_removal_user_server_preference)."/".mysql_result($internal_removal_user_server,0)."/logs");
					delete_directory("".$internal_setting["system_dir"]."clients/".trim($internal_removal_user_server_preference)."/".mysql_result($internal_removal_user_server,0)."/soundfiles");
					delete_directory("".$internal_setting["system_dir"]."clients/".trim($internal_removal_user_server_preference)."/".mysql_result($internal_removal_user_server,0)."/contentdir");
					delete_directory("".$internal_setting["system_dir"]."clients/".trim($internal_removal_user_server_preference)."/".mysql_result($internal_removal_user_server,0)."/configs");
					delete_directory("".$internal_setting["system_dir"]."clients/".trim($internal_removal_user_server_preference)."/".mysql_result($internal_removal_user_server,0)."/uploads");
					sleep(1);
					delete_directory("".$internal_setting["system_dir"]."clients/".trim($internal_removal_user_server_preference)."/".mysql_result($internal_removal_user_server,0));
					mysql_query("DELETE FROM internal_system_db_servers WHERE id='".mysql_real_escape_string(trim($internal_removal_user_server_preference))."'");
				}
			}
			delete_directory("".$internal_setting["system_dir"]."clients/".trim($_GET['edit'])."");
			if (mysql_query("DELETE FROM internal_system_db_users WHERE id='".mysql_real_escape_string(trim($_GET['edit']))."'"))
				$usermessage_gre[] = "<h2>".$language_message["275"]."</h2>";
			else 
				$usermessage_red[] = "<h2>".$language_message["276"]."</h2>";
		}
	}
}	
?>