<?PHP
//	Streamers Admin Panel 3.2
//
//	Developer:
//	Main Coding: djcrackhome [Sebastian Graebner]
//	Thanks 2 Raimund Barendt, resh [Mathias Simon], hansy [Rico Reinheckel], Largo [Michael Savino] 
//
//	License:
//	Creative Commons Attribution-ShareAlike 3.0 Unported License
//		This work is licensed under the Creative Commons Attribution-ShareAlike 3.0 Unported License.
//		To view a copy of this license, visit http://creativecommons.org/licenses/by-sa/3.0/ or
//		send a letter to Creative Commons, 171 Second Street, Suite 300, San Francisco, California, 94105, USA.
//
//	URL:		http://www.streamerspanel.com
//	SUPPORT:	http://support.streamerspanel.com
//	MAIL:		info@streamerspanel.com
///////////////////////////////////////////////
//
//	FILENAME: ./include/upload_top.php
//

error_reporting(0);
if ((!defined("_include_security")) || (!preg_match("/content.php/i", $_SERVER['PHP_SELF']))) {
    header('Location: ./../index.php?system_login='.md5(md5("access").date("H:i").$_SERVER['REMOTE_ADDR']));
	die();
}
$internal_setting_query = mysql_query("SELECT * FROM internal_system_db_mainsetting WHERE id='0'") or die($language_message["g5"]);
foreach(mysql_fetch_array($internal_setting_query) as $internal_setting_query_key => $internal_setting_query_preference) {
	if (!is_numeric($internal_setting_query_key)) {
		$internal_setting[$internal_setting_query_key] = stripslashes($internal_setting_query_preference);
	}
}
if((!empty($_FILES["uploaded_file"])) && ($_FILES['uploaded_file']['error'] == 0)) {
	if (!isset($_GET['portbase'])) {
		header('Location: content.php?include=music&error=port');
		die();
	}
	else $internal_upload_portbase = $_GET['portbase'];
	$internal_server_owner_query = mysql_query("SELECT * FROM internal_system_db_servers WHERE portbase='".mysql_real_escape_string(trim($internal_upload_portbase))."' AND owner='".mysql_real_escape_string(trim($internal_user_name))."'");
	if (mysql_num_rows($internal_server_owner_query)!=1) {
		header('Location: content.php?include=music&error=access');
		die();
	}
	$internal_server_space = mysql_query("SELECT * FROM internal_system_db_servers WHERE portbase='".mysql_real_escape_string(trim($internal_upload_portbase))."'") or die ();
	$internal_server_space = mysql_fetch_array($internal_server_space); 
	if (file_exists($internal_setting["system_dir"]."clients/".$internal_user_id."/".htmlspecialchars($internal_upload_portbase)."/uploads/audio/")) $internal_upload_portbase_use = $internal_upload_portbase;
	else {
		$internal_umask = umask(0);
		mkdir($internal_setting["system_dir"]."clients/".$internal_user_id."/".htmlspecialchars($internal_upload_portbase)."/uploads/audio/", 0777);
		umask($internal_umask);
		$internal_upload_portbase_use = $internal_upload_portbase;
		if ($internal_umask != umask()) {
			header('Location: content.php?include=music&error=dir');
			die ();
		}
	}
	$actual_dir_size = (internal_folder_space($internal_setting["system_dir"]."clients/".$internal_user_id."/".htmlspecialchars($internal_upload_portbase)."/uploads/audio/")+internal_folder_space($internal_setting["system_dir"]."clients/".$internal_user_id."/".htmlspecialchars($internal_upload_portbase)."/uploads/video"));
	$filename = basename($_FILES['uploaded_file']['name']);
	$ext = substr($filename, strrpos($filename, '.') + 1);
	$file_size_m = str_replace("M","",ini_get("upload_max_filesize"));
	if ($_FILES["uploaded_file"]["size"] >= (($internal_server_space['webspace']*1024)-$actual_dir_size*1024)) {
		$usermessage_red[] = "<h2>".$language_message["549"]."</h2>";
	}
	else {
		if (($ext == "mp3") && ($_FILES["uploaded_file"]["size"] < ($file_size_m*1024)*1024) && (($_FILES["uploaded_file"]["type"] == "audio/mpeg") || ($_FILES["uploaded_file"]["type"] == "audio/mpeg3") || ($_FILES["uploaded_file"]["type"] == "audio/ext") || ($_FILES["uploaded_file"]["type"] == "audio/x-mpeg-3") || ($_FILES["uploaded_file"]["type"] == "application/octet-stream") || ($_FILES["uploaded_file"]["type"] == "application/force-download") || ($_FILES["uploaded_file"]["type"] == "application/octetstream") || ($_FILES["uploaded_file"]["type"] == "x-cms/x-unknown") || ($_FILES["uploaded_file"]["type"] == "audio/x-amzaudio") || ($_FILES["uploaded_file"]["type"] == "application/x-download"))) {
			$newname = $internal_setting["system_dir"]."clients/".$internal_user_id."/".htmlspecialchars($internal_upload_portbase)."/uploads/audio/".$filename;
			if (!file_exists($newname)) {
				if ((move_uploaded_file($_FILES['uploaded_file']['tmp_name'],$newname))) {
					chmod ($newname, 0755);
					$usermessage_gre[] = "<h2>".$language_message["550"]."</h2>";
					$playlistupdate = "1";
				}
				else {
					$usermessage_red[] = "<h2>".$language_message["551"]."</h2>";
				}
			} 
			else {
				$usermessage_red[] = "<h2>".$language_message["552"]."</h2>";
			}
		}
		else {
			$usermessage_red[] = "<h2>".$language_message["553"]."</h2>";
		}
	}
	$actual_dir_size = (internal_folder_space($internal_setting["system_dir"]."clients/".$internal_user_id."/".htmlspecialchars($internal_upload_portbase)."/uploads/audio/")+internal_folder_space($internal_setting["system_dir"]."clients/".$internal_user_id."/".htmlspecialchars($internal_upload_portbase)."/uploads/video"));
} 
else {
	if (!isset($_GET['portbase'])) {
		header('Location: content.php?include=music&error=port');
		die ();
	}
	else $internal_upload_portbase=trim($_GET['portbase']);
	$internal_upload_portbase = strip_tags(preg_replace('#/#','', $internal_upload_portbase));
	$autopid_check_sql = mysql_query("SELECT autopid FROM internal_system_db_servers WHERE portbase='".mysql_real_escape_string(trim($internal_upload_portbase))."' AND owner='".mysql_real_escape_string(trim($internal_user_name))."'");
	if (mysql_result($autopid_check_sql,0) == "9999999") {
		header('Location: content.php?include=music&error=access');
		die ();
	}
	$selectowner = mysql_query("SELECT * FROM internal_system_db_servers WHERE portbase='".mysql_real_escape_string(trim($internal_upload_portbase))."' AND owner='".mysql_real_escape_string(trim($internal_user_name))."'");
	if (mysql_num_rows($selectowner)!=1) {
		header('Location: content.php?include=music&error=access');
		die ();
	}
	if (isset($_GET['delete'])) {
		$deletefiledecoded = base64_decode($_GET['delete']);
		if (file_exists($internal_setting["system_dir"]."clients/".$internal_user_id."/".htmlspecialchars($internal_upload_portbase)."/uploads/audio/".$deletefiledecoded."")) {
			unlink($internal_setting["system_dir"]."clients/".$internal_user_id."/".htmlspecialchars($internal_upload_portbase)."/uploads/audio/".$deletefiledecoded."");
			$usermessage_gre[] = "<h2>".$language_message["556"]."</h2>";
			$playlistupdate = "2";
		}
		else {
			$usermessage_red[] = "<h2>".$language_message["557"]."</h2>";
		}
	}
	if (isset($_GET['download'])) {
		$downloadiddecode=base64_decode($_GET['download']);
		if (file_exists($internal_setting["system_dir"]."clients/".$internal_user_id."/".htmlspecialchars($internal_upload_portbase)."/uploads/audio/".$downloadiddecode."")) {
			$filename = $internal_setting["system_dir"]."clients/".$internal_user_id."/".htmlspecialchars($internal_upload_portbase)."/uploads/audio/".$downloadiddecode."";
			if(ini_get("zlib.output_compression")) ini_set("zlib.output_compression", "Off");
			header("Pragma: public");
			header("Expires: 0");
			header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
			header("Cache-Control: private",false);
			header("Content-Type: audio/mpeg; charset=".$language_message["g0"]); 
			header("Content-Disposition: attachment; filename=\"".basename($filename)."\";" );  
			header("Content-Transfer-Encoding: binary");
			header("Content-Length: ".filesize($filename));
			readfile("$filename");
			exit();	
		}
		else {
			$usermessage_red[] = "<h2>".$language_message["558"]."</h2>";
		}
	}
	$internal_server_space_query = mysql_query("SELECT * FROM internal_system_db_servers WHERE portbase='".mysql_real_escape_string(trim($internal_upload_portbase))."'") or die ();
	$internal_server_space = mysql_fetch_array($internal_server_space_query); 
	$internal_upload_portbase = strip_tags(preg_replace('#/#','', $internal_upload_portbase));
	$actual_dir_size = (internal_folder_space($internal_setting["system_dir"]."clients/".$internal_user_id."/".htmlspecialchars($internal_upload_portbase)."/uploads/audio/")+internal_folder_space($internal_setting["system_dir"]."clients/".$internal_user_id."/".htmlspecialchars($internal_upload_portbase)."/uploads/video"));	
}
$dirlistdir = @opendir($internal_setting["system_dir"]."clients/".$internal_user_id."/".htmlspecialchars($internal_upload_portbase)."/uploads/audio") or $usermessage_red[] = "<h2>".$language_message["561"]."</h2>";
define('entries_per_page',7);
if (!isset($_GET['filecount']) or !is_numeric($_GET['filecount'])) $offset = 1;
else $offset = $_GET['filecount'];
if ($offset == 1) {
	$listing_start = $offset * entries_per_page - entries_per_page;
}
else {
	$listing_start = $offset * entries_per_page - entries_per_page + 3;
}					
$listing_end = $offset * entries_per_page + 2;
$dirlisting = @scandir($internal_setting["system_dir"]."clients/".$internal_user_id."/".htmlspecialchars($internal_upload_portbase)."/uploads/audio") or $usermessage_red[] = "<h2>".$language_message["562"]."</h2>";
if (!isset($dirlisting[$listing_start])) $usermessage_red[] = "<h2>".$language_message["563"]."</h2>";
?>