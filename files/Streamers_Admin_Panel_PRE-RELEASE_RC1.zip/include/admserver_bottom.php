<?PHP
//	Streamers Admin Panel 3.2
//
//	Developer:
//	Main Coding: djcrackhome [Sebastian Graebner]
//	Thanks 2 Raimund Barendt, resh [Mathias Simon], hansy [Rico Reinheckel], Largo [Michael Savino] 
//
//	License:
//	Creative Commons Attribution-ShareAlike 3.0 Unported License
//		This work is licensed under the Creative Commons Attribution-ShareAlike 3.0 Unported License.
//		To view a copy of this license, visit http://creativecommons.org/licenses/by-sa/3.0/ or
//		send a letter to Creative Commons, 171 Second Street, Suite 300, San Francisco, California, 94105, USA.
//
//	URL:		http://www.streamerspanel.com
//	SUPPORT:	http://support.streamerspanel.com
//	MAIL:		info@streamerspanel.com
///////////////////////////////////////////////
//
//	FILENAME: ./include/admserver_bottom.php
//

error_reporting(0);
if ((!defined("_include_security")) || (!preg_match("/content.php/i", $_SERVER['PHP_SELF']))) {
    header('Location: ./../index.php?system_login='.md5(md5("access").date("H:i").$_SERVER['REMOTE_ADDR']));
	die();
}
?>
<div id="content">
	<div class="box">
		<h2><?php echo $language_message[224]."&nbsp;".$_SERVER['SERVER_ADDR'];?></h2>
		<div class="contact_top_menu">
			<div class="tool_top_menu">
				<div class="main_shorttool"><?php echo $language_message[225];?></div>
				<div class="main_righttool">
					<h2><?php echo $language_message[226];?></h2>
					<p><?php echo $language_message[227];?></p>
				</div>
			</div>
			<form method="post" action="content.php?include=admserver&action=savesettings">	
				<fieldset>
					<legend><?php echo $language_message[228];?></legend>
					<div class="input_field">
						<label for="a"><?php echo $language_message[229];?></label>
						<input class="mediumfield" name="system_host" type="text" value="<?php echo htmlspecialchars($internal_setting['system_host']);?>" />
						<span class="field_desc"><?php echo $language_message[230];?></span>
					</div>
					<div class="input_field">
						<label for="a"><?php echo $language_message[231];?></label>
                        <select class="formselect_loca" name="system_connection_type" onchange="setting_show(value);"><option value="bash"<?php if ($internal_setting['system_connection_type']=="bash") echo " selected=\"selected\"";?>><?php echo $language_message[232];?></option><option value="ssh2"<?php if ($internal_setting['system_connection_type']=="ssh2") echo " selected=\"selected\"";?>><?php echo $language_message[233];?></option></select>
						<span class="field_desc"><?php echo $language_message[234];?></span>
					</div>
					<div class="input_field" id="ssh2_user"<?php if ($internal_setting['system_connection_type']=="bash") echo " style=\"display: none;\"";?>>
						<label for="a"><?php echo $language_message[235];?></label>
						<input class="mediumfield" name="system_ssh_user" type="text" value="<?php echo htmlspecialchars(base64_decode($internal_setting['system_ssh_user']));?>" />
						<span class="field_desc"><?php echo $language_message[236];?></span>
					</div>
					<div class="input_field" id="ssh2_pass"<?php if ($internal_setting['system_connection_type']=="bash") echo " style=\"display: none;\"";?>>
						<label for="a"><?php echo $language_message[237];?></label>
						<input class="mediumfield" name="system_ssh_pass" type="text" value="<?php echo htmlspecialchars(base64_decode($internal_setting['system_ssh_pass']));?>" />
						<span class="field_desc"><?php echo $language_message[238];?></span>
					</div>
					<div class="input_field" id="ssh2_port"<?php if ($internal_setting['system_connection_type']=="bash") echo " style=\"display: none;\"";?>>
						<label for="a"><?php echo $language_message[239];?></label>
						<input class="mediumfield" name="system_ssh_port" type="text" value="<?php echo htmlspecialchars($internal_setting['system_ssh_port']);?>" />
						<span class="field_desc"><?php echo $language_message[240];?></span>
					</div>
					<div class="input_field">
						<label for="a"><?php echo $language_message[241];?></label>
						<input class="mediumfield" name="system_dir" type="text" value="<?php echo htmlspecialchars($internal_setting['system_dir']);?>" />
						<span class="field_desc"><?php echo $language_message[242];?></span>
					</div>
					<div class="input_field">
						<label for="a"><?php echo $language_message[243];?></label>
						<input class="mediumfield" name="system_title" type="text" value="<?php echo htmlspecialchars($internal_setting['system_title']);?>" />
						<span class="field_desc"><?php echo $language_message[244];?></span>
					</div>
					<div class="input_field">
						<label for="a"><?php echo $language_message[245];?></label>
						<input class="mediumfield" name="system_slogan" type="text" value="<?php echo htmlspecialchars($internal_setting['system_slogan']);?>" />
						<span class="field_desc"><?php echo $language_message[246];?></span>
					</div>
                    <div class="input_field">
						<label for="a"><?php echo $language_message[247];?></label>
                        <select class="formselect_loca" name="htaccess" onchange="htaccess_create(value);"><option value="1"<?php if ($internal_setting['system_php_mp3']!="0") { echo " selected=\"selected\"";}?>><?php echo $language_message[248];?></option><option value="0"<?php if ($internal_setting['system_php_mp3']=="0") { echo " selected=\"selected\"";}?>><?php echo $language_message[249];?></option></select>
						<span class="field_desc"><?php echo $language_message[250];?></span>
					</div>
					<div class="input_field" id="php_mp3"<?php if ($internal_setting['system_php_mp3']=="0") echo " style=\"display: none;\"";?>>
						<label for="a"><?php echo $language_message[251];?></label>
						<input class="mediumfield" name="system_php_mp3" type="text" value="<?php echo htmlspecialchars($internal_setting['system_php_mp3']);?>" />
						<span class="field_desc"><?php echo $language_message[252];?></span>
					</div>
					<div class="input_field" id="php_exe"<?php if ($internal_setting['system_php_mp3']=="0") echo " style=\"display: none;\"";?>>
						<label for="a"><?php echo $language_message[253];?></label>
						<input class="mediumfield" name="system_php_exe" type="text" value="<?php echo htmlspecialchars($internal_setting['system_php_exe']);?>" />
						<span class="field_desc"><?php echo $language_message[254];?></span>
					</div>
					<div class="input_field">
						<label for="a"><?php echo $language_message[255];?></label>
						<?php
						echo '<select name="system_lang" class="formselect_loca">';
						$dirlisting = @scandir(dirname(__FILE__)."/languages/");
						for($i=1;$i<=100;$i++) {
							if (($dirlisting[$i]!=".") and ($dirlisting[$i]!="..") and ($dirlisting[$i]!="")) {
								echo "<option";
								if (substr($dirlisting[$i], 0, -4) == $internal_setting['system_lang']) {
									echo " selected=\"selected\"";
								}
								echo " value=\"".htmlspecialchars(substr($dirlisting[$i], 0, -4))."\">".htmlspecialchars(ucfirst(substr($dirlisting[$i], 0, -4)))."</option>";
							}
						}
						echo '</select>';
						?>                        
						<span class="field_desc"><?php echo $language_message[256];?></span>
					</div>
					<div class="input_field">
						<label for="a"><?php echo $language_message[257];?></label>
                        <select class="formselect_loca" name="system_update"><option value="1"<?php if ($internal_setting['system_update']=="1") echo " selected=\"selected\"";?>><?php echo $language_message[258];?></option><option value="0"<?php if ($internal_setting['system_update']=="0") echo " selected=\"selected\"";?>><?php echo $language_message[259];?></option></select>
						<span class="field_desc"><?php echo $language_message[260];?></span>
					</div>
					<div class="input_field">
						<label for="a"><?php echo $language_message[261];?></label>
                        <select class="formselect_loca" name="system_scs_config"><option value="0"<?php if ($internal_setting['system_scs_config']=="0") echo " selected=\"selected\"";?>><?php echo $language_message[262];?></option><option value="1"<?php if ($internal_setting['system_scs_config']=="1") echo " selected=\"selected\"";?>><?php echo $language_message[263];?></option></select>
						<span class="field_desc"><?php echo $language_message[264];?></span>
					</div>
					<div class="input_field">
						<label for="a"><?php echo $language_message[265];?></label>
                        <select class="formselect_loca" name="system_adj_config"><option value="0"<?php if ($internal_setting['system_adj_config']=="0") echo " selected=\"selected\"";?>><?php echo $language_message[266];?></option><option value="1"<?php if ($internal_setting['system_adj_config']=="1") echo " selected=\"selected\"";?>><?php echo $language_message[267];?></option></select>
						<span class="field_desc"><?php echo $language_message[268];?></span>
					</div>
					<div class="input_field">
						<label for="a"><?php echo $language_message[269];?></label>
                        <select class="formselect_loca" name="system_captcha"><option value="1"<?php if ($internal_setting['system_captcha']=="1") echo " selected=\"selected\""; ?>><?php echo $language_message[270];?></option><option value="0"<?php if ($internal_setting['system_captcha']=="0") echo " selected=\"selected\"";?>><?php echo $language_message[271];?></option></select>
						<span class="field_desc"><?php echo $language_message[272];?></span>
					</div>
					<div class="input_field">
						<label for="a"><?php echo $language_message[273];?></label>
                        <select class="formselect_loca" name="system_news"><option value="1"<?php if ($internal_setting['system_news']=="1") echo " selected=\"selected\""; ?>><?php echo $language_message[274];?></option><option value="0"<?php if ($internal_setting['system_news']=="0") echo " selected=\"selected\"";?>><?php echo $language_message[275];?></option></select>
						<span class="field_desc"><?php echo $language_message[276];?></span>
					</div>
                    <?php
					/*	NOT IN PRERELEASE YET!
					if ($internal_setting['system_premium']=="1") { ?>
					<div class="input_field">
						<label for="a"><?php echo $language_message[277];?></label>
                        <select class="formselect_loca" name="system_win" disabled="disabled"><option value="1"<?php if ($internal_setting['system_win']=="1") echo " selected=\"selected\""; ?>><?php echo $language_message[278];?></option><option value="0"<?php if ($internal_setting['system_win']=="0") echo " selected=\"selected\"";?>><?php echo $language_message[279];?></option></select>
						<span class="field_desc"><?php echo $language_message[280];?></span>
					</div>
                    <?php 
					}
					*/ ?>
					<div class="input_field">
						<label for="a"><?php echo $language_message[281];?></label>
						<input class="mediumfield" name="system_logourl" type="text" value="<?php echo htmlspecialchars($internal_setting['system_logourl']);?>" />
						<span class="field_desc"><?php echo $language_message[282];?></span>
					</div>
					<div class="input_field">
						<label for="a"><?php echo $language_message[283];?></label>
						<input class="mediumfield" name="system_limit" type="text" value="<?php echo htmlspecialchars($internal_setting['system_limit']);?>" />
						<span class="field_desc"><?php echo $language_message[284];?></span>
					</div>
					<input class="submit" type="submit" name="submit" value="<?php echo $language_message[285];?>" />
				</fieldset>
			</form>
		</div>
	</div> 
</div>