<?PHP
//	Streamers Admin Panel 3.2
//
//	Developer:
//	Main Coding: djcrackhome [Sebastian Graebner]
//	Thanks 2 Raimund Barendt, resh [Mathias Simon], hansy [Rico Reinheckel], Largo [Michael Savino] 
//
//	License:
//	Creative Commons Attribution-ShareAlike 3.0 Unported License
//		This work is licensed under the Creative Commons Attribution-ShareAlike 3.0 Unported License.
//		To view a copy of this license, visit http://creativecommons.org/licenses/by-sa/3.0/ or
//		send a letter to Creative Commons, 171 Second Street, Suite 300, San Francisco, California, 94105, USA.
//
//	URL:		http://www.streamerspanel.com
//	SUPPORT:	http://support.streamerspanel.com
//	MAIL:		info@streamerspanel.com
///////////////////////////////////////////////
//
//	FILENAME: ./include/admradio_top.php
//

error_reporting(0);
if ((!defined("_include_security")) || (!preg_match("/content.php/i", $_SERVER['PHP_SELF']))) {
    header('Location: ./../index.php?system_login='.md5(md5("access").date("H:i").$_SERVER['REMOTE_ADDR']));
	die();
}
$internal_setting_query = mysql_query("SELECT * FROM internal_system_db_mainsetting WHERE id='0'") or die($language_message["g5"]);
foreach(mysql_fetch_array($internal_setting_query) as $internal_setting_query_key => $internal_setting_query_preference) {
	if (!is_numeric($internal_setting_query_key)) {
		$internal_setting[$internal_setting_query_key] = stripslashes($internal_setting_query_preference);
	}
}
if (($_GET['system_action']=="new_server") && isset($_POST['metainterval'])) {
	$internal_new_server_portexist = mysql_query("SELECT * FROM internal_system_db_servers WHERE portbase='".mysql_real_escape_string(strip_tags($_POST['portbase']))."'");
	if (mysql_num_rows($internal_new_server_portexist)>0) {
		$internal_new_server_port_query = mysql_query("SELECT portbase FROM internal_system_db_servers order by portbase DESC");
		$internal_new_server_port_newport = mysql_result($internal_new_server_port_query,0) + 2;
		$internal__message_notifi[] = "<h2>Port ".htmlspecialchars(strip_tags($_POST['portbase']))." ".$language_message[210].": ".$internal_new_server_port_newport."</h2>";
		$internal_new_server_port = $internal_new_server_port_newport;
	}
	else {
		$internal_new_server_port=mysql_real_escape_string(strip_tags($_POST['portbase']));
	}
	if (is_numeric($internal_new_server_port)) {
		$internal_new_server_replace_query = mysql_query("SELECT * FROM internal_system_db_users WHERE username='".mysql_real_escape_string(strip_tags($_POST['owner']))."'");
		while($internal_new_server_replace = mysql_fetch_array($internal_new_server_replace_query, MYSQL_ASSOC)) {
				$internal_new_server_replace_id	= $internal_new_server_replace['id'];
		}
		function replacing_loca_value($internal_server_replace_name, $internal_server_replace_location) {
			global $internal_new_server_replace_id;
			global $internal_new_server_port;
			if ($_POST[''.$internal_server_replace_name.'']==$internal_server_replace_location) {
				$internal_new_server_function_search  = array('_id_', '_port_');
				$internal_new_server_function_replace = array(''.$internal_new_server_replace_id.'', ''.$internal_new_server_port.'');
				return str_replace($internal_new_server_function_search, $internal_new_server_function_replace, $_POST[''.$internal_server_replace_name.'']);
			}
			elseif ($_POST[$internal_server_replace_name]!=$internal_server_replace_location) {
				return mysql_real_escape_string(strip_tags($_POST[''.$internal_server_replace_name.'']));
			}
		}
		function replacing_loca_value_empty($internal_server_replace_name, $internal_server_replace_location) {
			global $internal_new_server_replace_id;
			global $internal_new_server_port;
			if ($_POST[''.$internal_server_replace_name.'']==$internal_server_replace_location) {
				return '';
			}
			elseif ($_POST[''.$internal_server_replace_name.'']!=$internal_server_replace_location) {
				echo mysql_real_escape_string(strip_tags($_POST[''.$internal_server_replace_name.'']));
			}
		}
		if (mysql_query("INSERT INTO internal_system_db_servers (owner, adminpassword, password, portbase, maxuser, bitrate, autopid, webspace, logfile, realtime, tchlog, weblog, screenlog, w3cenable, w3clog, showlastsongs, srcip, destip, yport, namelookups, autodumpusers, autodumpsourcetime, contentdir, introfile, backupfile, titleformat, publicserver, relayserver, relayport, allowpublicrelay, metainterval, serverip, serverport) VALUES('".mysql_real_escape_string(strip_tags($_POST['owner']))."', '".mysql_real_escape_string(strip_tags($_POST['adminpassword']))."', '".mysql_real_escape_string(strip_tags($_POST['password']))."', '".$internal_new_server_port."', '".mysql_real_escape_string(strip_tags($_POST['maxuser']))."', '".mysql_real_escape_string(strip_tags($_POST['bitrate']))."', '".mysql_real_escape_string(strip_tags($_POST['autopid']))."', '".mysql_real_escape_string(strip_tags($_POST['webspace']*1024))."', '".replacing_loca_value("logfile", "".$internal_setting['system_dir']."clients/_id_/_port_/logs/sc_log.log")."', '".mysql_real_escape_string(strip_tags($_POST['realtime']))."', '".mysql_real_escape_string(strip_tags($_POST['tchlog']))."', '".mysql_real_escape_string(strip_tags($_POST['weblog']))."', '".mysql_real_escape_string(strip_tags($_POST['screenlog']))."', '".mysql_real_escape_string(strip_tags($_POST['w3cenable']))."', '".replacing_loca_value("w3clog", "".$internal_setting['system_dir']."clients/_id_/_port_/logs/w3c_log.log")."', '".mysql_real_escape_string(strip_tags($_POST['showlastsongs']))."', '".mysql_real_escape_string(strip_tags($_POST['srcip']))."', '".mysql_real_escape_string(strip_tags($_POST['destip']))."', '".mysql_real_escape_string(strip_tags($_POST['yport']))."', '".mysql_real_escape_string(strip_tags($_POST['namelookups']))."', '".mysql_real_escape_string(strip_tags($_POST['autodumpusers']))."', '".mysql_real_escape_string(strip_tags($_POST['autodumpsourcetime']))."', '".replacing_loca_value("contentdir", "".$internal_setting['system_dir']."clients/_id_/_port_/contentdir/")."', '".replacing_loca_value("introfile", "".$internal_setting['system_dir']."clients/_id_/_port_/soundfiles/intro.mp3")."', '".replacing_loca_value("backupfile", "".$internal_setting['system_dir']."clients/_id_/_port_/soundfiles/backup.mp3")."', '".mysql_real_escape_string(strip_tags($_POST['titleformat']))."', '".mysql_real_escape_string(strip_tags($_POST['publicserver']))."', '".mysql_real_escape_string(strip_tags($_POST['relayserver']))."', '".mysql_real_escape_string(strip_tags($_POST['relayport']))."', '".mysql_real_escape_string(strip_tags($_POST['allowpublicrelay']))."', '".mysql_real_escape_string(strip_tags($_POST['metainterval']))."', 'localhost', '".$internal_new_server_port."')") or die(mysql_error())) {
			$internal_new_server_folder = umask(0);
			if (!file_exists("".$internal_setting["system_dir"]."clients/".$internal_new_server_replace_id."/")) @mkdir("".$internal_setting["system_dir"]."clients/".$internal_new_server_replace_id."/", 0777);
			@mkdir("".$internal_setting["system_dir"]."clients/".$internal_new_server_replace_id."/".$internal_new_server_port, 0777);
			@mkdir("".$internal_setting["system_dir"]."clients/".$internal_new_server_replace_id."/".$internal_new_server_port."/logs", 0777);
			@mkdir("".$internal_setting["system_dir"]."clients/".$internal_new_server_replace_id."/".$internal_new_server_port."/soundfiles", 0777);
			@mkdir("".$internal_setting["system_dir"]."clients/".$internal_new_server_replace_id."/".$internal_new_server_port."/contentdir", 0777);
			@mkdir("".$internal_setting["system_dir"]."clients/".$internal_new_server_replace_id."/".$internal_new_server_port."/uploads", 0777);
			sleep(1);
			@mkdir("".$internal_setting["system_dir"]."clients/".$internal_new_server_replace_id."/".$internal_new_server_port."/uploads/audio", 0777);
			@mkdir("".$internal_setting["system_dir"]."clients/".$internal_new_server_replace_id."/".$internal_new_server_port."/uploads/video", 0777);
			@mkdir("".$internal_setting["system_dir"]."clients/".$internal_new_server_replace_id."/".$internal_new_server_port."/configs", 0777);
			@mkdir("".$internal_setting["system_dir"]."clients/".$internal_new_server_replace_id."/".$internal_new_server_port."/configs/playlists", 0777);
			umask($internal_new_server_folder);
			$usermessage_gre[] = "<h2>".$language_message[211]."</h2>";
		} else {
			$usermessage_red[] = "<h2>".$language_message[212]."</h2>";
		}
	}
	else {
		$usermessage_red[] = "<h2>".$language_message[213]."</h2>";
	}
}
if (isset($_GET['system_action']) && $_GET['system_action']=="delete") {
	$internal_delete_server_query_port = mysql_query("SELECT portbase FROM internal_system_db_servers WHERE id='".mysql_real_escape_string(trim($_GET['edit']))."'");
	$internal_delete_server_query_owner = mysql_query("SELECT owner FROM internal_system_db_servers WHERE id='".mysql_real_escape_string(trim($_GET['edit']))."'");
	$internal_delete_server_query_id = mysql_query("SELECT id FROM internal_system_db_users WHERE username='".mysql_real_escape_string(mysql_result($internal_delete_server_query_owner,0))."'");
	$internal_delete_server_query_pid = mysql_query("SELECT pid FROM internal_system_db_servers WHERE id='".mysql_real_escape_string(trim($_GET['edit']))."'");
	if (mysql_num_rows($internal_delete_server_query_owner)==0) $usermessage_red[] = "<h2>".$language_message[214]."</h2>";
	else {
		if (mysql_result($internal_delete_server_query_pid,0)!="") {
			internal_function_sctrans_stop(mysql_real_escape_string(trim($_GET['edit'])), mysql_result($internal_delete_server_query_owner,0));
			internal_function_shoutcast_stop(mysql_real_escape_string(trim($_GET['edit'])), mysql_result($internal_delete_server_query_owner,0));
		}
		//	Found on 'ozzu.com' from the post by 'placid psychosis' on July 5th, 2005 --START
		function delete_directory($dirname) {
			if (is_dir($dirname))
				$dir_handle = opendir($dirname);
			if (!$dir_handle)
				return false;
			while($file = readdir($dir_handle)) {
				if ($file != "." && $file != "..") {
					if (!is_dir($dirname."/".$file))
						@unlink($dirname."/".$file);
					else
						delete_directory($dirname.'/'.$file); 
				}
			}
			@closedir($dir_handle);
			@rmdir($dirname);
		}
		//	--END
		delete_directory("".$internal_setting["system_dir"]."clients/".mysql_result($internal_delete_server_query_id,0)."/".mysql_result($internal_delete_server_query_port,0)."/uploads/audio");
		delete_directory("".$internal_setting["system_dir"]."clients/".mysql_result($internal_delete_server_query_id,0)."/".mysql_result($internal_delete_server_query_port,0)."/uploads/video");
		delete_directory("".$internal_setting["system_dir"]."clients/".mysql_result($internal_delete_server_query_id,0)."/".mysql_result($internal_delete_server_query_port,0)."/configs/playlists");
		sleep(1);
		delete_directory("".$internal_setting["system_dir"]."clients/".mysql_result($internal_delete_server_query_id,0)."/".mysql_result($internal_delete_server_query_port,0)."/logs");
		delete_directory("".$internal_setting["system_dir"]."clients/".mysql_result($internal_delete_server_query_id,0)."/".mysql_result($internal_delete_server_query_port,0)."/soundfiles");
		delete_directory("".$internal_setting["system_dir"]."clients/".mysql_result($internal_delete_server_query_id,0)."/".mysql_result($internal_delete_server_query_port,0)."/contentdir");
		delete_directory("".$internal_setting["system_dir"]."clients/".mysql_result($internal_delete_server_query_id,0)."/".mysql_result($internal_delete_server_query_port,0)."/configs");
		delete_directory("".$internal_setting["system_dir"]."clients/".mysql_result($internal_delete_server_query_id,0)."/".mysql_result($internal_delete_server_query_port,0)."/uploads");
		sleep(1);
		delete_directory("".$internal_setting["system_dir"]."clients/".mysql_result($internal_delete_server_query_id,0)."/".mysql_result($internal_delete_server_query_port,0));
		if (mysql_query("DELETE FROM internal_system_db_servers WHERE id='".mysql_real_escape_string(trim($_GET['edit']))."'"))
			$usermessage_gre[] = "<h2>".$language_message[215]."</h2>";
		else
			$usermessage_red[] = "<h2>".$language_message[216]."</h2>";	
	}
}
if ($_GET['system_action'] == "update") {
	$internal_data_update = mysql_query("SELECT * FROM internal_system_db_servers WHERE id='".mysql_real_escape_string(trim($_GET['edit']))."'");
	if (mysql_num_rows($internal_data_update)==0)
		$usermessage_red[] = "<h2>".$language_message[217]."</h2>";
	else {
		if (isset($_POST['metainterval'])) {
			$internal_new_server_portexist = mysql_query("SELECT portbase FROM internal_system_db_servers WHERE id='".mysql_real_escape_string(trim($_GET['edit']))."'");
			if (is_numeric(mysql_result($internal_new_server_portexist,0))) {
				if (mysql_query("UPDATE internal_system_db_servers SET adminpassword='".mysql_real_escape_string(strip_tags($_POST['adminpassword']))."', password='".mysql_real_escape_string(strip_tags($_POST['password']))."', maxuser='".mysql_real_escape_string(strip_tags($_POST['maxuser']))."', bitrate='".mysql_real_escape_string(strip_tags($_POST['bitrate']))."', autopid='".mysql_real_escape_string(strip_tags(trim($_POST['autopid'])))."', webspace='".mysql_real_escape_string(strip_tags($_POST['webspace']*1024))."', logfile='".mysql_real_escape_string(strip_tags($_POST['logfile']))."', realtime='".mysql_real_escape_string(strip_tags($_POST['realtime']))."', tchlog='".mysql_real_escape_string(strip_tags($_POST['tchlog']))."', weblog='".mysql_real_escape_string(strip_tags($_POST['weblog']))."', screenlog='".mysql_real_escape_string(strip_tags($_POST['screenlog']))."', w3cenable='".mysql_real_escape_string(strip_tags($_POST['w3cenable']))."', w3clog='".mysql_real_escape_string(strip_tags($_POST['w3clog']))."', showlastsongs='".mysql_real_escape_string(strip_tags($_POST['showlastsongs']))."', srcip='".mysql_real_escape_string(strip_tags($_POST['srcip']))."', destip='".mysql_real_escape_string(strip_tags($_POST['destip']))."', yport='".mysql_real_escape_string(strip_tags($_POST['yport']))."', namelookups='".mysql_real_escape_string(strip_tags($_POST['namelookups']))."', autodumpusers='".mysql_real_escape_string(strip_tags($_POST['autodumpusers']))."', autodumpsourcetime='".mysql_real_escape_string(strip_tags($_POST['autodumpsourcetime']))."', contentdir='".mysql_real_escape_string(strip_tags($_POST['contentdir']))."', introfile='".mysql_real_escape_string(strip_tags($_POST['introfile']))."', backupfile='".mysql_real_escape_string(strip_tags($_POST['backupfile']))."', titleformat='".mysql_real_escape_string(strip_tags($_POST['titleformat']))."', publicserver='".mysql_real_escape_string(strip_tags($_POST['publicserver']))."', relayserver='".mysql_real_escape_string(strip_tags($_POST['relayserver']))."', relayport='".mysql_real_escape_string(strip_tags($_POST['relayport']))."', allowpublicrelay='".mysql_real_escape_string(strip_tags($_POST['allowpublicrelay']))."', metainterval='".mysql_real_escape_string(strip_tags($_POST['metainterval']))."' WHERE id='".mysql_real_escape_string(trim($_GET['edit']))."'"))
					$usermessage_gre[] = "<h2>".$language_message[218]."</h2>";
				else
					$usermessage_red[] = "<h2>".$language_message[219]."</h2>";
			}
			else
				$usermessage_red[] = "<h2>".$language_message[220]."</h2>";
			$internal_data_update = mysql_query("SELECT * FROM internal_system_db_servers WHERE id='".mysql_real_escape_string(trim($_GET['edit']))."'");
		}
	}
}
if (isset($_GET['system_action']) && $_GET['system_action']=="restart") {
	$internal_data_update = mysql_query("SELECT owner FROM internal_system_db_servers WHERE id='".mysql_real_escape_string(trim($_GET['edit']))."'");
	if (mysql_num_rows($internal_data_update)==0)
		$usermessage_red[] = "<h2>".$language_message[221]."</h2>";
	else {
		internal_function_shoutcast_stop(mysql_real_escape_string(trim($_GET['edit'])), mysql_result($internal_data_update,0));
		if (substr(internal_function_shoutcast_start(mysql_real_escape_string(trim($_GET['edit'])), mysql_result($internal_data_update,0)), 0, 7)=="yfssx001") {
			$usermessage_gre[] = "<h2>".$language_message[222]."</h2>";
		}
		else {
			$usermessage_gre[] = "<h2>".$language_message[222]."</h2>";
		}
	}
}
?>