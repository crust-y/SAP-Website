<?PHP
//	Streamers Admin Panel 3.2
//
//	Developer:
//	Main Coding: djcrackhome [Sebastian Graebner]
//	Thanks 2 Raimund Barendt, resh [Mathias Simon], hansy [Rico Reinheckel], Largo [Michael Savino] 
//
//	License:
//	Creative Commons Attribution-ShareAlike 3.0 Unported License
//		This work is licensed under the Creative Commons Attribution-ShareAlike 3.0 Unported License.
//		To view a copy of this license, visit http://creativecommons.org/licenses/by-sa/3.0/ or
//		send a letter to Creative Commons, 171 Second Street, Suite 300, San Francisco, California, 94105, USA.
//
//	URL:		http://www.streamerspanel.com
//	SUPPORT:	http://support.streamerspanel.com
//	MAIL:		info@streamerspanel.com
///////////////////////////////////////////////
//
//	FILENAME: ./include/server_top.php
//

error_reporting(0);
if ((!defined("_include_security")) || (!preg_match("/content.php/i", $_SERVER['PHP_SELF']))) {
    header('Location: ./../index.php?system_login='.md5(md5("access").date("H:i").$_SERVER['REMOTE_ADDR']));
	die();
}
$internal_setting_query = mysql_query("SELECT * FROM internal_system_db_mainsetting WHERE id='0'") or die($language_message["g5"]);
foreach(mysql_fetch_array($internal_setting_query) as $internal_setting_query_key => $internal_setting_query_preference) {
	if (!is_numeric($internal_setting_query_key)) {
		$internal_setting[$internal_setting_query_key] = stripslashes($internal_setting_query_preference);
	}
}
if (isset($_GET['edit']) && preg_match("/^[0-9]{1,11}+$/", $_GET['edit'])) {
	$internal_servers_query = mysql_query("SELECT * FROM internal_system_db_servers WHERE id='".mysql_real_escape_string(trim($_GET['edit']))."'");
	$internal_servers_result = mysql_fetch_array($internal_servers_query);
	if (mysql_num_rows($internal_servers_query)==0 || $internal_servers_result['owner']!=$internal_user_name && ($internal_servers_result['user_level']!="Super Administrator")) {
		$usermessage_red[] = "<h2>".$language_message["511"]."</h2>";
	}
	else {
		if (isset($_GET['system_action']) && $_GET['system_action']=="start") {
			if (substr(internal_function_shoutcast_start(mysql_real_escape_string(trim($_GET['edit'])), $internal_user_name), 0, 8)=="yfssx001") {
				$usermessage_gre[] = "<h2>Server wurde neugestartet</h2>";
			}
			else {
				$usermessage_red[] = "<h2>Server konnte nicht gestartet werden</h2>";
			}
		}
		if (isset($_GET['system_action']) && $_GET['system_action']=="stop") {
			internal_function_sctrans_stop(mysql_real_escape_string(trim($_GET['edit'])), $internal_user_name);
			if (substr(internal_function_shoutcast_stop(mysql_real_escape_string(trim($_GET['edit'])), $internal_user_name), 0, 8)=="yfstx001") {
				$usermessage_gre[] = "<h2>Server wurde beendet</h2>";
			}
			else {
				$usermessage_red[] = "<h2>Server konnte nicht gestartet werden</h2>";
			}
		}			
	}
}
if ($_GET['system_action'] == "update") {
	$internal_data_update = mysql_query("SELECT * FROM internal_system_db_servers WHERE id='".mysql_real_escape_string(trim($_GET['edit']))."'");
	if (mysql_num_rows($internal_data_update)==0)
		$usermessage_red[] = "<h2>".$language_message["186"]."</h2>";
	elseif (isset($_POST['metainterval'])) {
		if (mysql_query("UPDATE internal_system_db_servers SET adminpassword='".mysql_real_escape_string(strip_tags($_POST['adminpassword']))."', password='".mysql_real_escape_string(strip_tags($_POST['password']))."', logfile='".mysql_real_escape_string(strip_tags($_POST['logfile']))."', realtime='".mysql_real_escape_string(strip_tags($_POST['realtime']))."', tchlog='".mysql_real_escape_string(strip_tags($_POST['tchlog']))."', weblog='".mysql_real_escape_string(strip_tags($_POST['weblog']))."', screenlog='".mysql_real_escape_string(strip_tags($_POST['screenlog']))."', w3cenable='".mysql_real_escape_string(strip_tags($_POST['w3cenable']))."', w3clog='".mysql_real_escape_string(strip_tags($_POST['w3clog']))."', showlastsongs='".mysql_real_escape_string(strip_tags($_POST['showlastsongs']))."', srcip='".mysql_real_escape_string(strip_tags($_POST['srcip']))."', destip='".mysql_real_escape_string(strip_tags($_POST['destip']))."', yport='".mysql_real_escape_string(strip_tags($_POST['yport']))."', namelookups='".mysql_real_escape_string(strip_tags($_POST['namelookups']))."', autodumpusers='".mysql_real_escape_string(strip_tags($_POST['autodumpusers']))."', autodumpsourcetime='".mysql_real_escape_string(strip_tags($_POST['autodumpsourcetime']))."', contentdir='".mysql_real_escape_string(strip_tags($_POST['contentdir']))."', introfile='".mysql_real_escape_string(strip_tags($_POST['introfile']))."', backupfile='".mysql_real_escape_string(strip_tags($_POST['backupfile']))."', titleformat='".mysql_real_escape_string(strip_tags($_POST['titleformat']))."', publicserver='".mysql_real_escape_string(strip_tags($_POST['publicserver']))."', relayserver='".mysql_real_escape_string(strip_tags($_POST['relayserver']))."', relayport='".mysql_real_escape_string(strip_tags($_POST['relayport']))."', allowpublicrelay='".mysql_real_escape_string(strip_tags($_POST['allowpublicrelay']))."', metainterval='".mysql_real_escape_string(strip_tags($_POST['metainterval']))."' WHERE id='".mysql_real_escape_string(trim($_GET['edit']))."'"))
			$usermessage_gre[] = "<h2>".$language_message["173"]."</h2>";
		else
			$usermessage_red[] = "<h2>".$language_message["174"]."</h2>";
		$internal_data_update = mysql_query("SELECT * FROM internal_system_db_servers WHERE id='".mysql_real_escape_string(trim($_GET['edit']))."'");
	}
}
?>