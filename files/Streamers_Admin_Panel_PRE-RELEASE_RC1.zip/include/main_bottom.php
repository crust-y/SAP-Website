<?PHP
//	Streamers Admin Panel 3.2
//
//	Developer:
//	Main Coding: djcrackhome [Sebastian Graebner]
//	Thanks 2 Raimund Barendt, resh [Mathias Simon], hansy [Rico Reinheckel],
//	 Largo [Michael Savino], Marcel Weinberg, and all translators!
//
//	License:
//	Creative Commons Attribution-ShareAlike 3.0 Unported License
//		This work is licensed under the Creative Commons Attribution-ShareAlike 3.0 Unported License.
//		To view a copy of this license, visit http://creativecommons.org/licenses/by-sa/3.0/ or
//		send a letter to Creative Commons, 171 Second Street, Suite 300, San Francisco, California, 94105, USA.
//
//	URL:		http://www.streamerspanel.com
//	SUPPORT:	http://support.streamerspanel.com
//	MAIL:		info@streamerspanel.com
///////////////////////////////////////////////
//
//	FILENAME: ./include/main_bottom.php
//

ini_set('error_reporting', E_ALL | E_STRICT);
if ((!defined("_include_security")) || (!preg_match("/content.php/i", $_SERVER['PHP_SELF']))) {
    header('Location: ./../index.php?system_login='.md5(md5("access").date("H:i").$_SERVER['REMOTE_ADDR']));
	die();
}
?>
<div id="content">
	<div class="box">
		<h2><?php echo $language_message["358"];?></h2>
		<div class="main_top_menu">
			<div class="main_short">
				<div class="_shortcut_auto">
					<span><a href="content.php?include=autodj"><?php echo $language_message["359"];?></a></span>
				</div>
				<div class="_shortcut_user">
					<span><a href="content.php?include=account"><?php echo $language_message["360"];?></a></span>
				</div>
				<div class="_shortcut_cont">
					<span><a href="content.php?include=contact"><?php echo $language_message["361"];?></a></span>
				</div>
				<div class="_shortcut_main">
					<span><a href="content.php?include=server"><?php echo $language_message["362"];?></a></span>
				</div>
				<div class="_shortcut_mp3u">
					<span><a href="content.php?include=music"><?php echo $language_message["363"];?></a></span>
				</div>
				<div class="_shortcut_sett<?php if ($internal_user_level!="Super Administrator") { echo "_adm"; }?>">
					<span><?php if ($internal_user_level=="Super Administrator") { echo '<a href="content.php?include=admserver">'; }?><?php if ($internal_user_level!="Super Administrator") { echo "<p>("; }?><?php echo $language_message["364"];?><?php if ($internal_user_level!="Super Administrator") { echo ")</p>"; }?><?php if ($internal_user_level=="Super Administrator") { echo '</a>'; }?></span>
				</div>
				<div class="_shortcut_radi<?php if (($internal_user_level!="Super Administrator") && ($internal_user_level!="Reseller")) { echo "_adm"; }?>">
					<span><?php if (($internal_user_level=="Super Administrator") || ($internal_user_level=="Reseller")) { echo '<a href="content.php?include=admradio">'; }?><?php if (($internal_user_level!="Super Administrator") && ($internal_user_level!="Reseller")) { echo "<p>("; }?><?php echo $language_message["365"];?><?php if (($internal_user_level!="Super Administrator") && ($internal_user_level!="Reseller")) { echo ")</p>"; }?><?php if (($internal_user_level=="Super Administrator") || ($internal_user_level=="Reseller")) { echo '</a>'; }?></span>
				</div>
				<div class="_shortcut_cust<?php if (($internal_user_level!="Super Administrator") && ($internal_user_level!="Reseller")) { echo "_adm"; }?>">
					<span><?php if (($internal_user_level=="Super Administrator") || ($internal_user_level=="Reseller")) { echo '<a href="content.php?include=admuser">'; }?><?php if (($internal_user_level!="Super Administrator") && ($internal_user_level!="Reseller")) { echo "<p>("; }?><?php echo $language_message["366"];?><?php if (($internal_user_level!="Super Administrator") && ($internal_user_level!="Reseller")) { echo ")</p>"; }?><?php if (($internal_user_level=="Super Administrator") || ($internal_user_level=="Reseller")) { echo '</a>'; }?></span>
				</div>
			</div>
			<div class="main_right">
				<h2><?php echo $language_message["367"];?></h2>
				<p><?php echo $language_message["368"];?></p>
				<p><?php echo $language_message["369"];?></p>
			</div>
		</div>
		<?php
		if ($internal_user_level=="Super Administrator")	{
			echo "<h2>Benutzernachrichten Service Center</h2>
				<table cellspacing=\"0\" cellpadding=\"0\">
				<tbody>";
			$internal_main_notices_query = mysql_query("SELECT * FROM internal_system_db_notices");
			if (mysql_num_rows($internal_main_notices_query)==0) {
				echo "<tr class=\"alt\">
					<td colspan=\"3\">".$language_message["371"]."</td>
					</tr>";
			}
			else {
				while($internal_main_notices_query_data = mysql_fetch_array($internal_main_notices_query)) {
					echo "<tr>
						<td>".$internal_main_notices_query_data['username']."</td>
						<td>".$internal_main_notices_query_data['reason']."</td>
						<td><a class=\"delete\" href=\"?action=remove&delmessid=".$internal_main_notices_query_data['id']."\">".$language_message["372"]."</a><a href=\"./include/messages.php?id=".$internal_main_notices_query_data['id']."\" class=\"nyroModal selector\">".$language_message["373"]."</a></td>
						</tr>";
				}
			}
			echo "</tbody>
				</table>";
		}
		?>
		<?php
		
		if (($internal_setting['system_win']=="1") && ($internal_setting['system_premium']=="1")) {
			echo "<br /><h2>Streamers Admin Panel - Windows Tool</h2>
				<div class=\"contact_top_menu\">
					<div class=\"tool_top_menu\">
						<div class=\"main_shorttool\">Das Streamers Admin Panel bietet VIP Usern dieser Software die M&ouml;glichkeit, wichtige Funktionen dieser Software von Ihrem Windows PC aus steuern zu k&ouml;nnen ohne direkt mit dieser Software &uuml;ber den Browser verbunden zu sein. Dieses Tool hat die Funktionen direkt Radio- und deren AutoDJ Server starten, stoppen, und direkt auch kicken zu k&ouml;nnen.</div>
							<div class=\"main_righttool\">
								<h2>Windows Tool</h2>
									<p>Das Tool wurde von der Firma 'RR-Tools' zur Verf&uuml;gung gestellt, und wird mit einem Teil der Spende entgeltet.</p>
								</div>
							</div>
						</div>
				<table cellspacing=\"0\" cellpadding=\"0\">
				<tbody><tr class=\"alt\">
				<td colspan=\"3\"><a href=\"index.php?download=latest_win_tool\">Bitte klicken Sie hier, um den Download f&uuml;r das Windows Tool von 'RR-Tools' zu initialisieren.</a></td>
				</tr></tbody>
				</table>";
		}
		?>
		<?php
		if ((phpversion() >= "5.1.0") && ($internal_setting['system_news']=="1")) {
			$internal_xml_news_request = simplexml_load_file("http://streamers.admin.panel.s3.amazonaws.com/news/index.xml");
			if ($internal_xml_news_request->channel->item!=NULL) {
				function internal_xml_shorter($internal_xml_shorter_input, $internal_xml_shorter_max) {
					if (strlen($internal_xml_shorter_input) <= $internal_xml_shorter_max) {
						$internal_xml_shorter_output = $internal_xml_shorter_input;
					}
					else {
						$internal_xml_shorter_max_short = substr($internal_xml_shorter_input, 0, $internal_xml_shorter_max);
						$internal_xml_shorter_max_null = strrpos($internal_xml_shorter_max_short, ' ');    
						$internal_xml_shorter_output = substr($internal_xml_shorter_input, 0, $internal_xml_shorter_max_null).'...';
					}
					return $internal_xml_shorter_output;
				}
				$playlist_xml_left_dirlistingsearch  = array('&', '<', '>', '"', "'");
				$playlist_xml_left_dirlistingreplace = array('&amp;', '&lt;', '&gt;', '&quot;', '&apos;');
				echo "<br /><h2>News & Updates - Streamers Admin Panel</h2>
					<div class=\"contact_top_menu\">
						<div class=\"tool_top_menu\">
							<div class=\"main_shorttool\">Dieser Newsfeed ist daf&uuml;r da, die neusten Entwicklungsst&auml;nde und Informationen rund um das Open-Source Programm &quot;Streamers Admin Panel&quot; zu ver&ouml;ffentlichen. Wir pr&auml;sentieren immer die aktuellesten Vorg&auml;nge und Ver&ouml;ffentlichungen dieses Programms in diesem Newsfeed. Auch Updates und Erneuerungen, sowie wichtige Nachrichten wird durch diesen Feed direkt an alle Panelbenutzer geschickt.</div>
								<div class=\"main_righttool\">
									<h2>News &amp; Updates</h2>
									<p>Hier findest du die neusten News zu diesem Panel. Alle News werden automatisch von unserem Server abgerufen.</p>
								</div>
							</div>
						</div>
						<table cellspacing=\"0\" cellpadding=\"0\">
						<tbody>";
			}
			else {
				echo "<br /><h2>News & Updates - Error</h2>
					<div class=\"contact_top_menu\">
						<div class=\"tool_top_menu\">
							<div class=\"main_shorttool\">Es ist eine Fehler beim Abruf der News aufgetreten. Bitte warten Sie auf ein Update oder pr&uuml;fen Sie Ihre Firewall bzw. Internetverbindung.</div>
								<div class=\"main_righttool\">
									<h2>News & Updates</h2>
									<p>Hier findest du die neusten News zu diesem Panel. Alle News werden automatisch von unserem Server abgerufen.</p>
								</div>
							</div>
						</div>
						<table cellspacing=\"0\" cellpadding=\"0\">
						<tbody>";
			}
			foreach ($internal_xml_news_request->channel->item as $internal_xml_news_request_item) {
				echo "<tr>
					<td>".internal_xml_shorter($internal_xml_news_request_item->title, 35)."</td>
					<td>".internal_xml_shorter($internal_xml_news_request_item->description, 60)."</td>
					<td><a href=\"#a".md5($internal_xml_news_request_item->pubDate)."\" class=\"nyroModal selector\">&Ouml;ffnen</a></td>
					</tr>";
			}
			if ($internal_xml_news_request->channel->item==NULL) {
				echo "<tr class=\"alt\">
					<td colspan=\"3\">Aktuell liegen keine neuen Nachrichten vor, oder es konnte keine Verbindung mit dem Server hergestellt werden.</td>
					</tr>";
			}
		}
		echo "</tbody>
			</table>";
		foreach ($internal_xml_news_request->channel->item as $internal_xml_news_request_item) {
			echo "
				<div id=\"a".md5($internal_xml_news_request_item->pubDate)."\" class=\"rss_implement_layer\" >
					<h3>".internal_xml_shorter($internal_xml_news_request_item->title, 45)."</h3>
					<hr size=\"1\" />
					<h4>News veröffentlicht am ".$internal_xml_news_request_item->pubDate."<br />News Kategorie: ".$internal_xml_news_request_item->category."</h4><br />
					<p>".$internal_xml_news_request_item->guid."</p>
					<p>Link zu diesem Newseintrag: <a href=\"".$internal_xml_news_request_item->link."\"><u>".internal_xml_shorter($internal_xml_news_request_item->title, 45)."</u></a></p>
				</div>";
		}
		?>
	</div>
</div>