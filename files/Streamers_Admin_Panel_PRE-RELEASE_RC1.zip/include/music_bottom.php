<?PHP
//	Streamers Admin Panel 3.2
//
//	Developer:
//	Main Coding: djcrackhome [Sebastian Graebner]
//	Thanks 2 Raimund Barendt, resh [Mathias Simon], hansy [Rico Reinheckel], Largo [Michael Savino] 
//
//	License:
//	Creative Commons Attribution-ShareAlike 3.0 Unported License
//		This work is licensed under the Creative Commons Attribution-ShareAlike 3.0 Unported License.
//		To view a copy of this license, visit http://creativecommons.org/licenses/by-sa/3.0/ or
//		send a letter to Creative Commons, 171 Second Street, Suite 300, San Francisco, California, 94105, USA.
//
//	URL:		http://www.streamerspanel.com
//	SUPPORT:	http://support.streamerspanel.com
//	MAIL:		info@streamerspanel.com
///////////////////////////////////////////////
//
//	FILENAME: ./include/music_bottom.php
//

error_reporting(0);
if ((!defined("_include_security")) || (!preg_match("/content.php/i", $_SERVER['PHP_SELF']))) {
    header('Location: ./../index.php?system_login='.md5(md5("access").date("H:i").$_SERVER['REMOTE_ADDR']));
	die();
}
$internal_listing_limit = mysql_real_escape_string(trim($internal_setting['system_limit']));
if (!isset($_GET['listing_query'])) $listing_query = 0;
else $listing_query = mysql_real_escape_string($_GET['listing_query'] * $internal_listing_limit);
$listing_query_limitery = $listing_query + $internal_listing_limit;
$listing_sql_query = mysql_query("SELECT * FROM internal_system_db_servers WHERE owner='".mysql_real_escape_string($internal_user_name)."' ORDER BY id ASC LIMIT $listing_query,$internal_listing_limit");
?>
<div id="content">
		<div class="box">
		<h2><?php echo $language_message["374"];?></h2>
		<div class="contact_top_menu">
			<div class="tool_top_menu">
				<div class="main_shorttool"><?php echo $language_message["375"];?></div>
				<div class="main_righttool">
					<h2><?php echo $language_message["376"];?></h2>
					<p><?php echo $language_message["377"];?></p>
					<p>&nbsp;</p>
				</div>
			</div>
			<table cellspacing="0" cellpadding="0">
				<thead>
					<tr>
						<th><?php echo $language_message["378"];?></th>
						<th><?php echo $language_message["379"];?></th>
						<th><?php echo $language_message["380"];?></th>
						<th>&nbsp;</th>
					</tr>
				</thead>
				<tbody>
				<?php
				if (mysql_num_rows($listing_sql_query)==0) {
					echo "<tr>
						<td colspan=\"5\">".$language_message["382"]."</td>
						</tr>";
				}
				else {
					while($internal_listing_data = mysql_fetch_array($listing_sql_query)) {
						if ($internal_listing_data['autopid'] != "9999999") {
							echo '<tr>
							<td><a href="http://'.$internal_setting['system_host'].':'.$internal_listing_data['portbase'].'/" target="_blank">'.$internal_setting['system_host'].'</a></td>
							<td><a href="http://'.$internal_setting['system_host'].':'.$internal_listing_data['portbase'].'/" target="_blank">'.$internal_listing_data['portbase'].'</a></td>
							<td><div class="space_show" style="background-position:';
							$internal_listing_ownerid = mysql_query("SELECT id FROM internal_system_db_users WHERE username='".mysql_real_escape_string($internal_listing_data['owner'])."'");
							$negative_background_pos = ((internal_folder_space($internal_setting['system_dir']."/clients/".$internal_user_id."/".$internal_listing_data['portbase']."/uploads/audio/")+internal_folder_space($internal_setting['system_dir']."/clients/".$internal_user_id."/".$internal_listing_data['portbase']."/uploads/video/"))/$internal_listing_data['webspace'])*120;
							echo '-'.$negative_background_pos.'px 0px;"></div></td>
								<td><a class="edit" href="content.php?include=playlist&portbase='.htmlspecialchars(trim($internal_listing_data['portbase'])).'">'.$language_message["383"].'</a><a class="selector" href="content.php?include=upload&portbase='.htmlspecialchars(trim($internal_listing_data['portbase'])).'">'.$language_message["384"].'</a></td>
								</tr>';
						}
					}
				}
				?>
				</tbody>
			</table>
		</div>
	</div> 
</div>