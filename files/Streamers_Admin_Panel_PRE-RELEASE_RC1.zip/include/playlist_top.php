<?PHP
//	Streamers Admin Panel 3.2
//
//	Developer:
//	Main Coding: djcrackhome [Sebastian Graebner]
//	Thanks 2 Raimund Barendt, resh [Mathias Simon], hansy [Rico Reinheckel],
//	 Largo [Michael Savino], Marcel Weinberg, and all translators!
//
//	License:
//	Creative Commons Attribution-ShareAlike 3.0 Unported License
//		This work is licensed under the Creative Commons Attribution-ShareAlike 3.0 Unported License.
//		To view a copy of this license, visit http://creativecommons.org/licenses/by-sa/3.0/ or
//		send a letter to Creative Commons, 171 Second Street, Suite 300, San Francisco, California, 94105, USA.
//
//	URL:		http://www.streamerspanel.com
//	SUPPORT:	http://support.streamerspanel.com
//	MAIL:		info@streamerspanel.com
///////////////////////////////////////////////
//
//	FILENAME: ./include/main_bottom.php
//

error_reporting(0);
if ((!defined("_include_security")) || (!preg_match("/content.php/i", $_SERVER['PHP_SELF']))) {
    header('Location: ./../index.php?system_login='.md5(md5("access").date("H:i").$_SERVER['REMOTE_ADDR']));
	die();
}
$internal_setting_query = mysql_query("SELECT * FROM internal_system_db_mainsetting WHERE id='0'") or die($language_message["g5"]);
foreach(mysql_fetch_array($internal_setting_query) as $internal_setting_query_key => $internal_setting_query_preference) {
	if (!is_numeric($internal_setting_query_key)) {
		$internal_setting[$internal_setting_query_key] = stripslashes($internal_setting_query_preference);
	}
}
if (!isset($_GET['portbase'])) {
	header('Location: content.php?include=music&error=port');
	die ();
}
else {
	$internal_server_port=$_GET['portbase'];
}
$internal_server_owner = mysql_query("SELECT * FROM internal_system_db_servers WHERE portbase='".mysql_real_escape_string(strip_tags(trim($internal_server_port)))."' AND owner='".mysql_real_escape_string(strip_tags($internal_user_name))."'");
if (mysql_num_rows($internal_server_owner)!=1) {
	header('Location: content.php?include=music&error=access');
	die ();
}
$internal_server_autopid_check_query = mysql_query("SELECT autopid FROM internal_system_db_servers WHERE portbase='".mysql_real_escape_string(strip_tags(trim($internal_server_port)))."' AND owner='".mysql_real_escape_string(strip_tags($internal_user_name))."'");
if (mysql_result($autopid_check_sql,0) == "9999999") {
	header('Location: content.php?include=music&error=access');
	die ();
}
if (($_GET['indiv'] == "0") && (isset($_GET['listname'])) && ($_GET['delete'] == "1")) {
	$internal_file_rem_decode = strip_tags(preg_replace("#/#","", base64_decode($_GET['listname'])));
	if (file_exists($internal_setting["system_dir"]."clients/".$internal_user_id."/".trim($internal_server_port)."/configs/playlists/".$internal_file_rem_decode)) {
		unlink($internal_setting["system_dir"]."clients/".$internal_user_id."/".trim($internal_server_port)."/configs/playlists/".$internal_file_rem_decode);
		$usermessage_gre[] = "<h2>".$language_message["407"]."</h2>";
	}
	else {
		$usermessage_red[] = "<h2>".$language_message["408"]."</h2>";
	}
}
if ($_GET['delete'] != "1") {
	if ((isset($_POST['arv'])) && (isset($_GET['listname']))) {
		if ($_GET['new'] == "1") {
			if ($_POST['playlistformname'] !== "bmV3IHBsYXlsaXN0LmxzdA==") {
				$playlistfilecreatename = strip_tags(preg_replace("#/#","", $_POST['playlistformname']));
				if (!file_exists($internal_setting["system_dir"]."clients/".$internal_user_id."/".trim($internal_server_port)."/configs/playlists/".$playlistfilecreatename.".lst")) {
					$playlistfilecreate = fopen($internal_setting["system_dir"]."clients/".$internal_user_id."/".trim($internal_server_port)."/configs/playlists/".$playlistfilecreatename.".lst", 'w') or $errors[] = "<h2>".$language_message["411"]."</h2>";
					fclose($playlistfilecreate);
					if (file_exists($internal_setting["system_dir"]."clients/".$internal_user_id."/".trim($internal_server_port)."/configs/playlists/")) {
						if (file_exists($internal_setting["system_dir"]."clients/".$internal_user_id."/".trim($internal_server_port)."/configs/playlists/".$playlistfilecreatename.".lst")) {
							if ($_POST['data_style']!="0") {
								$postvar_form = $_POST['arv'];
								$postvar_form = urldecode($postvar_form);
								$postvar_name = $internal_setting["system_dir"]."clients/".$internal_user_id."/".trim($internal_server_port)."/configs/playlists/".$playlistfilecreatename.".lst";
								$filehandle = fopen($postvar_name, "w+");
								$tok = explode(',',$postvar_form);
								foreach ($tok as $playlistentry) {
									$playlistentry=str_replace("undefined", "", $playlistentry);
									if (isset($_POST['playlistform_foldername'])) {
										if (is_file($internal_setting["system_dir"]."clients/".$internal_user_id."/".trim($internal_server_port)."/uploads/audio/".$_POST['playlistform_foldername']."/".$playlistentry) && ($_POST['playlistform_foldername']!="/")) {
											fwrite($filehandle, $internal_setting["system_dir"]."clients/".$internal_user_id."/".trim($internal_server_port)."/uploads/audio/".$_POST['playlistform_foldername']."/".$playlistentry."\n");
										}
										else {
											fwrite($filehandle, $internal_setting["system_dir"]."clients/".$internal_user_id."/".trim($internal_server_port)."/uploads/audio/".$playlistentry."\n");
										}
									}
								}
								fclose($filehandle);
								chmod($postvar_name,0777);
							}
							else {
								if ((isset($_GET['playlist_folder'])) && ($_POST['playlistform_foldername']!="/")) {
									shell_exec("find ".$internal_setting["system_dir"]."clients/".$internal_user_id."/".trim($internal_server_port)."/uploads/audio/".$_POST['playlistform_foldername']."/ -type f -name '*.mp3' -maxdepth 1 > ".$internal_setting["system_dir"]."clients/".$internal_user_id."/".trim($internal_server_port)."/configs/playlists/".$playlistfilecreatename.".lst");
								}
								else {
									shell_exec("find ".$internal_setting["system_dir"]."clients/".$internal_user_id."/".trim($internal_server_port)."/uploads/audio/ -type f -name '*.mp3' -maxdepth 1 > ".$internal_setting["system_dir"]."clients/".$internal_user_id."/".trim($internal_server_port)."/configs/playlists/".$playlistfilecreatename.".lst");
								}	
							}
							$usermessage_gre[] = "<h2>".$language_message["412"]."</h2>";
						}
						else {
							$usermessage_red[] = "<h2>".$language_message["413"]."</h2>";
						}
					}
					else {
						$usermessage_red[] = "<h2>".$language_message["414"]."</h2>";
					}				
				}
				else {
					$usermessage_red[] = "<h2>".$language_message["415"]."</h2>";
				}
			}
			else {
				$usermessage_red[] = "<h2>".$language_message["416"]."</h2>";
			}
		}
		else {
			if (file_exists($internal_setting["system_dir"]."clients/".$internal_user_id."/".trim($internal_server_port)."/configs/playlists/")) {
				if (file_exists($internal_setting["system_dir"]."clients/".$internal_user_id."/".trim($internal_server_port)."/configs/playlists/".base64_decode($_GET['listname']))) {
					if ($_POST['data_style']!="0") {
						$postvar_form = $_POST['arv'];
						$postvar_form = urldecode($postvar_form);
						$postvar_name = $internal_setting["system_dir"]."clients/".$internal_user_id."/".trim($internal_server_port)."/configs/playlists/".base64_decode($_GET['listname']);
						$filehandle = fopen($postvar_name, "w+");
						$tok = explode(',',$postvar_form);
						foreach ($tok as $playlistentry) {
							$playlistentry=str_replace("undefined", "", $playlistentry);
							if (isset($_POST['playlistform_foldername'])) {
								if (is_file($internal_setting["system_dir"]."clients/".$internal_user_id."/".trim($internal_server_port)."/uploads/audio/".$_POST['playlistform_foldername']."/".$playlistentry) && ($_POST['playlistform_foldername']!="/")) {
									fwrite($filehandle, $internal_setting["system_dir"]."clients/".$internal_user_id."/".trim($internal_server_port)."/uploads/audio/".$_POST['playlistform_foldername']."/".$playlistentry."\n");
								}
								else {
									fwrite($filehandle, $internal_setting["system_dir"]."clients/".$internal_user_id."/".trim($internal_server_port)."/uploads/audio/".$playlistentry."\n");
								}
							}
						}
						fclose($filehandle);
						chmod($postvar_name,0777);
					}
					else {
						if ((isset($_GET['playlist_folder'])) && ($_POST['playlistform_foldername']!="/")) {
							shell_exec("find ".$internal_setting["system_dir"]."clients/".$internal_user_id."/".trim($internal_server_port)."/uploads/audio/".$_POST['playlistform_foldername']."/ -type f -name '*.mp3' -maxdepth 1 > ".$internal_setting["system_dir"]."clients/".$internal_user_id."/".trim($internal_server_port)."/configs/playlists/".base64_decode($_GET['listname']));
						}
						else {
							shell_exec("find ".$internal_setting["system_dir"]."clients/".$internal_user_id."/".trim($internal_server_port)."/uploads/audio/ -type f -name '*.mp3' -maxdepth 1 > ".$internal_setting["system_dir"]."clients/".$internal_user_id."/".trim($internal_server_port)."/configs/playlists/".base64_decode($_GET['listname']));
						}	
					}
					$usermessage_gre[] = "<h2>".$language_message["417"]."</h2>";
				}
				else {
					$usermessage_red[] = "<h2>".$language_message["418"]."</h2>";
				}
			}
			else {
				$usermessage_red[] = "<h2>".$language_message["419"]."</h2>";
			}
		}
	}
}
else {
	define('entries_per_page',100);
	if (!isset($_GET['filecount']) or !is_numeric($_GET['filecount'])) $offset = 1;
	else $offset = $_GET['filecount'];
	if ($offset == 1) {
		$listing_start = $offset * entries_per_page - entries_per_page;
	}
	else {
		$listing_start = $offset * entries_per_page - entries_per_page + 3;
	}					
	$listing_end = $offset * entries_per_page + 2;
	$dirlisting = @scandir("".$internal_setting["system_dir"]."clients/".$internal_user_id."/".trim($internal_server_port)."/configs/playlists/") or $usermessage_red[] = "<h2>".$language_message["420"]."</h2>";
	if (!isset($dirlisting[$listing_start]))
		$usermessage_red[] = "<h2>".$language_message["421"]."</h2>";
}
?>