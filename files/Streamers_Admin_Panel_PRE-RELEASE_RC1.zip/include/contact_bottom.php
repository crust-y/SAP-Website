<?PHP
//	Streamers Admin Panel 3.2
//
//	Developer:
//	Main Coding: djcrackhome [Sebastian Graebner]
//	Thanks 2 Raimund Barendt, resh [Mathias Simon], hansy [Rico Reinheckel], Largo [Michael Savino] 
//
//	License:
//	Creative Commons Attribution-ShareAlike 3.0 Unported License
//		This work is licensed under the Creative Commons Attribution-ShareAlike 3.0 Unported License.
//		To view a copy of this license, visit http://creativecommons.org/licenses/by-sa/3.0/ or
//		send a letter to Creative Commons, 171 Second Street, Suite 300, San Francisco, California, 94105, USA.
//
//	URL:		http://www.streamerspanel.com
//	SUPPORT:	http://support.streamerspanel.com
//	MAIL:		info@streamerspanel.com
///////////////////////////////////////////////
//
//	FILENAME: ./include/contact_bottom.php
//

if ((!defined("_include_security")) || (!preg_match("/content.php/i", $_SERVER['PHP_SELF']))) {
    header('Location: ./../index.php?system_login='.md5(md5("access").date("H:i").$_SERVER['REMOTE_ADDR']));
	die();
}
?>
<div id="content">
	<div class="box">
		<h2><?php echo $language_message["338"];?></h2>
		<div class="contact_top_menu">
			<div class="tool_top_menu">
				<div class="main_shorttool"><?php echo $language_message["339"];?></div>
				<div class="main_righttool">
					<h2><?php echo $language_message["340"];?></h2>
					<p><?php echo $language_message["341"];?></p>
					<p>&nbsp;</p>
				</div>
			</div>
			<form method="post" action="content.php?include=contact" id="contactform">
				<fieldset>
					<legend><?php echo $language_message["342"];?></legend>
					<div class="input_field">
						<label for="a"><?php echo $language_message["343"];?></label>
						<input class="mediumfield" name="internal_contact_loginname" type="text" value="<?php echo htmlspecialchars($internal_user_name);?>" disabled="disabled" />
						<span class="field_desc"><?php echo $language_message["344"];?></span>
					</div>
					<div class="input_field">
						<label for="b"><?php echo $language_message["345"];?></label>
						<input type="text" name="internal_contact_email" class="mediumfield" value="<?php if (isset($internal_contact_formerror)) { echo htmlspecialchars($_POST['internal_contact_email']); }?>"/>
						<?php
						if ((isset($internal_contact_formerror)) && ($internal_contact_formerror == "email")) {
							echo "<span class=\"validate_error\">".$language_message["346"]."</span>";
						}
						elseif ((isset($internal_contact_formerror)) && (($internal_contact_formerror == "reason") || ($internal_contact_formerror == "message"))) {
							echo "<span class=\"validate_success\">".$messages["347"]."</span>";
						}
						?>
					</div>
					<div class="input_field">
						<label for="c"><?php echo $language_message["348"];?></label>
						<input type="text" name="internal_contact_reason" class="mediumfield" value="<?php if (isset($internal_contact_formerror)) { echo htmlspecialchars($_POST['internal_contact_reason']); }?>" />
						<?php
						if ((isset($internal_contact_formerror)) && ($internal_contact_formerror == "reason")) {
							echo "<span class=\"validate_error\">".$language_message["349"]."</span>";
						}
						elseif ((isset($internal_contact_formerror)) && ($internal_contact_formerror == "message")) {
							echo "<span class=\"validate_success\">".$messages["350"]."</span>";
						}
						?>
					</div>
					<div class="input_field">
						<textarea cols="90" name="internal_contact_message" rows="6" class="textbox" value=""><?php if (isset($internal_contact_formerror)) { echo htmlspecialchars($_POST['internal_contact_message']); }?></textarea>
						<?php
						if ((isset($internal_contact_formerror)) && ($internal_contact_formerror == "message")) {
							echo "<span class=\"validate_error\">".$language_message["351"]."</span>";
						}
						?>
					</div>
					<input class="submit" type="submit" name="internal_contact_submit" value="<?php echo $language_message["353"];?>" />
					<input class="submit" type="reset" value="<?php echo $language_message["354"];?>" />
				</fieldset>
			</form>
		</div>
	</div>
</div>