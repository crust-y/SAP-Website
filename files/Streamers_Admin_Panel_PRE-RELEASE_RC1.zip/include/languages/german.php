<?php
//	Streamers Admin Panel 3.2
//
//	Developer:
//	Main Coding: djcrackhome [Sebastian Graebner]
//	Thanks to all VIP Users for their support and all translators, and a special thanks to:
//	Raimund Barendt, resh [Mathias Simon], peaceman2305, hansy [Rico Reinheckel], Largo [Michael Savino] 
//
//	License:
//	Creative Commons Attribution-ShareAlike 3.0 Unported License
//		This work is licensed under the Creative Commons Attribution-ShareAlike 3.0 Unported License.
//		To view a copy of this license, visit http://creativecommons.org/licenses/by-sa/3.0/ or
//		send a letter to Creative Commons, 171 Second Street, Suite 300, San Francisco, California, 94105, USA.
//
//	URL:		http://www.streamerspanel.com
//	SUPPORT:	http://support.streamerspanel.com
//	MAIL:		info@streamerspanel.com
///////////////////////////////////////////////
//
//	FILENAME: ./include/languages/german.php
//

//	Translated by: Sebastian Graebner
//	GERMAN LANGUAGE FILES
//	language credit
$language_message[0]	=		"<a href=\"http://www.url.cdn\">Steffen...bla</a>";
//	
//	
//	./index.php
$language_message[1]		=		"Die Logindaten stimmen nicht mit unseren gespeicherten Daten &uuml;berein!";
$language_message[2]		=		"Der Captcha Code wurde nicht korrekt eingegeben!";
$language_message[3]		=		"Sie wurden erfolgreich von dem Panel ausgeloggt!";
$language_message[4]		=		"Sie sind nicht dazu berechtigt diese Datei extern aufzurufen!";
$language_message[5]		=		"Webpanel Login";
$language_message[6]		=		"Benutzeranmeldung";
$language_message[7]		=		"Bitte benutzen Sie das folgende Loginfeld um Ihre Identit&auml;t festzustellen. Nachdem Sie sich erfolgreich angemeldet haben, erhalten Sie Zugriff auf das Shoutcast Admin Panel. Ihre Daten werden sicher mit den Datenbankdaten verglichen. Es kann sein das der Administrator w&uuml;nscht dass Sie zur Sicherheit einen Captcha Code eingeben, wir bitten Sie daher den Code in das dazugeh&ouml;rige Feld einzutragen.";
$language_message[8]		=		"Bitte melden Sie sich hier folgend mit Ihren Login-Daten in das Shoutcast Admin Panel ein";
$language_message[9]		=		"Benutzername";
$language_message[10]		=		"Ihr pers&ouml;nlicher Benutzername";
$language_message[11]		=		"Passwort";
$language_message[12]		=		"Ihr pers&ouml;nliches Passwort";
$language_message[13]		=		"Captcha Eingabe";
$language_message[14]		=		"Anmelden";
$language_message[15]		=		"Zur&uuml;cksetzen";
//	
//	
//	./content.php
$language_message[16]		=		"Sie wurden erfolgreich mit Ihren pers&ouml;nlichen Daten in das Panel angemeldet";
$language_message[17]		=		"Das Installationsverzeichnis des Panels befindet sich noch im Webverzeichnis";
$language_message[18]		=		"Die Seite konnte nicht gefunden werden, bitte kontaktieren Sie den Admin";
$language_message[19]		=		"Sie k&ouml;nnen keine Administrationsseiten aufrufen, ohne Administrator-Rechte";
$language_message[20]		=		"Die Nachricht mit der ID wurde erfolgreich aus der Datenbank gel&ouml;scht";
$language_message[21]		=		"Die Nachricht mit der ID konnte nicht aus der Datenbank gel&ouml;scht werden";
$language_message[22]		=		"Bitte installieren Sie das Panel neu, System PHP Datei wurde nicht gefunden";
$language_message[23]		= 		"Die Verbindung zur MySQL Datenbank konnte nicht hergestellt werden";
$language_message[24]		=		"Sie sind angemeldet als";
$language_message[25]		=		"Abmelden";
$language_message[26]		=		"Herzlich Willkommen";
$language_message[27]		=		"Sie haben keine neue Nachrichten";
$language_message[28]		=		"Sie haben";
$language_message[29]		=		"neue Nachricht";
$language_message[30]		=		"Sie haben";
$language_message[31]		=		"neue Nachrichten";
$language_message[32]		=		"Benutzeransicht";
$language_message[33]		=		"Hauptmenu";
$language_message[34]		=		"server, seite und stream";
$language_message[35]		=		"Benutzernachrichten Service Center";
$language_message[36]		=		"Meine Benutzerkonto-Einstellungen";
$language_message[37]		=		"Meine Radio Streaming Server";
$language_message[38]		=		"AutoDJ";
$language_message[39]		=		"autodj, playlist und mp3s";
$language_message[40]		=		"Upload und Wiedergabelisten-Einstellungen";
$language_message[41]		=		"Audio AutoDJ-Server Steuerung";
$language_message[42]		=		"Administration";
$language_message[43]		=		"Reseller";
$language_message[44]		=		"server und zugriff";
$language_message[45]		=		"Panel Webserver Einstellungen";
$language_message[46]		=		"Radioserver Administration und Zugriff";
$language_message[47]		=		"Klienten Steuerung und Administration";
$language_message[48]		=		"Informationen";
$language_message[49]		=		"ip und versionsinfo";
$language_message[50]		=		"server und zugriff";
$language_message[51]		=		"Benutzer IP";
$language_message[52]		=		"Server IP";
$language_message[53]		=		"Panel Version";
$language_message[54]		=		"PHP Version";
$language_message[55]		=		"Bitte aktiviere JavaScript in den Browsereinstellungen";
//
//
//	./messages.php
$language_message[56]		=		"Keine Nachricht ausgew&auml;lt!";
$language_message[57]		=		"Eine Nachricht von";
$language_message[58]		=		"Betreff";
$language_message[59]		=		"Mitteilung";
//
//	
//	./include/account_bottom.php
$language_message[60]		=		"Meine Benutzerkonto-Einstellungen";
$language_message[61]		=		"Benutzen Sie diese Seite um Ihre Informationen zu Ihrem Benutzerkonto zu editieren, oder etwas nachzuschauen. Diese Informationen teilen Sie mit dem Administrator dieses Panels. Nur dieser kann Ihre Informationen aufrufen. Sie haben aber auch die M&ouml;glichkeit Ihr pers&ouml;nliches Passwort zu &auml;ndern. Sie k&ouml;nnen jederzeit Ihre Informationen nach Belieben &auml;ndern.";
$language_message[62]		=		"Benutzer Infos";
$language_message[63]		=		"Hier k&ouml;nnen Sie Ihre pers&ouml;nlichen Informationen, sowie auch Ihr pers&ouml;nliches Passwort &auml;ndern.";
$language_message[64]		=		"Einstellungen der pers&ouml;nlichen Daten Ihres Benutzerkontos";
$language_message[65]		=		"Benutzername";
$language_message[66]		=		"Ihr Benutzername auf diesem Panel";
$language_message[67]		=		"Zugriffslevel";
$language_message[68]		=		"Ihr Zugriffslevel auf dieses Panel";
$language_message[69]		=		"Kennwort";
$language_message[70]		=		"Ihr aktuelles Passwort";
$language_message[71]		=		"Wiederholung";
$language_message[72]		=		"Nur bei &Auml;nderung wiederholen";
$language_message[73]		=		"E-Mail Adresse";
$language_message[74]		=		"Ihr angegebene E-Mail Adresse";
$language_message[75]		=		"Vorname";
$language_message[76]		=		"Ihr Vorname";
$language_message[77]		=		"Nachname";
$language_message[78]		=		"Ihr Nachname";
$language_message[79]		=		"Geburtstag";
$language_message[80]		=		"Ihr Geburtsdatum";
$language_message[81]		=		"Stra&szlig;e";
$language_message[82]		=		"Ihre Stra&szlig;e";
$language_message[83]		=		"Ort";
$language_message[84]		=		"Ihr Wohnort";
$language_message[85]		=		"PLZ";
$language_message[86]		=		"Die Postleitzahl";
$language_message[87]		=		"Bundesland";
$language_message[88]		=		"Ihr Bundesland";
$language_message[89]		=		"Land";
$language_message[90]		=		"Ihr Aufenthaltsland";
$language_message[91]		=		"Telefon";
$language_message[92]		=		"Eine Telefonnummer";
$language_message[93]		=		"WWW";
$language_message[94]		=		"Ihre Webseite";
$language_message[95]		=		"Facebook";
$language_message[96]		=		"Ihre Facebook Seite";
$language_message[97]		=		"Ge&auml;nderte Informationen speichern";
$language_message[98]		=		"Ihr pers&ouml;nlicher Sicherheits API Code";
$language_message[99]		=		"Sicherheitscode";
$language_message[100]		=		"Ihr API Code";
$language_message[101]		=		"Neuen Sicherheitscode erstellen";
//
//	
//	./include/account_top.php
$language_message[102]		=		"Bitte &uuml;berpr&uuml;fen Sie die Eingabe der Passw&ouml;rter, diese stimmen nicht &uuml;berein";
$language_message[103]		=		"Ihre Benutzerdaten wurden erfolgreich in die Datenbank &uuml;bertragen";
$language_message[104]		=		"Ihre Benutzerdaten konnten nicht erfolgreich &uuml;bertragen werden";
$language_message[105]		=		"Ein neuer API Sicherheitscode wurde erfolgreich erstellt";
$language_message[106]		=		"Ein neuer API Sicherheitscode konnte nicht erstellt werden";
//
//	
//	./include/admradio_bottom.php
$language_message[107]		=		"Konfiguration der Shoutcast Server auf diesem Server";
$language_message[108]		=		"Hier haben Sie die M&ouml;glichkeit Shoutcast Server zu erstellen, bearbeiten, und zu l&ouml;schen. Diese Server k&ouml;nnen Sie auf einen beliebigen Benutzer dieses Panels registrieren. Falls Sie sich entscheiden den Benutzer sp&auml;ter zu &auml;ndern k&ouml;nnen Sie den Server ganz einfach editieren. Hier haben Sie auch die M&ouml;gleichkeit einen AutoDJ, dem Server hinzuzuf&uuml;gen, oder auch zu entziehen.";
$language_message[109]		=		"Shoutcast Server";
$language_message[110]		=		"Hier k&ouml;nnen Sie einen Shoutcast Server erstellen, bearbeiten, oder ganz einfach neustarten.";
$language_message[111]		=		"Kunde des Servers";
$language_message[112]		=		"Port";
$language_message[113]		=		"Speicherplatz";
$language_message[114]		=		"Neuer Server";
$language_message[115]		=		"Es sind keine Server auf Ihren Benutzernamen zugeteilt!";
$language_message[116]		=		"L&ouml;schen";
$language_message[117]		=		"Neustarten";
$language_message[118]		=		"Einstellen";
$language_message[119]		=		"Neuen SHOUTcast Server erstellen";
$language_message[120]		=		"Aktuellen SHOUTcast Server bearbeiten";
$language_message[121]		=		"SHOUTcast Konfigurationseinstellungen";
$language_message[122]		=		"Server Inhaber";
$language_message[123]		=		"Bitte geben Sie den Inhaber an";
$language_message[124]		=		"Admin Passwort";
$language_message[125]		=		"changeme";
$language_message[126]		=		"Admin Passwort zum Radioserver";
$language_message[127]		=		"DJ Passwort";
$language_message[128]		=		"DJ Passwort zum Radioserver";
$language_message[129]		=		"Radioserver Port";
$language_message[130]		=		"Port-Angabe des Radio Servers";
$language_message[131]		=		"Max Zuh&ouml;hrer";
$language_message[132]		=		"Max. Zuh&ouml;hreranzahl des Servers";
$language_message[133]		=		"Stream Bitrate";
$language_message[134]		=		"Erlaubte Streambitrate des Servers";
$language_message[135]		=		"AutoDJ Status";
$language_message[136]		=		"Eingeschaltet";
$language_message[137]		=		"Ausgeschaltet";
$language_message[138]		=		"Audio-/ Video DJ f&uuml;r Radioserver";
$language_message[139]		=		"Max Webspace";
$language_message[140]		=		"Max Webspace des Servers (MB)";
$language_message[141]		=		"Server Logfile";
$language_message[142]		=		"Speichert alle Serveraktivit&auml;ten";
$language_message[143]		=		"Realtime - [Log]";
$language_message[144]		=		"An";
$language_message[145]		=		"Aus";
$language_message[146]		=		"Status wird sek&uuml;ndlich aktualisiert";
$language_message[147]		=		"TCHLog - [Log]";
$language_message[148]		=		"An";
$language_message[149]		=		"Aus";
$language_message[150]		=		"YP Aktivi. wird in Logfile geloggt";
$language_message[151]		=		"Weblog - [Log]";
$language_message[152]		=		"An";
$language_message[153]		=		"Aus";
$language_message[154]		=		"Webaktivit&auml;ten werden geloggt";
$language_message[155]		=		"Screenlog - [Log]";
$language_message[156]		=		"An";
$language_message[157]		=		"Aus";
$language_message[158]		=		"Log wird in Console ausgegeben";
$language_message[159]		=		"W3C Enable";
$language_message[160]		=		"W3C Eingeschaltet";
$language_message[161]		=		"W3C Ausgeschaltet";
$language_message[162]		=		"Log wird in Console ausgegeben";
$language_message[163]		=		"W3C Logfile";
$language_message[164]		=		"Keine Logdatei speichern";
$language_message[165]		=		"Webaktivit&auml;ten werden geloggt";
$language_message[166]		=		"Titel Auflistung";
$language_message[167]		=		"Tracklimitierung f&uuml;r 'played'-Listing";
$language_message[168]		=		"Source IP";
$language_message[169]		=		"Quell (Source) IP des Radiostreams";
$language_message[170]		=		"Destination IP";
$language_message[171]		=		"Ziel (Destination) IP des R.-Streams";
$language_message[172]		=		"YP Port";
$language_message[173]		=		"Erreichbarkeitsport von YP";
$language_message[174]		=		"Name Lookups";
$language_message[175]		=		"DNS Aufl&ouml;sen";
$language_message[176]		=		"DNS Aufl&ouml;sung unterbinden";
$language_message[177]		=		"DNS Erkennung der Quell IP's";
$language_message[178]		=		"Auto Dump Users";
$language_message[179]		=		"User werden gekickt, wenn DJ Offline geht";
$language_message[180]		=		"User auf Stream belassen, wenn DJ Offline geht";
$language_message[181]		=		"Listener Kick bei DJ-Trennung";
$language_message[182]		=		"Auto Dump Time";
$language_message[183]		=		"Sekundenangabe f&uuml;r Listenerkick";
$language_message[184]		=		"Content Directory";
$language_message[185]		=		"Kein Contentdir Verzeichnis";
$language_message[186]		=		"Verzeichnis f&uuml;r abrufbaren Inhalt";
$language_message[187]		=		"Intro Datei";
$language_message[188]		=		"Keine Intro Datei";
$language_message[189]		=		"Verzeichnisangabe - Intro Datei";
$language_message[190]		=		"Backup Datei";
$language_message[191]		=		"Keine Backup Datei";
$language_message[192]		=		"Verzeichnisangabe - Backup Datei";
$language_message[193]		=		"Titel Format";
$language_message[194]		=		"Streamtitel Format Vorlage";
$language_message[195]		=		"&Ouml;ffentlicher Server";
$language_message[196]		=		"Radioserver wird in die YP gelistet";
$language_message[197]		=		"Radioserver wird nicht in die YP gelistet";
$language_message[198]		=		"Server bei SHOUTcast listen";
$language_message[199]		=		"Relay Server";
$language_message[200]		=		"Adresse zum Relayservers";
$language_message[201]		=		"Relay Port";
$language_message[202]		=		"Port zum Relayservers";
$language_message[203]		=		"Public Relay";
$language_message[204]		=		"Relayserver als Public zeigen";
$language_message[205]		=		"Relayserver als Private zeigen";
$language_message[206]		=		"Server bei YP als Public Relay";
$language_message[207]		=		"Meta Interval";
$language_message[208]		=		"Wert beibehalten";
$language_message[209]		=		"Absenden";
$language_message[210]		=		"wird schon benutzt, der Port wurde ge&auml;ndert in";
$language_message[211]		=		"Der Server wurde erfolgreich installiert und in die Datenbank kopiert";
$language_message[212]		=		"Der Server konnte nicht erstellt werden, bitte wenden Sie sich an den Support";
$language_message[213]		=		"Der angegebene Port ist keine Zahl, bitte &uuml;berpr&uuml;fen Sie das";
$language_message[214]		=		"Die angegebene ID stimmt mit keinem Server auf diesem Server &uuml;berein";
$language_message[215]		=		"Der Server wurde erfolgreich auf der Datenbank und diesem Panel gel&ouml;scht";
$language_message[216]		=		"Der gew&uuml;nschte Server konnte nicht aus diesem System gel&ouml;scht werden";
$language_message[217]		=		"Die angegebene ID stimmt mit keinem Server auf diesem Server &uuml;berein";
$language_message[218]		=		"Die Servereinstellungen wurden erfolgreich ge&auml;ndert und gespeichert";
$language_message[219]		=		"Die Einstellungen konnten nicht in die Datenbank gespeichert werden";
$language_message[220]		=		"Dieser Server existiert nicht in der Datenbank oder auf diesem Server";
$language_message[221]		=		"Es ist kein Server vorhanden";
$language_message[222]		=		"Server wurde neugestartet";
$language_message[223]		=		"Server konnte nicht gestartet werden";
//
//
//	./include/admserver_bottom.php
$language_message[224]		=		"Eigenschaften des Servers";
$language_message[225]		=		"Hier k&ouml;nnen Sie wichtige Einstellungen des Servers konfigurieren und ver&auml;ndern. Diese wichtige Daten werden f&uuml;r alle Funktionen des Panel ben&ouml;tigt, damit dieses einwandfrei funktionieren kann. Alle diese Konfigurationen sind nur Ihnen, also dem Administrator dieses Panels, einsehbar. Diese k&ouml;nnen nur von Ihnen ver&auml;ndert werden. Wir empfehlen Ihnen also diese Einstellungen mit Vorsicht zu bearbeiten.";
$language_message[226]		=		"Server Settings";
$language_message[227]		=		"&Uuml;ber das folgende Formular k&ouml;nnen Sie wichtige Einstellungen des Servers hinzuf&uuml;gen oder &auml;ndern.";
$language_message[228]		=		"Servereinstellungen dieses Panels";
$language_message[229]		=		"IP/DNS Adresse";
$language_message[230]		=		"Die IP/DNS des aktuellen Server";
$language_message[231]		=		"Server Startup";
$language_message[232]		=		"Shellscript &uuml;ber System (empfohlen)";
$language_message[233]		=		"SSH2 Verbindung &uuml;ber PHP SSH2 Modul";
$language_message[234]		=		"Startfunktion einstellen";
$language_message[235]		=		"SSH Benutzer";
$language_message[236]		=		"Der SSH Benutzername";
$language_message[237]		=		"SSH Passwort";
$language_message[238]		=		"Das SSH Passwort";
$language_message[239]		=		"SSH Port";
$language_message[240]		=		"Der SSH Port zum WebServer";
$language_message[241]		=		"Verzeichnis";
$language_message[242]		=		"Das Verzeichnis zum Panel";
$language_message[243]		=		"Server Name";
$language_message[244]		=		"Der Servername des Servers";
$language_message[245]		=		"Server Slogan";
$language_message[246]		=		"Der Slogan Ihres Servers";
$language_message[247]		=		"Hypertext-Zugriff";
$language_message[248]		=		".htaccess f&uuml;r Einstellungen erstellen";
$language_message[249]		=		"Keine .htaccess f&uuml;r Einstellungen erstellen";
$language_message[250]		=		".htaccess Erstellung";
$language_message[251]		=		"MP3-Dateigr&ouml;&szlig;e";
$language_message[252]		=		"Maximale MP3 Dateigr&ouml;&szlig;e (in MB)";
$language_message[253]		=		"Ausf&uuml;hrungszeit";
$language_message[254]		=		"Max. Upload Ausf&uuml;hrung in Sek.";
$language_message[255]		=		"Panel Sprache";
$language_message[256]		=		"Spracheinstellung f�r das Panel";
$language_message[257]		=		"Updatepr�fung";
$language_message[258]		=		"Automatische Updates eingeschaltet";
$language_message[259]		=		"Automatische Updates ausgeschaltet";
$language_message[260]		=		"Updatepr�fung auf neue Versionen";
$language_message[261]		=		"Radio Config";
$language_message[262]		=		"Radio Config wird vom Server gel�scht";
$language_message[263]		=		"Radio Config wird auf Server belassen";
$language_message[264]		=		"Konfigurationsspeicherung nach Start";
$language_message[265]		=		"AutoDJ Config";
$language_message[266]		=		"AutoDJ Config wird vom Server gel�scht";
$language_message[267]		=		"AutoDJ Config wird auf Server belassen";
$language_message[268]		=		"Konfigurationsspeicherung nach Start";
$language_message[269]		=		"Captcha Code";
$language_message[270]		=		"Captcha Code beim Login abfragen";
$language_message[271]		=		"Captcha Code Abfrage ist ausgeschaltet";
$language_message[272]		=		"Abfragecode kann Sicherheit erh�hen";
$language_message[273]		=		"News Auflistung";
$language_message[274]		=		"Den Newsfeed auf Startseite anzeigen";
$language_message[275]		=		"Keinen Newsfeed auf Startseite anzeigen";
$language_message[276]		=		"Aktuelle News auf der Startseite";
$language_message[277]		=		"Windows Tool";
$language_message[278]		=		"Downloadlink auf Startseite anzeigen";
$language_message[279]		=		"Kein Downloadlink auf Startseite anzeigen";
$language_message[280]		=		"Downloadlink zum Tool anzeigen";
$language_message[281]		=		"Logobranding URL";
$language_message[282]		=		"Ihr Logo als Panel Branding";
$language_message[283]		=		"Auflistingslimit";
$language_message[284]		=		"Limiterung der Seitenauflistung";
$language_message[285]		=		"Absenden";
$language_message[286]		=		"Alle Einstellungen wurden erfolgreich ge&auml;ndert und gespeichert";
$language_message[287]		=		"Ein schwerwiegender Fehler ist bei der Speicherung aufgetreten";
//
//
//	sadasd
$language_message[288]		=		"Benutzereinstellungen f&uuml;r dieses Panel";
$language_message[289]		=		"Hier k&ouml;nnen Sie alle Benutzer dieses Panels editieren, oder l&ouml;schen. Sie k&ouml;nnen nat&uuml;rlich auch weitere Benutzer dem Panel hinzuf&uuml;gen. Alle diese Einstellungen k&ouml;nnen Sie jederzeit wieder ver&auml;ndern. Administratoren k&ouml;nnen sich nicht l&ouml;schen. Nachdem Sie den Benutzer erfolgreich erstellt haben, empfehlen wir Ihnen diesem einen Server zu registrieren.";
$language_message[290]		=		"Benutzer";
$language_message[291]		=		"Bitte w&auml;hlen Sie zwischen eines der folgenden Benutzer um diesen zu editieren. Oder erstellen Sie einen neuen.";
$language_message[292]		=		"Benutzername";
$language_message[293]		=		"Zugriffslevel";
$language_message[294]		=		"Anzahl der Server";
$language_message[295]		=		"Neuer User";
$language_message[296]		=		"Server registriert";
$language_message[297]		=		"l&ouml;schen";
$language_message[298]		=		"einstellen";
$language_message[299]		=		"Neue Benutzerdaten eingeben";
$language_message[300]		=		"Benutzerdaten ver&auml;ndern";
$language_message[301]		=		"Servereinstellungen dieses Panels";
$language_message[302]		=		"Administrator";
$language_message[303]		=		"Serverkunde / Kunde / Reseller";
$language_message[304]		=		"Deejay (DJ) / Radiomoderator";
$language_message[305]		=		"Ihr Zugriffslevel auf dieses Panel";
$language_message[306]		=		"Vorname des Kunden";
$language_message[307]		=		"Nachname des Kunden";
$language_message[308]		=		"Geburtdatum des Kunden";
$language_message[309]		=		"Adresse des Kunden";
$language_message[310]		=		"Wohnort des Kunden";
$language_message[311]		=		"PLZ des Kunden";
$language_message[312]		=		"Bundesland des Kunden";
$language_message[313]		=		"Aufenthaltsland des Kunden";
$language_message[314]		=		"Telefonnummer des Kunden";
$language_message[315]		=		"Webadresse des Kunden";
$language_message[316]		=		"Facebook Adresse des Kunden";
$language_message[317]		=		"Informationen aktualisieren";
$language_message[318]		=		"Neuen Benutzer erstellen";

$language_message[319]		=		"Dieser Benutzer existiert schon und kann daher nicht nochmal erstellt werden";





/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//		TRANSLATE FILE UNTIL HERE ; FROM NOW ON ITS NOT DONE YET!!!!!
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

//	./pages/admuser_bottom.php


$language_message["264"]	=		"Absenden";
$language_message["265"]	=		"Zugriffsberechtigung";

$language_message["267"]	=		"Bitte &uuml;berpr&uuml;fen Sie die Eingabe der Passw&ouml;rter, diese stimmen nicht &uuml;berein";
$language_message["268"]	=		"Der Benutzer wurde erfolgreich erstellt, und in die Datenbank eingetragen";
$language_message["269"]	=		"Der Benutzer konnte nicht erfolgreich in die Datenbank eingetragen werden";
$language_message["270"]	=		"Dieser Benutzer existiert nicht, bitte &uuml;berpr&uuml;fen Sie die ID";
$language_message["271"]	=		"Ihre Ver&auml;nderungen wurden erfolgreich ver&auml;ndert und gespeichert";
$language_message["272"]	=		"Die Daten konnten nicht korrekt in die Datenbank eingef&uuml;gt werden";
$language_message["273"]	=		"Ein Benutzer kann nicht seinen eigenen Benutzernamen aus dem Panel l&ouml;schen";
$language_message["274"]	=		"Ein Administrator kann nur direkt &uuml;ber die Datenbank gel&ouml;scht werden";
$language_message["275"]	=		"Der Benutzer wurde erfolgreich aus der Datenbank und dem System gel&ouml;scht";
$language_message["276"]	=		"Der Benutzer konnte nicht erfolgreich aus dem System gel&ouml;scht werden";
//	
//	
//	./pages/autodj_bottom.php
$language_message["277"]	=		"Shoutcast AutoDJ Konfiguration";
$language_message["278"]	=		"Hier k&ouml;nnen Sie den AutoDJ f&uuml;r Ihre Shoutcast Server konfigurieren. Bitte w&auml;hlen Sie zwischen den Wiedergabelisten die Sie &uuml;ber die MP3 Einstellungen erstellt haben, und klicken sie dann auf Starten. Bei Mausklick auf den gelben Button k&ouml;nnen Sie die Einstellungen f&uuml;r den AutoDJ &auml;ndern, welche den Titel und die Stream-Qualit&auml;t beinhalten. Nat&uuml;rlich k&ouml;nnen Sie diesen auch hiermit beenden.";
$language_message["279"]	=		"AutoDJ Auswahl";
$language_message["280"]	=		"Bitte &uuml;ber das Auswahlmen&uuml; die Wiedergabeliste ausw&auml;hlen, mit der Sie den AutoDJ starten m&ouml;chten.";
$language_message["281"]	=		"IP-Adresse";
$language_message["282"]	=		"Port";
$language_message["283"]	=		"Playlist";
$language_message["284"]	=		"Es sind keine Server auf Ihren Benutzernamen zugeteilt!";
$language_message["285"]	=		"Starten";
$language_message["286"]	=		"Stoppen";
$language_message["287"]	=		"Einstellen";
$language_message["288"]	=		"Eigenschaften des AutoDJ Servers auf Port";
$language_message["289"]	=		"Bitte f&uuml;llen Sie die folgenden Formulareintr&auml;ge aus um den AutoDJ Server korrekt konfigurieren zu k&ouml;nnen. Diese Einstellungen k&ouml;nnen Sie jederzeit wieder &auml;ndern oder auch l&ouml;schen. Bitte versuchen Sie keines dieser Eintr&auml;ge leer zu lassen, da es sonst zu Problemen beim Start des AutoDJ Server zum Shoutcast Server kommen kann. ";
$language_message["290"]	=		"AutoDJ Konfig";
$language_message["291"]	=		"Bitte f&uuml;llen Sie die folgenden Formulare korrekt aus und versuchen Sie nichts frei zu lassen.";
$language_message["292"]	=		"AutoDJ Konfiguration";
$language_message["293"]	=		"Server IP";
$language_message["294"]	=		"Die Serverip des Shoutcast Server";
$language_message["295"]	=		"Server Port";
$language_message["296"]	=		"Der Serverport des Shoutcast Server";
$language_message["297"]	=		"Server Password";
$language_message["298"]	=		"Das Passwort zum Verbinden";
$language_message["299"]	=		"Bitrate";
$language_message["300"]	=		"Die &Uuml;bertragungsrate des Streams";
$language_message["301"]	=		"Stream Titel";
$language_message["302"]	=		"Der Titel dieses Streams";
$language_message["303"]	=		"Stream URL";
$language_message["304"]	=		"Die Webadresse Ihres Radios/etc.";
$language_message["305"]	=		"Stream Genre";
$language_message["306"]	=		"Das Musikgenre dieses Senders";
$language_message["307"]	=		"Shuffle";
$language_message["308"]	=		"Zuf&auml;llige Wiedergabe";
$language_message["309"]	=		"Qualit&auml;t";
$language_message["310"]	=		"Qualit&auml;t [1 = Beste | 10 = Schnellste]";
$language_message["311"]	=		"Crossfade";
$language_message["312"]	=		"&Uuml;bergang der Lieder";
$language_message["313"]	=		"Crossfade L&auml;nge";
$language_message["314"]	=		"Die L&auml;nge des Musik&uuml;bergangs [in Millisekunde]";
$language_message["315"]	=		"Bandbreite";
$language_message["316"]	=		"Musikbandbreite in Hz";
$language_message["317"]	=		"ID3 Benutzung";
$language_message["318"]	=		"ID3 Benutzung der MP3 Dateien";
$language_message["319"]	=		"&Ouml;ffentlich zeigen";
$language_message["320"]	=		"Stream &ouml;ffentlich gezeigt werden";
$language_message["321"]	=		"Channel";
$language_message["322"]	=		"Musikchannel";
$language_message["323"]	=		"AIM";
$language_message["324"]	=		"Benutzer Verbindung f&uuml;r AOL";
$language_message["325"]	=		"ICQ";
$language_message["326"]	=		"Benutzer Verbindung f&uuml;r ICQ";
$language_message["327"]	=		"IRC";
$language_message["328"]	=		"Benutzer Verbindung f&uuml;r IRC";
$language_message["329"]	=		"Aktualisieren";
$language_message["330"]	=		"Zur&uuml;ck zur Auswahl";
$language_message["331"]	=		"Aktuell ist ein DJ mit dem Server verbunden, bitte melden Sie sich zuerst ab";
$language_message["332"]	=		"Es wurde keine Playlist angegeben, mit welcher der Server starten kann";
$language_message["333"]	=		"Der AutoDJ wurde erfolgreich mit der angegebenen Wiedergabeliste gestartet";
$language_message["334"]	=		"Es konnte keine Prozess ID gefunden werden. Der Port wurde nicht gestartet";
$language_message["335"]	=		"Der AutoDJ wurde erfolgreich von diesen Port getrennt und wurde beendet";
$language_message["336"]	=		"Die Konfigurationsdateien f&uuml;r Port";	// $language_message["336"] portnumber $language_message["336_pre"]
$language_message["336_pre"]=		"wurden erfgolreich aktualisiert";
$language_message["337"]	=		"Diesem Server ist keine AutoDJ Funktion zugewiesen, bitte Admin kontaktieren";
//	
//	
//	./pages/contact_bottom.php
$language_message["338"]	=		"Kontaktm&ouml;glichkeit an den Administrator";
$language_message["339"]	=		"Hier haben Sie die M&ouml;glichkeit, den Administrator des Server zu kontaktieren. Sofern sich die Frage oder das Anliegen um Ihr Produkt oder dem Server handelt, kontaktieren Sie bitte den Admin, andernfalls bitte das Programmiererteam des Panes. Administratoren k&ouml;nnen &uuml;ber dieses Formular Nachrichten verschicken, um damit z.B. andere Admins zu kontaktieren.";
$language_message["340"]	=		"Kontaktformular";
$language_message["341"]	=		"Bei Fragen rund um Ihren Shoutcast Server und dieses Panel k&ouml;nnen Sie hierdr&uuml;ber Ihren Admin kontaktieren.";
$language_message["342"]	=		"Hier haben Sie die M&ouml;glichkeit den Administrator des Servers zu kontaktieren";
$language_message["343"]	=		"Name";
$language_message["344"]	=		"Hier bitte ihren Namen eintragen";
$language_message["345"]	=		"EMail Adresse";
$language_message["346"]	=		"Keine g&uuml;ltige EMail!";
$language_message["347"]	=		"Eintrag in Ordnung!";
$language_message["348"]	=		"Betreff";
$language_message["349"]	=		"Bitte einen Betreff eingeben!";
$language_message["350"]	=		"Eintrag in Ordnung!";
$language_message["351"]	=		"Sie haben keine Nachricht eingegeben!";
$language_message["352"]	=		"Eintrag in Ordnung!";
$language_message["353"]	=		"Absenden";
$language_message["354"]	=		"Zur&uuml;cksetzen";
$language_message["355"]	=		"Ihre Nachricht wurde erfolgreich an den Administrator versendet";
$language_message["356"]	=		"Ihre Nachricht konnte leider nicht erfolgreich versendet werden";
$language_message["357"]	=		"Es wurde keine g&uuml;ltige EMail Adresse eingegeben";
//	
//	
//	./pages/main_bottom.php
$language_message["358"]	=		"Schnell&uuml;bersicht auf alle Funktionen";
$language_message["359"]	=		"AutoDJ";
$language_message["360"]	=		"Mein Konto";
$language_message["361"]	=		"Kontakt";
$language_message["362"]	=		"Eigene Server";
$language_message["363"]	=		"MP3-Upload";
$language_message["364"]	=		"Einstellungen";
$language_message["365"]	=		"Radioserver";
$language_message["366"]	=		"Kunden";
$language_message["367"]	=		"Hilfsinfomenu";
$language_message["368"]	=		"Hier finden Sie, auch auf allen weiteren Unterseiten, alle Informationen zu der aktuellen Seite.";
$language_message["369"]	=		"Auf dieser Hauptseite k&ouml;nnen Sie durch Schnellstarticons direkt auf die gew&uuml;nschte Funktion kommen.";
$language_message["370"]	=		"Nachrichtencenter";
$language_message["371"]	=		"Keine neue Nachrichten verf&uuml;gbar";
$language_message["372"]	=		"l&ouml;schen";
$language_message["373"]	=		"lesen";
//	
//	
//	./pages/music_bottom.php
$language_message["374"]	=		"Auswahl des Servers f&uuml;r den Upload der MP3 Dateien";
$language_message["375"]	=		"Zur Ausf&uuml;hrung des AutoDJ ben&ouml;tigen Sie Multimedia Dateien, welche &uuml;ber den AutoDJ dann an den jeweiligen Shoutcast Server gesendet werden. Diese k&ouml;nnen Sie hier auf den Server hochladen, und dann als Playlist speichern. Diese werden dann dann nach dem n&auml;chsten AutoDJ-Neustart automatisch geladen. Bitte w&auml;hlen Sie nun hier folgend den jeweiligen Server aus.";
$language_message["376"]	=		"Server Auswahl";
$language_message["377"]	=		"Bitte w&auml;hlen Sie den Server, welchen Sie f&uuml;r den Upload oder die Playlistfunktion, ausw&auml;hlen m&ouml;chten.";
$language_message["378"]	=		"IP-Adresse";
$language_message["379"]	=		"Port";
$language_message["380"]	=		"Speicherplatz";
$language_message["381"]	=		"Traffic";
$language_message["382"]	=		"Es sind keine Server auf Ihren Benutzernamen zugeteilt!";
$language_message["383"]	=		"playlist";
$language_message["384"]	=		"upload";
$language_message["385"]	=		"Es wurde kein Port f&uuml;r die weitere Funktion ausgew&auml;hlt";
$language_message["386"]	=		"Sie besitzen keine Rechte um diesen Port f&uuml;r AutoDJ steuern zu k&ouml;nnen";
$language_message["387"]	=		"Das Verzeichnis dieses Ports konnte nicht erstellt werden, bitte CHMOD &uuml;berpr&uuml;fen";
$language_message["388"]	=		"Der Speicherplatz dieses Ports wurde &uuml;berschritten, ein weiterer Upload ist nicht m&ouml;glich";
$language_message["389"]	=		"Der Ordnerinhalt des Ordners dieses Ports konnte nicht ausgelesen werden";
$language_message["390"]	=		"Sie besitzen keine Rechte um diesen Port f&uuml;r AutoDJ zugreifen zu k&ouml;nnen";
//	
//	
//	./pages/playlist_bottom.php
$language_message["391"]	=		"Playlisten Konfiguration f&uuml;r den Shoutcast Port";
$language_message["392"]	=		"Hier k&ouml;nnen Sie die Wiedergabelisten f&uuml;r Ihren AutoDJ zuf&auml;llig mit allen Liedern oder individuell erstellen. Bei einer zuf&auml;lligen Erstellung einer Wiedergabeliste, werden alle Lieder, welche sich zu dem aktuellen Zeitpunkt in Ihrem Musik-Upload Ordner befinden, in die Wiedergabelisten zuf&auml;llig eingef&uuml;gt. Bei einer individuellen Auswahl, k&ouml;nnen Sie Ihre Wiedergabeliste selbst bestimmen.";
$language_message["393"]	=		"Playlist";
$language_message["394"]	=		"Bitte w&auml;hlen Sie zwischen einer zuf&auml;lligen oder individuellen Erstellung, oder einer neuen Playlist.";
$language_message["395"]	=		"Neue Playlist erstellen";
$language_message["396"]	=		"Gr&ouml;&szlig;e";
$language_message["397"]	=		"neue playlist";
$language_message["398"]	=		"l&ouml;schen";
$language_message["399"]	=		"zuf&auml;llig";
$language_message["400"]	=		"individuell";
$language_message["401"]	=		"Playlist indiviuell gestalten";
$language_message["402"]	=		"Playlist";
$language_message["403"]	=		"Ihr Shoutcast Server Musikordner";
$language_message["404"]	=		"Ihre AutoDJ-Playliste";
$language_message["405"]	=		"Speichern";
$language_message["406"]	=		"Playlist leeren";
$language_message["407"]	=		"Die Wiedergabeliste wurde erfolgreich gel&ouml;scht";
$language_message["408"]	=		"Die Wiedergabeliste konnte nicht gefunden werden";
$language_message["409"]	=		"Die Playliste konnte nicht erstellt werden!";
$language_message["410"]	=		"Ihre Playliste wurde erfolgreich ge&auml;ndert und gespeichert!";
$language_message["411"]	=		"Die Playliste konnte nicht erstellt werden!";
$language_message["412"]	=		"Ihre Playliste wurde erfolgreich ge&auml;ndert und gespeichert!";
$language_message["413"]	=		"Die Playliste konnte nicht gefunden werden, bitte l&ouml;schen Sie diese!";
$language_message["414"]	=		"Das Portverzeichnis existiert nicht!";
$language_message["415"]	=		"Eine Playlist mit solch einem Dateinamen existiert schon!";
$language_message["416"]	=		"Dieser Dateiname ist nicht erlaubt, bitte &auml;ndern Sie diesen!";
$language_message["417"]	=		"Ihre Playliste wurde erfolgreich ge&auml;ndert und gespeichert!";
$language_message["418"]	=		"Die Playliste konnte nicht gefunden werden, bitte l&ouml;schen Sie diese!";
$language_message["419"]	=		"Das Portverzeichnis existiert nicht!";
$language_message["420"]	=		"Das Verzeichnis konnte nicht ausgelesen werden!";
$language_message["421"]	=		"Das Verzeichnis konnte nicht ausgelesen werden!";
//	
//	
//	./pages/public_bottom.php
$language_message["422"]	=		"&Ouml;ffentliche Server";
$language_message["423"]	=		"Alle Benutzer dieses Panels, welche einen Zugang zu diesem Panel besitzen, sind in der Lage alle hier folgenden Server zu sehen. Diese wurden vom Administrator dieses Panels f&uuml;r diese freigegeben. Diese k&ouml;nnen als Beispiel Server oder als Testserver benutzt werden. Falls der	jeweilige	Server	online ist, ist in der Tabelle ein zugeh&ouml;riger Link verf&uuml;gbar, auf den man dann den Stream verfolgen kann.";
$language_message["424"]	=		"Public Server";
$language_message["425"]	=		"Alle Benutzer des Panels auf diesem Server k&ouml;nnen alle folgenden Server einsehen und verfolgen.";
$language_message["426"]	=		"IP";
$language_message["427"]	=		"Port";
$language_message["428"]	=		"Inhaber";
$language_message["429"]	=		"Webspeicherplatz";
$language_message["430"]	=		"Es sind keine &Ouml;ffentlichen Server verf&uuml;gbar";
$language_message["431"]	=		"Anh&ouml;ren";
$language_message["432"]	=		"Offline";
//	
//	
//	./pages/server_bottom.php
$language_message["433"]	=		"Konfiguration Ihres Shoutcast Servers";
$language_message["434"]	=		"Hier k&ouml;nnen Sie Ihren Shoutcast Server ausw&auml;hlen um diesen dann zu editieren, starten, oder zu stoppen. Alle folgenden Server wurden Ihrem Benutzernamen zugewiesen. Falls Sie eine Erweiterung des Webspeichers w&uuml;nschen, kontaktieren Sie bitte Ihren Administrator, welcher Ihnen den Speicher erwarten k&ouml;nnte. Bei einem Mausklick auf den gew&auml;hlten Server gelangen Sie direkt auf diesen.";
$language_message["435"]	=		"Server Auswahl";
$language_message["436"]	=		"Bitte w&auml;hlen Sie von den folgenden Servern um diesen zu editieren, starten, oder stoppen zu k&ouml;nnen.";
$language_message["437"]	=		"IP-Adresse";
$language_message["438"]	=		"Port";
$language_message["439"]	=		"Speicherplatz";
$language_message["440"]	=		"Es sind keine Server auf Ihren Benutzernamen zugeteilt!";
$language_message["441"]	=		"Stoppen";
$language_message["442"]	=		"Starten";
$language_message["443"]	=		"Einstellen";
$language_message["444"]	=		"Eigenschaften des Shoutcast Server auf Port";
$language_message["445"]	=		"Folgend k&ouml;nnen Sie die Konfigurationsdatei des Shoutcast Servers &auml;ndern. Diese ist notwendig damit der Server einwandfrei funktioniert. Diese Einstellungen k&ouml;nnen Sie jederzeit &auml;ndern. Bitte versuchen Sie alle Eintr&auml;ge zu f&uuml;llen damit es zu keinen Komplikationen beim Start des Servers kommen kann. Alle diese Einstellungen kann jederzeit vom Administrator ver&auml;ndert werden.";
$language_message["446"]	=		"Shoutcast Konfig";
$language_message["447"]	=		"Bitte alle folgenden Formulareintr&auml;ge f&uuml;r die Konfiguration des Shoutcast Servers einstellen.";
$language_message["448"]	=		"Shoutcast Server Konfiguration";
$language_message["449"]	=		"Aktualisieren";
$language_message["450"]	=		"Zur&uuml;ck zur Auswahl";
$language_message["451"]	=		"Server Kunde";
$language_message["452"]	=		"Maximale Zuh&ouml;rer";
$language_message["453"]	=		"Server Port";
$language_message["454"]	=		"Streambitrate";
$language_message["455"]	=		"Admin Passwort";
$language_message["456"]	=		"Passwort";
$language_message["457"]	=		"&Ouml;ffentlich-Panel";
$language_message["458"]	=		"Logfile";
$language_message["459"]	=		"Realtime";
$language_message["460"]	=		"Screenlog";
$language_message["461"]	=		"ShowLastSongs";
$language_message["462"]	=		"Tchlog";
$language_message["463"]	=		"Weblog";
$language_message["464"]	=		"W3CEnable";
$language_message["465"]	=		"W3CLog";
$language_message["466"]	=		"Source IP";
$language_message["467"]	=		"Destination IP";
$language_message["468"]	=		"YPort";
$language_message["469"]	=		"Name Lookups";
$language_message["470"]	=		"Relay Port";
$language_message["471"]	=		"Relay Server";
$language_message["472"]	=		"AutoDumpUser";
$language_message["473"]	=		"AutoDumpUserTime";
$language_message["474"]	=		"ContentDir";
$language_message["475"]	=		"Introfile";
$language_message["476"]	=		"Titleformat";
$language_message["477"]	=		"Publicserver";
$language_message["478"]	=		"Allow Relay";
$language_message["479"]	=		"Allow Public Relay";
$language_message["480"]	=		"Metaintervall";
$language_message["481"]	=		"Kundenname des Server";
$language_message["482"]	=		"Maximale Zuh&ouml;rer";
$language_message["483"]	=		"Der Port des Shoutcast Streams";
$language_message["484"]	=		"Maximale Bitrate f&uuml;r den AutoDJ und Radioservers";
$language_message["485"]	=		"Administrator Password des Streams";
$language_message["486"]	=		"DJ Passwort des Streams";
$language_message["487"]	=		"Als &Ouml;ffentlichen Server im Panel anzeigen";
$language_message["488"]	=		"Speicherort der Logfiles";
$language_message["489"]	=		"Streaminfos sollen aktuell ausgegeben werden";
$language_message["490"]	=		"Loginhalt wird in der Anzeige angezeigt";
$language_message["491"]	=		"Gibt an wieviele Songs in der /played.html anzeigt werden";
$language_message["492"]	=		"Sollen YP Tracks mitgeloggt werden";
$language_message["493"]	=		"Sollen die Webaktivit&auml;ten geloggt werden";
$language_message["494"]	=		"Sollen W3C Aktivit&auml;ten geloggt werden";
$language_message["495"]	=		"Speicherort der W3CLog Datei";
$language_message["496"]	=		"Quell-IP Adresse des Streams";
$language_message["497"]	=		"Ziel-IP Adresse des Streams";
$language_message["498"]	=		"Y-Port f&uuml;r Verbindung zu yp.shoutcast.com";
$language_message["499"]	=		"DNS Erkennung der Quell IP's";
$language_message["500"]	=		"Falls dieser Shoutcast Server als Relay dienen soll. Port-Angabe";
$language_message["501"]	=		"IP-Adresse des Relay";
$language_message["502"]	=		"Falls User gekickt werden sollen wenn Quelle sich abmeldet";
$language_message["503"]	=		"Sekundenangabe nach dem der Listener gekickt werden sollen";
$language_message["504"]	=		"Verzeichnisangabe des Inhalts";
$language_message["505"]	=		"Verzeichnisangabe der Intro-Datei";
$language_message["506"]	=		"Server Title Format";
$language_message["507"]	=		"Shoutcast Server &ouml;ffentlich zeigen";
$language_message["508"]	=		"Server auf anderen Server als Inhalt erlauben";
$language_message["509"]	=		"RelayServer als &ouml;ffentlich zeigen";
$language_message["510"]	=		"Nur Metaangabe, belassen Sie es auf 32768";
$language_message["511"]	=		"Dieser Server existiert nicht, oder ist nicht auf Sie registriert";
$language_message["512"]	=		"Dieser Server existiert nicht in der Datenbank und auf diesem Server";
$language_message["513"]	=		"Dieser Server ist schon Online, und ben&ouml;tigt kein weiteren Start";
$language_message["514"]	=		"Das Panel kann die tempor&auml;re Konfigdatei nicht erstellen";
$language_message["515"]	=		"Das Panel kann die tempor&auml;re Konfigdatei nicht beschreiben";
$language_message["516"]	=		"Panel kann den Shoutcast Server nicht starten, bitte Admin kontaktieren";
$language_message["517"]	=		"Panel kann den Shoutcast Server nicht starten, Admin wurde kontaktiert";
$language_message["518"]	=		"Panel hat den Shoutcast Server neugestartet und ist jetzt Online";
$language_message["519"]	=		"Dieser Shoutcast Server ist nicht gestartet worden, und ist nicht erreichbar";
$language_message["520"]	=		"Die PID des Servers konnte nicht aus der Datenbank gelesen werden";
$language_message["521"]	=		"Panel hat den Shoutcast Server erfolgreich geschlossen und ist jetzt beendet";
$language_message["522"]	=		"Die Einstellungen wurden erfolgreich in die Datenbank &uuml;bertragen";
$language_message["523"]	=		"Die Einstellungen konnten nicht erfolgreich &uuml;bertragen werden";
//	
//	
//	./pages/update.php
$language_message["524"]	=		"Es ist eine neuere Version f&uuml;r dieses Panel verf&uuml;gbar, bitte aktualisieren";
//	
//	
//	./pages/upload_bottom.php
$language_message["525"]	=		"Dateiupload auf den Shoutcast Port";
$language_message["526"]	=		"Hier k&ouml;nnen Sie ihre MP3 Dateien, welche sp&auml;ter &uuml;ber den AutoDJ an den Shoutcast Server gesendet werden hochladen. Bitte achten Sie dabei das nur der verf&uuml;gbare Speicherplatz daf&uuml;r benutzt werden kann. Bitte beachten Sie auch die Limiterungen der folgend angezeigten Werte. Darunter k&ouml;nnen Sie Ihre Dateien aufgelistet sehen, welche Sie dort downloaden oder auch von Ihrem Speicher l&ouml;schen k&ouml;nnen.";
$language_message["527"]	=		"Upload von MP3";
$language_message["528"]	=		"Bitte nach jeder &Auml;nderung jeglicher Dateien hier, die Playliste des jeweiligen AutoDJ Server aktualisieren.";
$language_message["529"]	=		"MP3 Upload auf den Port";
$language_message["530"]	=		"Einstellungen";
$language_message["531"]	=		"Maximal";
$language_message["532"]	=		"Aktuell";
$language_message["533"]	=		"Speicherplatz";
$language_message["534"]	=		"Datenverkehr";
$language_message["535"]	=		"Maximale Dateigr&ouml;&szlig;e";
$language_message["536"]	=		"Erlaubter Dateityp";
$language_message["537"]	=		"Shoutcast Port";
$language_message["538"]	=		"Datei Hochladen";
$language_message["539"]	=		"Hochladen";
$language_message["540"]	=		"Zur&uuml;ck zur Auswahl";
$language_message["541"]	=		"Dateiname";
$language_message["542"]	=		"Gr&ouml;&szlig;e";
$language_message["543"]	=		"l&ouml;schen";
$language_message["544"]	=		"download";
$language_message["545"]	=		"Zur&uuml;ck";
$language_message["546"]	=		"Vor";
$language_message["547"]	=		"Der Gesamtspeicherplatz des Ordners konnte nicht ermittelt werden";
$language_message["548"]	=		"Der Gesamtspeicherplatz des Ordners konnte nicht ermittelt werden";
$language_message["549"]	=		"Die Dateigr&ouml;&szlig;e &uuml;berschreitet den verf&uuml;gbaren Speicherplatz";
$language_message["550"]	=		"Die Datei wurde erfolgreich hochgeladen und in das Verzeichnis kopiert";
$language_message["551"]	=		"Es ist ein Fehler beim Versuch aufgetreten, diese Datei hochzuladen";
$language_message["552"]	=		"Diese Datei existiert schon auf diesem System Port";
$language_message["553"]	=		"Dieser Dateityp ist nicht erlaubt, oder beinhaltet keine MP3 Datei";
$language_message["554"]	=		"Der Gesamtspeicherplatz des Ordners konnte nicht ermittelt werden";
$language_message["555"]	=		"Der Gesamtspeicherplatz des Ordners konnte nicht ermittelt werden";
$language_message["556"]	=		"Die Datei wurde erfolgreich vom System und dem Panel gel&ouml;scht";
$language_message["557"]	=		"Die Datei zur L&ouml;schung kann nicht im System gefunden werden";
$language_message["558"]	=		"Der Download konnte nicht gestartet werden, da keine Datei gefunden wurde";
$language_message["559"]	=		"Der Gesamtspeicherplatz des Ordners konnte nicht ermittelt werden";
$language_message["560"]	=		"Der Gesamtspeicherplatz des Ordners konnte nicht ermittelt werden";
$language_message["561"]	=		"Das Verzeichnis konnte nicht ausgelesen werden!";
$language_message["562"]	=		"Das Verzeichnis konnte nicht ausgelesen werden!";
$language_message["563"]	=		"Das Verzeichnis konnte nicht ausgelesen werden!";
//
//

//
//
//	changes
$language_message["565"]	=		"";
$language_message["566"]	=		"An";
$language_message["567"]	=		"Aus";
$language_message["568"]	=		"Mono";
$language_message["569"]	=		"Stereo";
$language_message["570"]	=		"Sperren";
$language_message["571"]	=		"Hier k&ouml;nnen Sie diesen Benutzer sperren";
$language_message["572"]	=		"Entsperrt";
$language_message["573"]	=		"Gesperrt";
$language_message["574"]	=		"Backupfile";
$language_message["575"]	=		"Wenn keine Quelle vorhanden";
$language_message["576"]	=		"Keine Intro Datei";
$language_message["577"]	=		"Keine Backup Datei";
$language_message["578"]	=		"Keine Content Verzeichnis";

$language_message["580"]	=		"NSV Bitrate";
$language_message["581"]	=		"kbps - Bitrateangabe des NSV Streams f�r YP";
$language_message["582"]	=		"DJ Tools";
$language_message["583"]	=		"tools f&uuml;r webradios";
$language_message["584"]	=		"Serverkick und Playlist";
$language_message["585"]	=		"WebPlayer und externe Links";
$language_message["586"]	=		"Radioserver Statistiken";
$language_message["587"]	=		"API Web-Steuerungsinterface";
//
//
//	changes
$language_message["588_1"]	=		"Sehr geehrter Administrator,\nUser ";
$language_message["588_2"]	=		" hat Ihnen �ber das Streamers Admin Panel im Benutzernachrichten Service Center eine Nachricht zukommen lassen.\n\nDer Betreff dieser Nachricht: ";
$language_message["588_3"]	=		"\n\nUm diese Nachricht jetzt aufrufen zu k�nnen, loggen Sie sich bitte unter der folgenden Adresse in Ihr Streamers Admin Panel ein:\nLink zu Ihrem Panel: ";
$language_message["588_4"]	=		"\n\nIhr Streamers Admin Panel";
*/
?>