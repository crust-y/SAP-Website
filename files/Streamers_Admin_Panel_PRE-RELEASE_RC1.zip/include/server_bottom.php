<?PHP
//	Streamers Admin Panel 3.2
//
//	Developer:
//	Main Coding: djcrackhome [Sebastian Graebner]
//	Thanks 2 Raimund Barendt, resh [Mathias Simon], hansy [Rico Reinheckel], Largo [Michael Savino] 
//
//	License:
//	Creative Commons Attribution-ShareAlike 3.0 Unported License
//		This work is licensed under the Creative Commons Attribution-ShareAlike 3.0 Unported License.
//		To view a copy of this license, visit http://creativecommons.org/licenses/by-sa/3.0/ or
//		send a letter to Creative Commons, 171 Second Street, Suite 300, San Francisco, California, 94105, USA.
//
//	URL:		http://www.streamerspanel.com
//	SUPPORT:	http://support.streamerspanel.com
//	MAIL:		info@streamerspanel.com
///////////////////////////////////////////////
//
//	FILENAME: ./include/server_bottom.php
//

error_reporting(0);
if ((!defined("_include_security")) || (!preg_match("/content.php/i", $_SERVER['PHP_SELF']))) {
    header('Location: ./../index.php?system_login='.md5(md5("access").date("H:i").$_SERVER['REMOTE_ADDR']));
	die();
}
$internal_listing_limit = mysql_real_escape_string(trim($internal_setting['system_limit']));
if (!isset($_GET['listing_query'])) $listing_query = 0;
else $listing_query = $_GET['listing_query'] * $internal_listing_limit;
$listing_query_limitery = $listing_query + $internal_listing_limit;
$listing_sql_query = mysql_query("SELECT * FROM internal_system_db_servers WHERE owner='".$internal_user_name."' ORDER BY id ASC LIMIT $listing_query,$internal_listing_limit");
if ($_GET['system_action']!="update") {
?>
<div id="content">
	<div class="box">
		<h2><?php echo $language_message["433"];?></h2>
			<div class="contact_top_menu">
				<div class="tool_top_menu">
					<div class="main_shorttool"><?php echo $language_message["434"];?></div>
					<div class="main_righttool">
						<h2><?php echo $language_message["435"];?></h2>
						<p><?php echo $language_message["436"];?></p>
						<p>&nbsp;</p>
					</div>
				</div>
				<table cellspacing="0" cellpadding="0">
					<thead>
						<tr>
							<th><?php echo $language_message["437"];?></th>
							<th><?php echo $language_message["438"];?></th>
							<th><?php echo $language_message["439"];?></th>
							<th>&nbsp;</th>
						</tr>
					</thead>
					<tbody>
						<?php
						if (mysql_num_rows($listing_sql_query)==0) {
							echo "<tr>
								<td colspan=\"5\">".$language_message["440"]."</td>
								</tr>";
						}
						else {
							while($listing_sql_query_data = mysql_fetch_array($listing_sql_query)) {
								echo '<tr>
									<td><a href="http://'.$internal_setting['system_host'].':'.$listing_sql_query_data['portbase'].'/" target="_blank">'.$internal_setting['system_host'].'</a></td>
									<td><a href="http://'.$internal_setting['system_host'].':'.$listing_sql_query_data['portbase'].'/" target="_blank">'.$listing_sql_query_data['portbase'].'</a></td>
									<td><div class="space_show" style="background-position:';
								$negative_background_pos = ((internal_folder_space($internal_setting['system_dir']."/clients/".$internal_user_id."/".$listing_sql_query_data['portbase']."/uploads/audio/")+internal_folder_space($internal_setting['system_dir']."/clients/".$internal_user_id."/".$listing_sql_query_data['portbase']."/uploads/video/"))/$listing_sql_query_data['webspace'])*120;
								echo '-'.$negative_background_pos.'px 0px;"></div></td>
									<td><a class="delete" href="content.php?include=server&edit='.$listing_sql_query_data["id"].'&system_action=stop">'.$language_message["441"].'</a><a class="selector" href="content.php?include=server&edit='.$listing_sql_query_data["id"].'&system_action=start">'.$language_message["442"].'</a><a class="edit" href="content.php?include=server&edit='.$listing_sql_query_data["id"].'&system_action=update">'.$language_message["443"].'</a></td>
									</tr>';
							}
						}
						?>
					</tbody>
				</table>	
					<?php
					if (mysql_num_rows($listing_sql_query)!=0) {
						echo "<ul class=\"paginator\">";
					$listing_limit_page = mysql_num_rows(mysql_query("SELECT * FROM internal_system_db_servers WHERE owner='".mysql_real_escape_string($internal_user_name)."'"));
					$i = 0;
					while($listing_limit_page > "0") {
						echo "<li><a href=\"content.php?include=server&listing_query=";
						if (($listing_query / $internal_listing_limit) == $i){
							echo "";
						}
						echo "$i\">$i</a></li>";
						$i++;
						$listing_limit_page -= $internal_listing_limit;
						}
						echo "</ul>";
					}
					?>
			</div>
		</div> 
	</div>

<?php 
}
else {
?>
<div id="content">
	<div class="box">
		<h2><?php
		echo $language_message["444"];
		$internal_port_query = mysql_fetch_object(mysql_query("SELECT portbase FROM internal_system_db_servers WHERE owner='".mysql_real_escape_string($internal_user_name)."' AND id='".mysql_real_escape_string($_GET['edit'])."'"));
		echo $internal_port_query->portbase;
		?></h2>
		<div class="contact_top_menu">
			<div class="tool_top_menu">
				<div class="main_shorttool"><?php echo $language_message["445"];?></div>
				<div class="main_righttool">
					<h2><?php echo $language_message["446"];?></h2>
					<p><?php echo $language_message["447"];?></p>
				</div>
			</div>
		<form method="post" action="content.php?include=server&edit=<?php echo htmlspecialchars($_GET['edit']);?>&system_action=update">
			<?php 
			while($updateget_var = mysql_fetch_array($internal_data_update)) { $updateget_var_t_owner = $updateget_var['owner']; $updateget_var_t_adminpassword = $updateget_var['adminpassword']; $updateget_var_t_password = $updateget_var['password']; $updateget_var_t_portbase = $updateget_var['portbase']; $updateget_var_t_maxuser = $updateget_var['maxuser']; $updateget_var_t_bitrate = $updateget_var['bitrate']; $updateget_var_t_autopid = $updateget_var['autopid']; $updateget_var_t_logfile = $updateget_var['logfile']; $updateget_var_t_screenlog = $updateget_var['screenlog']; $updateget_var_t_realtime = $updateget_var['realtime']; $updateget_var_t_showlastsongs = $updateget_var['showlastsongs']; $updateget_var_t_tchlog = $updateget_var['tchlog']; $updateget_var_t_weblog = $updateget_var['weblog']; $updateget_var_t_webspace = $updateget_var['webspace']; $updateget_var_t_w3clog = $updateget_var['w3clog']; $updateget_var_t_w3cenable = $updateget_var['w3cenable']; $updateget_var_t_srcip = $updateget_var['srcip']; $updateget_var_t_destip = $updateget_var['destip']; $updateget_var_t_yport = $updateget_var['yport']; $updateget_var_t_relayport = $updateget_var['relayport']; $updateget_var_t_namelookups = $updateget_var['namelookups']; $updateget_var_t_relayserver = $updateget_var['relayserver']; $updateget_var_t_autodumpusers = $updateget_var['autodumpusers']; $updateget_var_t_autodumpsourcetime = $updateget_var['autodumpsourcetime']; $updateget_var_t_contentdir = $updateget_var['contentdir']; $updateget_var_t_introfile = $updateget_var['introfile']; $updateget_var_t_backupfile = $updateget_var['backupfile']; $updateget_var_t_titleformat = $updateget_var['titleformat']; $updateget_var_t_publicserver = $updateget_var['publicserver']; $updateget_var_t_metainterval = $updateget_var['metainterval']; $updateget_var_t_allowrelay = $updateget_var['allowrelay']; $updateget_var_t_allowpublicrelay = $updateget_var['allowpublicrelay'];
				}
				$internal_id_owner = mysql_query("SELECT id FROM internal_system_db_users WHERE username='".mysql_real_escape_string($internal_user_name)."'");
				?>
				<fieldset>
					<legend><?php echo $language_message["99"];?></legend>
					<div class="input_field">
						<label for="a">Server Inhaber</label>
						<input class="mediumfield" name="owner" type="text" disabled="disabled" value="<?php echo htmlspecialchars($updateget_var_t_owner); ?>" />           
						<span class="field_desc">Bitte geben Sie den Inhaber an</span>
					</div>
					<div class="input_field">
						<label for="a">Admin Passwort</label>
						<input class="mediumfield" name="adminpassword" type="text" value="<?php echo htmlspecialchars($updateget_var_t_adminpassword); ?>" />
					<span class="field_desc">Admin Passwort zum Radioserver</span>
				</div>
				<div class="input_field">
					<label for="a">DJ Passwort</label>
					<input class="mediumfield" name="password" type="text" value="<?php echo htmlspecialchars($updateget_var_t_password); ?>" />
					<span class="field_desc">DJ Passwort zum Radioserver</span>
				</div>
				<div class="input_field">
			    <label for="a">Radioserver Port</label>
					<input class="mediumfield" name="portbase" type="text" disabled="disabled" value="<?php echo htmlspecialchars($updateget_var_t_portbase); ?>" />
					<span class="field_desc">Port-Angabe des Radio Servers</span>
				</div>
				<div class="input_field">
					<label for="a">Max Zuh&ouml;hrer</label>
					<input class="mediumfield" name="maxuser" type="text" disabled="disabled" value="<?php echo htmlspecialchars($updateget_var_t_maxuser); ?>" />
					<span class="field_desc">Max. Zuh&ouml;hreranzahl des Servers</span>
				</div>
				<div class="input_field">
					<label for="a">Stream Bitrate</label>
                    <select class="formselect_loca" name="bitrate" disabled="disabled">
                        <option value="320000"<?php if ($updateget_var_t_bitrate=="320000") echo " selected=\"selected\"";?>>320 kbps</option>
                        <option value="256000"<?php if ($updateget_var_t_bitrate=="256000") echo " selected=\"selected\"";?>>256 kbps</option>
                        <option value="224000"<?php if ($updateget_var_t_bitrate=="224000") echo " selected=\"selected\"";?>>224 kbps</option>
                        <option value="192000"<?php if ($updateget_var_t_bitrate=="192000") echo " selected=\"selected\"";?>>192 kbps</option>
                        <option value="160000"<?php if ($updateget_var_t_bitrate=="160000") echo " selected=\"selected\"";?>>160 kbps</option>
                        <option value="128000"<?php if ($updateget_var_t_bitrate=="128000") echo " selected=\"selected\"";?>>128 kbps</option>
                        <option value="112000"<?php if ($updateget_var_t_bitrate=="112000") echo " selected=\"selected\"";?>>112 kbps</option>
                        <option value="96000"<?php if ($updateget_var_t_bitrate=="96000") echo " selected=\"selected\"";?>>96 kbps</option>
                        <option value="80000"<?php if ($updateget_var_t_bitrate=="80000") echo " selected=\"selected\"";?>>80 kbps</option>
                        <option value="64000"<?php if ($updateget_var_t_bitrate=="64000") echo " selected=\"selected\"";?>>64 kbps</option>
                        <option value="56000"<?php if ($updateget_var_t_bitrate=="56000") echo " selected=\"selected\"";?>>56 kbps</option>
                        <option value="48000"<?php if ($updateget_var_t_bitrate=="48000") echo " selected=\"selected\"";?>>48 kbps</option>
                        <option value="40000"<?php if ($updateget_var_t_bitrate=="40000") echo " selected=\"selected\"";?>>40 kbps</option>
                        <option value="32000"<?php if ($updateget_var_t_bitrate=="32000") echo " selected=\"selected\"";?>>32 kbps</option>
                    </select>
					<span class="field_desc">Erlaubte Streambitrate des Servers</span>
				</div>
				<div class="input_field">
					<label for="a">AutoDJ Status</label>
					<?php echo '<select name="autopid" class="formselect_loca" disabled="disabled"><option'; if ($updateget_var_t_autopid != "9999999") { echo ' selected="selected" value="'.htmlspecialchars($updateget_var_t_autopid).'"'; } echo '>'.$language_message["115"].'</option><option value="9999999"'; if ($updateget_var_t_autopid == "9999999") { echo ' selected="selected"';} echo '>'.$language_message["116"].'</option></select>';
					?>
					<span class="field_desc">Audio-/ Video DJ f&uuml;r Radioserver</span>
				</div>
				<div class="input_field" id="autodj_setup_id_1"<?php if ($updateget_var_t_autopid == "9999999") echo " style=\"display:none;\""; ?>>
					<label for="a">Max Webspace</label>
					<input class="mediumfield" name="webspace" type="text" disabled="disabled" value="<?php echo (htmlspecialchars($updateget_var_t_webspace)/1024); ?>" />
					<span class="field_desc">Max Webspace des Servers (MB)</span>
				</div>
				<div class="input_field" id="view_setting_show_logfile">
			    <label for="a">Server Logfile</label>
					<select class="formselect_loca" name="logfile" onchange="log_setup(value);"><option value="<?php if (preg_match("/clients/i", $updateget_var_t_logfile)) { echo htmlspecialchars($updateget_var_t_logfile)."\" selected=\"selected"; } else { echo $internal_setting['system_dir']."clients/".mysql_result($internal_id_owner,0)."/".htmlspecialchars($updateget_var_t_portbase)."/logs/sc_log.log"; }?>"><?php $updateget_var_t_logfile=preg_replace("#".$internal_setting['system_dir']."#","./", $updateget_var_t_logfile); if (preg_match("/clients/i", $updateget_var_t_logfile)) { echo htmlspecialchars($updateget_var_t_logfile); } else { echo "./clients/".mysql_result($internal_id_owner,0)."/".htmlspecialchars($updateget_var_t_portbase)."/logs/sc_log.log"; } ?></option><option value="/dev/null"<?php if (!preg_match("/clients/i", $updateget_var_t_logfile)) { echo " selected=\"selected\""; } ?>><?php echo $language_message["579"];?></option></select>
					<span class="field_desc">Speichert alle Serveraktivit&auml;ten</span>
				</div>
				<div class="input_field" id="log_setup_id_1"<?php if ($updateget_var_t_logfile=="/dev/null") echo " style=\"display:none;\""; ?>>
					<label for="a">Realtime - [Log]</label>
                    <select class="formselect_loca" name="realtime"><option value="1"<?php if ($updateget_var_t_realtime=="1") { echo " selected=\"selected\""; } ?>><?php echo $language_message["566"];?></option><option value="0"<?php if ($updateget_var_t_realtime=="0") { echo " selected=\"selected\""; } ?>><?php echo $language_message["567"];?></option></select>
					<span class="field_desc">Status wird sek&uuml;ndlich aktualisiert</span>
				</div>
				<div class="input_field" id="log_setup_id_2"<?php if ($updateget_var_t_logfile=="/dev/null") echo " style=\"display:none;\""; ?>>
					<label for="a">TCHLog - [Log]</label>
                    <select class="formselect_loca" name="tchlog"><option value="Yes"<?php if ($updateget_var_t_tchlog=="Yes") { echo " selected=\"selected\""; } ?>><?php echo $language_message["566"];?></option><option value="No"<?php if ($updateget_var_t_tchlog=="No") { echo " selected=\"selected\""; } ?>><?php echo $language_message["567"];?></option></select>
					<span class="field_desc">YP Aktivi. wird in Logfile geloggt</span>
				</div> 
				<div class="input_field" id="log_setup_id_3"<?php if ($updateget_var_t_logfile=="/dev/null") echo " style=\"display:none;\""; ?>>
					<label for="a">Weblog - [Log]</label>
                    <select class="formselect_loca" name="weblog"><option value="Yes"<?php if ($updateget_var_t_weblog=="Yes") { echo " selected=\"selected\""; } ?>><?php echo $language_message["566"];?></option><option value="No"<?php if ($updateget_var_t_weblog=="No") { echo " selected=\"selected\""; } ?>><?php echo $language_message["567"];?></option></select>
					<span class="field_desc">Webaktivit&auml;ten werden geloggt </span>
				</div>
				<div class="input_field" id="log_setup_id_4"<?php if ($updateget_var_t_logfile=="/dev/null") echo " style=\"display:none;\""; ?>>
					<label for="a">Screenlog - [Log]</label>
                    <select class="formselect_loca" name="screenlog"><option value="1"<?php if ($updateget_var_t_screenlog=="1") { echo " selected=\"selected\""; } ?>><?php echo $language_message["566"];?></option><option value="0"<?php if ($updateget_var_t_screenlog=="0") { echo " selected=\"selected\""; } ?>><?php echo $language_message["567"];?></option></select>
					<span class="field_desc">Log wird in Console ausgegeben</span>
				</div>
				<div class="input_field" id="w3c_enable">
					<label for="a">W3C Enable</label>
                    <select class="formselect_loca" name="w3cenable" onchange="w3c_enable(value);"><option value="Yes"<?php if ($updateget_var_t_w3cenable=="Yes") { echo " selected=\"selected\""; } ?>>W3C Eingeschaltet</option><option value="No"<?php if ($updateget_var_t_w3cenable=="No") { echo " selected=\"selected\""; } ?>>W3C Ausgeschaltet</option></select>
					<span class="field_desc">Log wird in Console ausgegeben</span>
				</div>
				<div class="input_field" id="view_setting_show_w3c"<?php if ($updateget_var_t_w3cenable=="No") echo " style=\"display:none;\""; ?>>
					<label for="a">W3C Logfile</label>
                    <select class="formselect_loca" name="w3clog"><option value="<?php if (preg_match("/clients/i", $updateget_var_t_w3clog)) { echo htmlspecialchars($updateget_var_t_w3clog)."\" selected=\"selected"; } else { echo $internal_setting['system_dir']."clients/".mysql_result($internal_id_owner,0)."/".htmlspecialchars($updateget_var_t_portbase)."/logs/w3c_log.log"; }?>"><?php $updateget_var_t_w3clog=preg_replace("#".$internal_setting['system_dir']."#","./",$updateget_var_t_w3clog); if (preg_match("/clients/i", $updateget_var_t_w3clog)) echo htmlspecialchars($updateget_var_t_w3clog); else echo "./clients/".mysql_result($internal_id_owner,0)."/".htmlspecialchars($updateget_var_t_portbase)."/logs/w3c_log.log"; ?></option><option value="/dev/null"<?php if (!preg_match("/clients/i", $updateget_var_t_w3clog)) { echo " selected=\"selected\""; } ?>><?php echo $language_message["579"];?></option></select>
					<span class="field_desc">Webaktivit&auml;ten werden geloggt</span>
				</div>
				<div class="input_field" id="view_setting_show_lastsongs">
			    <label for="a">Titel Auflistung</label>
					<input class="mediumfield" name="showlastsongs" type="text" value="<?php echo htmlspecialchars($updateget_var_t_showlastsongs); ?>" />
					<span class="field_desc">Tracklimitierung f&uuml;r 'played'-Listing</span>
				</div>
				<div class="input_field" id="view_setting_show_src">
					<label for="a">Source IP</label>
					<input class="mediumfield" name="srcip" type="text" value="<?php echo htmlspecialchars($updateget_var_t_srcip); ?>" />
					<span class="field_desc">Quell (Source) IP des Radiostreams</span>
				</div>            
				<div class="input_field" id="view_setting_show_dest">
					<label for="a">Destination IP</label>
					<input class="mediumfield" name="destip" type="text" value="<?php echo htmlspecialchars($updateget_var_t_destip); ?>" />
					<span class="field_desc">Ziel (Destination) IP des R.-Streams</span>
				</div>
               	<div class="input_field" id="view_setting_show_yport">
					<label for="a">YP Port</label>
					<input class="mediumfield" name="yport" type="text" value="<?php echo htmlspecialchars($updateget_var_t_yport); ?>" />
					<span class="field_desc">Erreichbarkeitsport von YP</span>
				</div>
				<div class="input_field" id="view_setting_show_name">
					<label for="a">Name Lookups</label>
                    <select class="formselect_loca" name="namelookups"><option value="1"<?php if ($updateget_var_t_namelookups=="1") { echo " selected=\"selected\""; } ?>><?php echo $language_message["566"];?></option><option value="0"<?php if ($updateget_var_t_namelookups=="0") { echo " selected=\"selected\""; } ?>><?php echo $language_message["567"];?></option></select>
					<span class="field_desc">DNS Erkennung der Quell IP's</span>
				</div>                       
				<div class="input_field" id="view_setting_show_autodump">
					<label for="a">Auto Dump Users</label>
                    <select class="formselect_loca" name="autodumpusers" onchange="setting_show_autodumpsrc(value);"><option value="1"<?php if ($updateget_var_t_namelookups=="1") { echo " selected=\"selected\""; } ?>><?php echo $language_message["566"];?></option><option value="0"<?php if ($updateget_var_t_namelookups=="0") { echo " selected=\"selected\""; } ?>><?php echo $language_message["567"];?></option></select>
					<span class="field_desc">Listener Kick bei DJ-Trennung</span>
				</div>  
				<div class="input_field" id="view_setting_show_autodumpsrc"<?php if ($updateget_var_t_namelookups=="0") echo " style=\"display:none;\""; ?>>
					<label for="a">Auto Dump Time</label>
					<input class="mediumfield" name="autodumpsourcetime" type="text" value="<?php echo htmlspecialchars($updateget_var_t_autodumpsourcetime); ?>" />
					<span class="field_desc">Sekundenangabe f&uuml;r Listenerkick</span>
				</div>  
				<div class="input_field" id="shout_server_setup_id_21">
					<label for="a">Content Directory</label>
                    <select class="formselect_loca" name="contentdir"><option value="<?php if (preg_match("/clients/i", $updateget_var_t_contentdir)) { echo htmlspecialchars($updateget_var_t_contentdir)."\" selected=\"selected"; } else { echo $internal_setting['system_dir']."clients/".mysql_result($internal_id_owner,0)."/".htmlspecialchars($updateget_var_t_portbase)."/contentdir/"; } ?>"><?php $updateget_var_t_contentdir=preg_replace("#".$internal_setting['system_dir']."#","./", $updateget_var_t_contentdir); if (preg_match("/clients/i", $updateget_var_t_contentdir)) { echo htmlspecialchars($updateget_var_t_contentdir); } else { echo "./clients/".mysql_result($internal_id_owner,0)."/".htmlspecialchars($updateget_var_t_portbase)."/contentdir/"; } ?></option><option value="/dev/null"<?php if (!preg_match("/clients/i", $updateget_var_t_contentdir)) { echo " selected=\"selected\""; } ?>>Kein Contentdir Verzeichnis</option></select>
					<span class="field_desc">Verzeichnis f&uuml;r abrufbaren Inhalt</span>
				</div>      
				<div class="input_field" id="view_setting_show_intro">
					<label for="a">Intro Datei</label>
                    <select class="formselect_loca" name="introfile"><option value=""><?php echo $language_message["576"];?></option><option value="<?php if (preg_match("/clients/i", $updateget_var_t_introfile)) { echo htmlspecialchars($updateget_var_t_introfile)."\" selected=\"selected"; } else { echo $internal_setting['system_dir']."clients/".mysql_result($internal_id_owner,0)."/".htmlspecialchars($updateget_var_t_portbase)."/soundfiles/intro.mp3"; } ?>"><?php $updateget_var_t_introfile=preg_replace("#".$internal_setting['system_dir']."#","./", $updateget_var_t_introfile); if (preg_match("/clients/i", $updateget_var_t_introfile)) { echo $updateget_var_t_introfile; } else { echo "./clients/".mysql_result($internal_id_owner,0)."/".htmlspecialchars($updateget_var_t_portbase)."/soundfiles/intro.mp3"; } ?></option></select>
					<span class="field_desc">Verzeichnisangabe - Intro Datei</span>
				</div>  
				<div class="input_field" id="view_setting_show_backup">
					<label for="a">Backup Datei</label>
                    <select class="formselect_loca" name="backupfile"><option value="">Keine Backup Datei</option><option value="<?php if (preg_match("/clients/i", $updateget_var_t_backupfile)) { echo htmlspecialchars($updateget_var_t_backupfile)."\" selected=\"selected"; } else { echo $internal_setting['system_dir']."clients/".mysql_result($internal_id_owner,0)."/".htmlspecialchars($updateget_var_t_portbase)."/soundfiles/backup.mp3"; } ?>"><?php $updateget_var_t_backupfile=preg_replace("#".$internal_setting['system_dir']."#","./", $updateget_var_t_backupfile); if (preg_match("/clients/i", $updateget_var_t_backupfile)) { echo $updateget_var_t_backupfile; } else { echo "./clients/".mysql_result($internal_id_owner,0)."/".htmlspecialchars($updateget_var_t_portbase)."/soundfiles/backup.mp3"; } ?></option></select>
					<span class="field_desc">Verzeichnisangabe - Backup Datei</span>
				</div>  
				<div class="input_field">
					<label for="a">Titel Format</label>
					<input class="mediumfield" name="titleformat" type="text" value="<?php echo htmlspecialchars($updateget_var_t_titleformat); ?>" />
					<span class="field_desc">Streamtitel Format Vorlage</span>
				</div>  
				<div class="input_field">
					<label for="a">&Ouml;ffentlicher Server</label>
                    <select class="formselect_loca" name="publicserver"><option value="always"<?php if ($updateget_var_t_publicserver=="always") { echo ' selected="selected"'; } ?>>Radioserver wird in die YP gelistet</option><option value="never"<?php if ($updateget_var_t_publicserver=="never") { echo ' selected="selected"'; } ?>>Radioserver wird nicht in die YP gelistet </option></select>
					<span class="field_desc">Server bei SHOUTcast listen</span>
				</div>
				<div class="input_field" id="yp_shoutcast_setup_id_9">
			    <label for="a">Relay Server</label>
					<input class="mediumfield" name="relayserver" type="text" value="<?php echo htmlspecialchars($updateget_var_t_relayserver);?>" />
					<span class="field_desc">Adresse zum Relayservers</span>
				</div>  
				<div class="input_field" id="yp_shoutcast_setup_id_8">
					<label for="a">Relay Port</label>
					<input class="mediumfield" name="relayport" type="text" value="<?php echo htmlspecialchars($updateget_var_t_relayport);?>" />
					<span class="field_desc">Port zum Relayservers</span>
				</div>   
				<div class="input_field" id="view_setting_show_allowpublic">
					<label for="a">Public Relay</label>
                    <select class="formselect_loca" name="allowpublicrelay"><option value="Yes"<?php if ($updateget_var_t_allowpublicrelay=="Yes") { echo " selected=\"selected\""; } ?>><?php echo $language_message["566"];?></option><option value="No"<?php if ($updateget_var_t_allowpublicrelay=="No") { echo " selected=\"selected\""; } ?>><?php echo $language_message["567"];?></option></select>
					<span class="field_desc">Server bei YP als Public Relay</span>
				</div> 
				<div class="input_field" id="view_setting_show_metainterval">
					<label for="a">Meta Interval</label>
					<input class="mediumfield" name="metainterval" type="text" value="<?php echo htmlspecialchars($updateget_var_t_metainterval); ?>" />
					<span class="field_desc">Wert beibehalten</span>
				</div>
				<input class="submit" type="submit" name="submit" value="<?php echo $language_message["168"];?>" />
				<input class="submit" type="reset" value="<?php echo $language_message["450"];?>" onclick="document.location='content.php?include=server';" />
				</fieldset>
			</form>
		</div>
	</div>
</div>
<?php 
}?>