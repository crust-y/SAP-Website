<?PHP
//	Streamers Admin Panel 3.2
//
//	Developer:
//	Main Coding: djcrackhome [Sebastian Graebner]
//	Thanks 2 Raimund Barendt, resh [Mathias Simon], hansy [Rico Reinheckel], Largo [Michael Savino] 
//
//	License:
//	Creative Commons Attribution-ShareAlike 3.0 Unported License
//		This work is licensed under the Creative Commons Attribution-ShareAlike 3.0 Unported License.
//		To view a copy of this license, visit http://creativecommons.org/licenses/by-sa/3.0/ or
//		send a letter to Creative Commons, 171 Second Street, Suite 300, San Francisco, California, 94105, USA.
//
//	URL:		http://www.streamerspanel.com
//	SUPPORT:	http://support.streamerspanel.com
//	MAIL:		info@streamerspanel.com
///////////////////////////////////////////////
//
//	FILENAME: ./include/system_function.php
//

error_reporting(0);
if ((!defined("_include_security")) || (!preg_match("/content.php/i", $_SERVER['PHP_SELF']))) {
    header('Location: ./../index.php?system_login='.md5(md5("access").date("H:i").$_SERVER['REMOTE_ADDR']));
	die();
}
$internal_setting_query = mysql_query("SELECT * FROM internal_system_db_mainsetting WHERE id='0'") or die($language_message["g5"]);
foreach(mysql_fetch_array($internal_setting_query) as $internal_setting_query_key => $internal_setting_query_preference) {
	if (!is_numeric($internal_setting_query_key)) {
		$internal_setting[$internal_setting_query_key] = stripslashes($internal_setting_query_preference);
	}
}
$internal_function_server_host = $internal_setting["system_host"];
$internal_function_server_dir = $internal_setting["system_dir"];
$internal_function_system_connection_type = $internal_setting["system_connection_type"];
$internal_function_ssh2_username=$internal_setting["system_ssh_user"];
$internal_function_ssh2_password=$internal_setting["system_ssh_pass"];
$internal_function_ssh2_port=$internal_setting["system_ssh_port"];
function internal_function_shoutcast_start($internal_function_server_id, $internal_function_server_owner){
	global $internal_function_server_host;
	global $internal_function_server_dir;
	global $internal_function_system_connection_type;
	global $internal_function_ssh2_username;
	global $internal_function_ssh2_password;
	global $internal_function_ssh2_port;
	$internal_function_server_start_query = mysql_query("SELECT portbase FROM internal_system_db_servers WHERE id='".mysql_real_escape_string(strip_tags($internal_function_server_id))."' AND owner='".mysql_real_escape_string(strip_tags($internal_function_server_owner))."'");
	if (@fsockopen($internal_function_server_host, mysql_result($internal_function_server_start_query,0), &$errno, &$errstr, 1)) {
		return "xfssx001-SERVER_NOT_OFFLINE";
	}
	else {
		if (mysql_num_rows($internal_function_server_start_query)==0) {
			return "xfssx002-NO_SERVER_REGISTERED_OR_NOT_THE_OWNER";
		}
		else {
			$internal_function_server_start_data = mysql_query("SELECT * FROM internal_system_db_servers WHERE id='".mysql_real_escape_string(strip_tags($internal_function_server_id))."' AND portbase='".mysql_real_escape_string(strip_tags(mysql_result($internal_function_server_start_query,0)))."'");
			$internal_function_server_owner_id = mysql_query("SELECT id FROM internal_system_db_users WHERE username='".mysql_real_escape_string(strip_tags($internal_function_server_owner))."'");
			$internal_function_server_start_config_cont = "";
			foreach(mysql_fetch_array($internal_function_server_start_data) as $field => $value) {
				if (!is_numeric($field) && $value !="" && $field != "id" && $field != "owner" && $field != "pid" && $field != "apivalue" && $field != "autopid" && $field != "webspace" && $field != "serverip" && $field != "serverport" && $field != "streamtitle" && $field != "streamurl" && $field != "shuffle" && $field != "samplerate" && $field != "channels" && $field != "genre" && $field != "quality" && $field != "crossfademode" && $field != "crossfadelength" && $field != "useid3" && $field != "public" && $field != "aim" && $field != "icq" && $field != "irc") {
					$internal_function_server_start_config_cont .= $field."=".$value."\n";
				}
			}
			$internal_function_server_start_filename = "clients/".mysql_result($internal_function_server_owner_id,0)."/".mysql_result($internal_function_server_start_query,0)."/configs/sc_serv_".time().".conf";
			if (!$internal_function_server_start_filename_handler = fopen($internal_function_server_start_filename, "a")) {
				return "xfssx003-TEMP_CONFIG_COULD_NOT_BE_CREATED";
			fclose($internal_function_server_start_filename_handler);
			}
			elseif (fwrite($internal_function_server_start_filename_handler, $internal_function_server_start_config_cont) === FALSE) {
				return "xfssx004-TEMP_CONFIG_COULD_NOT_BE_WRITTEN";
			fclose($internal_function_server_start_filename_handler);
			}
			else {
				if ((!file_exists(''.$internal_function_server_dir.'system/require/sc_serv_1_98')) || ((substr(sprintf('%o', fileperms(''.$internal_function_server_dir.'system/require/sc_serv_1_98')), -4)!="0777") && (substr(sprintf('%o', fileperms(''.$internal_function_server_dir.'system/require/sc_serv_1_98')), -4)!="0755"))) {
					echo '<xml>'; 
					echo '	<status>';
					echo '		<code>xfssx004</code>';
					echo '		<message>FATAL_SERVER_START__FILE_NOT_EXIST_OR_WRONG_CHMOD</message>';
					echo '	</status>'; 
					echo '</xml>';
					die();
				}
				if ($internal_function_system_connection_type=="ssh2") {
					$internal_function_server_ssh2_connect = ssh2_connect("localhost", $internal_function_ssh2_port);
					ssh2_auth_password($internal_function_server_ssh2_connect, ''.base64_decode($internal_function_ssh2_username).'', ''.base64_decode($internal_function_ssh2_password).'');
					$internal_function_server_ssh2_exec = ssh2_exec($internal_function_server_ssh2_connect, 'sudo -u '.base64_decode($internal_function_ssh2_username).' '.$internal_function_server_dir.'system/require/sc_serv_1_98 '.$internal_function_server_dir.$internal_function_server_start_filename.' </dev/null 2>/dev/null >/dev/null & echo $!');
					sleep(4);
					$internal_function_server_start_pid = stream_get_contents($internal_function_server_ssh2_exec);		
				}
				elseif ($internal_function_system_connection_type=="bash") {
					$internal_function_server_start_pid = shell_exec("nohup ".$internal_function_server_dir."system/system.sh shoutcast ver1 start ".$internal_function_server_dir." ".$internal_function_server_dir.$internal_function_server_start_filename."");
					sleep(4);
					$internal_function_server_start_pid = substr($internal_function_server_start_pid, 6, -1);
				}
				else {
					echo '<xml>'; 
					echo '	<status>';
					echo '		<code>xfssx005</code>';
					echo '		<message>FATAL_SERVER_START_CRASH</message>';
					echo '	</status>'; 
					echo '</xml>';
					die();
				}
				if (!$internal_function_server_start_pid || $internal_function_server_start_pid == "") {
					mysql_query("INSERT INTO internal_system_db_notices (username,reason,message,ip) VALUES('System Startup','Server Start Fatal Error','Server with ID ".$internal_function_server_id." could not be started on Port ".$internal_function_server_start_data['portbase']."','".$_SERVER['REMOTE_ADDR']."')");
					return "xfssx006-SERVER_COULD_NOT_BE_STARTED";
				}
				else {
					mysql_query("UPDATE internal_system_db_servers SET pid='".$internal_function_server_start_pid."' WHERE id='".mysql_real_escape_string(strip_tags($internal_function_server_id))."' AND owner='".mysql_real_escape_string(strip_tags($internal_function_server_owner))."'");
					if ($internal_setting["system_scs_config"]=="0") {
						unlink($internal_function_server_start_filename);
					}
					return "yfssx001-SERVER_WAS_SUCCESSFULLY_STARTED";
				}
			}
		}
	}
}
function internal_function_shoutcast_stop($internal_function_server_id, $internal_function_server_owner){
	global $internal_function_server_host;
	global $internal_function_server_dir;
	global $internal_function_system_connection_type;
	global $internal_function_ssh2_username;
	global $internal_function_ssh2_password;
	global $internal_function_ssh2_port;
	$internal_function_server_stop_query = mysql_query("SELECT portbase FROM internal_system_db_servers WHERE id='".mysql_real_escape_string(strip_tags($internal_function_server_id))."' AND owner='".mysql_real_escape_string(strip_tags($internal_function_server_owner))."'");
	if (!@fsockopen("".$internal_function_server_host."", mysql_result($internal_function_server_stop_query,0), $errno, $errstr, 1)) {
		return "xfstx001";
	}
	else{
		$internal_function_server_stop_pid = mysql_query("SELECT pid FROM internal_system_db_servers WHERE id='".$internal_function_server_id."' AND owner='".mysql_real_escape_string(strip_tags($internal_function_server_owner))."'");
		if ((mysql_result($internal_function_server_stop_pid,0)=="") || (mysql_result($internal_function_server_stop_pid,0)==NULL)) {
			return "xfstx002";
		}
		else {
			if ($internal_function_system_connection_type=="ssh2") {
				$internal_function_server_ssh2_connect = ssh2_connect("localhost", $internal_function_ssh2_port);
				ssh2_auth_password($internal_function_server_ssh2_connect, ''.base64_decode($internal_function_ssh2_username).'', ''.base64_decode($internal_function_ssh2_password).'');
				$internal_function_server_ssh2_exec = ssh2_exec($internal_function_server_ssh2_connect, 'kill '.mysql_result($internal_function_server_stop_pid,0));
				sleep(3);
			}
			elseif ($internal_function_system_connection_type=="bash") {
				$internal_function_server_stop_pid = shell_exec("nohup ".$internal_function_server_dir."system/system.sh shoutcast ver1 stop ".mysql_result($internal_function_server_stop_pid,0)."");
				sleep(3);
			}
			else {
				echo '<xml>'; 
				echo '	<status>';
				echo '		<code>xfstx003</code>';
				echo '		<message>FATAL_SERVER_START_CRASH</message>';
				echo '	</status>'; 
				echo '</xml>';
				die();
			}
			return "yfstx001";
		}	
	}
}
function internal_function_sctrans_start($internal_function_server_id, $internal_function_playlist, $internal_function_server_owner){
	global $internal_function_server_host;
	global $internal_function_server_dir;
	global $internal_function_system_connection_type;
	global $internal_function_ssh2_username;
	global $internal_function_ssh2_password;
	global $internal_function_ssh2_port;
	$internal_function_sctrans_start_query = mysql_query("SELECT portbase FROM internal_system_db_servers WHERE id='".mysql_real_escape_string(trim($internal_function_server_id))."' AND owner='".mysql_real_escape_string(strip_tags($internal_function_server_owner))."'");
	if (mysql_num_rows($internal_function_sctrans_start_query)==0) {
		return "xftsx001";
		die ();
	}
	$internal_function_sctrans_autopid_check = mysql_query("SELECT autopid FROM internal_system_db_servers WHERE id='".mysql_real_escape_string(trim($internal_function_server_id))."' AND owner='".mysql_real_escape_string(strip_tags($internal_function_server_owner))."'");
	if (mysql_num_rows($internal_function_sctrans_autopid_check)==0) {
		return "xftsx002";
		die ();
	}
	if (mysql_result($internal_function_sctrans_autopid_check,0) != "9999999") {
		$internal_function_sctrans_start_connection = @fsockopen($internal_function_server_host, mysql_result($internal_function_sctrans_start_query,0), &$errno, &$errstr, 1);
		$internal_function_strans_owner_id = mysql_query("SELECT id FROM internal_system_db_users WHERE username='".mysql_real_escape_string(strip_tags($internal_function_server_owner))."'");
		if ($internal_function_sctrans_start_connection) {
			fputs($internal_function_sctrans_start_connection, "GET /7.html HTTP/1.0\r\nUser-Agent: XML Getter (Mozilla Compatible)\r\n\r\n");
			while(!feof($internal_function_sctrans_start_connection))
				$page .= fgets($internal_function_sctrans_start_connection, 1000);
			fclose($internal_function_sctrans_start_connection);
			$page = preg_replace("#.*<body>#", "", $page);
			$page = preg_replace("#</body>.*#", "/,/", $page);
			$numbers = explode(",", $page);
		}
		if (($numbers[1] == "1") || (!isset($internal_function_playlist))) {
			if ($numbers[1] == "1") {
				return "xftsx003";
			}
			if (!isset($internal_function_playlist)) {
				return "xftsx004";
			}
		}
		else {
			$internal_function_sctrans_start_data = mysql_query("SELECT * FROM internal_system_db_servers WHERE id='".mysql_real_escape_string(trim($internal_function_server_id))."'");
			$ini_content = "";
			$ini_content .= "playlistfile=".$internal_function_server_dir."clients/".mysql_result($internal_function_strans_owner_id,0)."/".mysql_result($internal_function_sctrans_start_query,0)."/configs/playlists/".strip_tags($internal_function_playlist)."\n";
			foreach(mysql_fetch_array($internal_function_sctrans_start_data) as $field => $value) {
				if (!is_numeric($field) && $field != "id" && $field != "owner" && $field!="maxuser" && $field!="portbase" && $field!="adminpassword" && $field!="sitepublic" && $field!="realtime" && $field!="screenlog" && $field!="showlastsongs" && $field!="tchlog" && $field!="weblog" && $field!="w3cenable" && $field!="w3clog" && $field!="srcip" && $field!="destip" && $field!="yport" && $field!="apivalue" && $field!="backupfile" && $field!="namelookups" && $field!="relayport" && $field!="relayserver" && $field!="autodumpusers" && $field!="autodumpsourcetime" && $field!="contentdir" && $field!="introfile" && $field!="titleformat" && $field!="publicserver" && $field!="allowrelay" && $field!="allowpublicrelay" && $field!="metainterval" && $field!="suspended" && $field!="abuse" && $field!="pid" && $field!="autopid" && $field!="webspace") {
					$ini_content .= $field."=".$value."\n";
				}
			}
			$internal_function_sctrans_start_filename = "clients/".mysql_result($internal_function_strans_owner_id,0)."/".mysql_result($internal_function_sctrans_start_query,0)."/configs/sc_trans_".time().".conf";
			$handle = fopen($internal_function_sctrans_start_filename, "a");
			chmod($internal_function_sctrans_start_filename,0777);
			if (fwrite($handle, $ini_content) === FALSE) {
				return false;
			}
			fclose($handle);
			if ($internal_function_system_connection_type=="ssh2") {
				$internal_function_server_ssh2_connect = ssh2_connect("localhost", $internal_function_ssh2_port);
				ssh2_auth_password($internal_function_server_ssh2_connect, ''.base64_decode($internal_function_ssh2_username).'', ''.base64_decode($internal_function_ssh2_password).'');
				$internal_function_server_ssh2_exec = ssh2_exec($internal_function_server_ssh2_connect, 'sudo -u '.base64_decode($internal_function_ssh2_username).' '.$internal_function_server_dir.'system/require/sc_trans_0_40 '.$internal_function_server_dir.$internal_function_sctrans_start_filename.' </dev/null 2>/dev/null >/dev/null & echo $!');
				sleep(4);
				$internal_function_sctrans_start_pid = stream_get_contents($internal_function_server_ssh2_exec);		
			}
			elseif ($internal_function_system_connection_type=="bash") {
				$internal_function_server_start_pid = shell_exec("nohup ".$internal_function_server_dir."system/system.sh shoutcast trans start ".$internal_function_server_dir." ".$internal_function_server_dir.$internal_function_sctrans_start_filename."");
				sleep(4);
				$internal_function_sctrans_start_pid = substr($internal_function_server_start_pid, 6, -1);
			}
			else {
				echo '<xml>'; 
				echo '	<status>';
				echo '		<code>xfssx005</code>';
				echo '		<message>FATAL_SERVER_START_CRASH</message>';
				echo '	</status>'; 
				echo '</xml>';
				die();
			}
			if (!$internal_function_sctrans_start_pid || $internal_function_sctrans_start_pid == "") {
			mysql_query("INSERT INTO internal_system_db_notices (username,reason,message,ip) VALUES('System Startup','Server failure','The server with id ".$internal_function_server_id." cannot start on port ".$internal_function_sctrans_start_data['portbase']."','".$_SERVER['REMOTE_ADDR']."')");
			echo $internal_function_sctrans_start_pid;
				echo "Could not start server, please contact administration using the contact form on your left";
			}
			$pid = substr($internal_function_sctrans_start_pid, 6, -1);
			mysql_query("UPDATE internal_system_db_servers SET autopid='".$internal_function_sctrans_start_pid."' WHERE id='".$internal_function_server_id."'");
			return "yftsx001";
			if ($internal_setting['system_adj_config']=="0") {
				unlink($internal_function_sctrans_start_filename);
			}
		}
	}
	else return "xftsx005";
}
function internal_function_sctrans_stop ($internal_function_server_id, $internal_function_server_owner){
	global $internal_function_server_host;
	global $internal_function_server_dir;
	global $internal_function_system_connection_type;
	global $internal_function_ssh2_username;
	global $internal_function_ssh2_password;
	global $internal_function_ssh2_port;
	$internal_function_server_stop_query = mysql_query("SELECT portbase FROM internal_system_db_servers WHERE id='".mysql_real_escape_string(strip_tags($internal_function_server_id))."' AND owner='".mysql_real_escape_string(strip_tags($internal_function_server_owner))."'");
	if (!@fsockopen("".$internal_function_server_host."", mysql_result($internal_function_server_stop_query,0), $errno, $errstr, 1)) {
		return "xftsx001";
	}
	else{
		$internal_function_server_stop_pid = mysql_query("SELECT autopid FROM internal_system_db_servers WHERE id='".$internal_function_server_id."' AND owner='".mysql_real_escape_string(strip_tags($internal_function_server_owner))."'");
		if ((mysql_result($internal_function_server_stop_pid,0)=="") || (mysql_result($internal_function_server_stop_pid,0)==NULL)) {
			return "xftsx002";
		}
		else {
			if ($internal_function_system_connection_type=="ssh2") {
				$internal_function_server_ssh2_connect = ssh2_connect("localhost", $internal_function_ssh2_port);
				ssh2_auth_password($internal_function_server_ssh2_connect, ''.base64_decode($internal_function_ssh2_username).'', ''.base64_decode($internal_function_ssh2_password).'');
				$internal_function_server_ssh2_exec = ssh2_exec($internal_function_server_ssh2_connect, 'kill '.mysql_result($internal_function_server_stop_pid,0));
				sleep(3);
			}
			elseif ($internal_function_system_connection_type=="bash") {
				$internal_function_server_stop_pid = shell_exec("nohup ".$internal_function_server_dir."system/system.sh shoutcast ver1 stop ".mysql_result($internal_function_server_stop_pid,0)."");
				sleep(3);
			}
			else {
				echo '<xml>'; 
				echo '	<status>';
				echo '		<code>xfstx003</code>';
				echo '		<message>FATAL_SERVER_START_CRASH</message>';
				echo '	</status>'; 
				echo '</xml>';
				die();
			}
			return "yftsx001";
		}	
	}
}
function internal_function_server_kick($internal_function_server_id, $internal_function_server_owner, $internal_function_server_pass){
	global $internal_function_server_host;
	$internal_function_server_kick_query = mysql_query("SELECT portbase FROM internal_system_db_servers WHERE id='".mysql_real_escape_string(trim($internal_function_server_id))."' AND owner='".mysql_real_escape_string(strip_tags($internal_function_server_owner))."'");
	if (mysql_num_rows($internal_function_server_kick_query)==0) {
		return "xfkix001";
	}
	$fp = fsockopen($internal_function_server_host, mysql_result($internal_function_server_kick_query,0), &$errnum, &$errstr, 2);
	if($fp){
   		fwrite($fp, "GET /admin.cgi?pass=".strip_tags($internal_function_server_pass)."&mode=kicksrc HTTP/1.0\r\nUser-Agent:Mozilla/4.0\r\n\r\n");
		return "yfkix001";
	}
	else {
		return "xfkix002";
	}
}
function internal_folder_space($internal_check_folder){
	$internal_listing_dirsize = 0;
	if(is_dir($internal_check_folder)) {
		if($internal_listing_process = opendir($internal_check_folder)) {
			while($internal_listing_name = readdir($internal_listing_process) ) {
				if(($internal_listing_name == '.') || ($internal_listing_name == '..'))
					continue;
				if (!is_file($internal_check_folder.$internal_listing_name)) {
					$internal_check_folder_file_new = $internal_check_folder.$internal_listing_name."/";
					$internal_check_folder_file_new_filesize = 0;
					if(is_dir($internal_check_folder_file_new)) {
						if($internal_check_folder_file_new_open = opendir($internal_check_folder_file_new)) {
							while($internal_listing_folder_name = readdir($internal_check_folder_file_new_open) ) {
								if(($internal_listing_folder_name == '.') || ($internal_listing_folder_name == '..')) 
									continue;
								$internal_check_folder_size = stat($internal_check_folder_file_new.$internal_listing_folder_name);
								$internal_listing_dirsize += $internal_check_folder_size[7];
							}
						}
					}
				}
				else {
					$internal_listing_filedata = stat($internal_check_folder.$internal_listing_name);
					$internal_listing_dirsize += $internal_listing_filedata[7];
				}	
			}
			return $internal_listing_dirsize/1024;
		}
	}
}
?>