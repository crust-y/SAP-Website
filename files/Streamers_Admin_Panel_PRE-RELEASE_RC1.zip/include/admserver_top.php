<?PHP
//	Streamers Admin Panel 3.2
//
//	Developer:
//	Main Coding: djcrackhome [Sebastian Graebner]
//	Thanks 2 Raimund Barendt, resh [Mathias Simon], hansy [Rico Reinheckel], Largo [Michael Savino] 
//
//	License:
//	Creative Commons Attribution-ShareAlike 3.0 Unported License
//		This work is licensed under the Creative Commons Attribution-ShareAlike 3.0 Unported License.
//		To view a copy of this license, visit http://creativecommons.org/licenses/by-sa/3.0/ or
//		send a letter to Creative Commons, 171 Second Street, Suite 300, San Francisco, California, 94105, USA.
//
//	URL:		http://www.streamerspanel.com
//	SUPPORT:	http://support.streamerspanel.com
//	MAIL:		info@streamerspanel.com
///////////////////////////////////////////////
//
//	FILENAME: ./include/admradio_bottom.php
//

error_reporting(0);
if ((!defined("_include_security")) || (!preg_match("/content.php/i", $_SERVER['PHP_SELF']))) {
    header('Location: ./../index.php?system_login='.md5(md5("access").date("H:i").$_SERVER['REMOTE_ADDR']));
	die();
}
$internal_setting_query = mysql_query("SELECT * FROM internal_system_db_mainsetting WHERE id='0'") or die($language_message["g5"]);
foreach(mysql_fetch_array($internal_setting_query) as $internal_setting_query_key => $internal_setting_query_preference) {
	if (!is_numeric($internal_setting_query_key)) {
		$internal_setting[$internal_setting_query_key] = stripslashes($internal_setting_query_preference);
	}
}
if ($internal_user_level == "Super Administrator") {
	if (($_GET['action'] == "savesettings") && (isset($_POST['submit'])))  {
		foreach($_POST as $internal_settings_key => $internal_settings_pref) {
			$_POST[$internal_settings_key] = addslashes($internal_settings_pref);
		}
		if ($_POST['htaccess']=="0") $_POST['system_php_mp3']="0"; 
		if (mysql_query("UPDATE internal_system_db_mainsetting SET system_host='".mysql_real_escape_string(trim($_POST['system_host']))."', system_connection_type='".mysql_real_escape_string(trim($_POST['system_connection_type']))."', system_ssh_user='".mysql_real_escape_string(base64_encode($_POST['system_ssh_user']))."', system_ssh_pass='".mysql_real_escape_string(base64_encode($_POST['system_ssh_pass']))."', system_ssh_port='".mysql_real_escape_string(trim($_POST['system_ssh_port']))."', system_dir='".mysql_real_escape_string(addslashes(trim($_POST['system_dir'])))."', system_title='".mysql_real_escape_string($_POST['system_title'])."', system_slogan='".mysql_real_escape_string($_POST['system_slogan'])."', system_php_mp3='".mysql_real_escape_string(trim($_POST['system_php_mp3']))."', system_php_exe='".mysql_real_escape_string(trim($_POST['system_php_exe']))."', system_lang='".mysql_real_escape_string(trim($_POST['system_lang']))."', system_update='".mysql_real_escape_string(trim($_POST['system_update']))."', system_logourl='".mysql_real_escape_string(trim($_POST['system_logourl']))."', system_news='".mysql_real_escape_string(trim($_POST['system_news']))."', system_adj_config='".mysql_real_escape_string(trim($_POST['system_adj_config']))."', system_scs_config='".mysql_real_escape_string(trim($_POST['system_scs_config']))."', system_captcha='".mysql_real_escape_string(trim($_POST['system_captcha']))."', system_limit='".mysql_real_escape_string(trim($_POST['system_limit']))."', system_win='".mysql_real_escape_string(trim($_POST['system_win']))."'")) {
			if ($_POST['htaccess']!="0" && $_POST['system_php_mp3']!="0") {
				$internal_htaccess_cont = @fopen(".htaccess","w+");
				@fputs($internal_htaccess_cont,"php_value upload_max_filesize ".htmlspecialchars(trim($_POST['system_php_mp3']))."M\r\nphp_value post_max_size ".htmlspecialchars(trim($_POST['system_php_mp3']))."M\r\nphp_value max_execution_time ".htmlspecialchars(trim($_POST['system_php_exe']))."\r\nphp_value max_input_time ".htmlspecialchars(trim($_POST['system_php_exe']))."");
				@fclose($internal_htaccess_cont);
			}
			$usermessage_gre[] = "<h2>".$language_message[286]."</h2>";
		}
		else {
			$usermessage_red[] = "<h2>".$language_message[287]."</h2>";
		}
	}
}
?>