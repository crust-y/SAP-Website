<?PHP
//	Streamers Admin Panel 3.2
//
//	Developer:
//	Main Coding: djcrackhome [Sebastian Graebner]
//	Thanks 2 Raimund Barendt, resh [Mathias Simon], hansy [Rico Reinheckel], Largo [Michael Savino] 
//
//	License:
//	Creative Commons Attribution-ShareAlike 3.0 Unported License
//		This work is licensed under the Creative Commons Attribution-ShareAlike 3.0 Unported License.
//		To view a copy of this license, visit http://creativecommons.org/licenses/by-sa/3.0/ or
//		send a letter to Creative Commons, 171 Second Street, Suite 300, San Francisco, California, 94105, USA.
//
//	URL:		http://www.streamerspanel.com
//	SUPPORT:	http://support.streamerspanel.com
//	MAIL:		info@streamerspanel.com
///////////////////////////////////////////////
//
//	FILENAME: ./include/admradio_bottom.php
//

error_reporting(0);
if ((!defined("_include_security")) || (!preg_match("/content.php/i", $_SERVER['PHP_SELF']))) {
    header('Location: ./../index.php?system_login='.md5(md5("access").date("H:i").$_SERVER['REMOTE_ADDR']));
	die();
}
$internal_setting_query = mysql_query("SELECT * FROM internal_system_db_mainsetting WHERE id='0'") or die($language_message["g5"]);
foreach(mysql_fetch_array($internal_setting_query) as $internal_setting_query_key => $internal_setting_query_preference) {
	if (!is_numeric($internal_setting_query_key)) {
		$internal_setting[$internal_setting_query_key] = stripslashes($internal_setting_query_preference);
	}
}
$internal_listing_limit = mysql_real_escape_string(trim($internal_setting['system_limit']));
if (!isset($_GET['listing_query'])) $listing_query = 0;
else $listing_query = $_GET['listing_query'] * $internal_listing_limit;
$listing_query_limitery = $listing_query + $internal_listing_limit;
$listing_sql_query = mysql_query("SELECT * FROM internal_system_db_servers WHERE owner='".mysql_real_escape_string($internal_user_name)."' ORDER BY id ASC LIMIT $listing_query,$internal_listing_limit");
if (isset($_GET['edit'])) {
	$internal_autodj_port_query = mysql_query("SELECT portbase FROM internal_system_db_servers WHERE id='".mysql_real_escape_string(trim($_GET['edit']))."' AND owner='".mysql_real_escape_string($internal_user_name)."'");
	if (mysql_num_rows($internal_autodj_port_query)==0) {
		header('Location: content.php?include=music&error=sc_trans_access');
		die ();
	}
	$internal_autodj_pid_query = mysql_query("SELECT autopid FROM internal_system_db_servers WHERE id='".mysql_real_escape_string(trim($_GET['edit']))."' AND owner='".mysql_real_escape_string($internal_user_name)."'");
	if (mysql_num_rows($internal_autodj_pid_query)==0) {
		header('Location: content.php?include=music&error=sc_trans_access');
		die ();
	}
	if (mysql_result($internal_autodj_pid_query,0) != "9999999") {
		if ($_GET['system_action'] == "start") {
			if (substr(internal_function_sctrans_start(mysql_real_escape_string(trim($_GET['edit'])), strip_tags($_POST['pllist']), mysql_real_escape_string($internal_user_name)), 0, 8)=="yftsx001") {
				$usermessage_gre[] = "<h2>Server wurde gestartet</h2>";
			}
			else {
				$usermessage_red[] = "<h2>Server konnte nicht gestartet werden</h2>";
			}
		}
		elseif ($_GET['system_action'] == "stop") {
			if (substr(internal_function_sctrans_stop(mysql_real_escape_string(trim($_GET['edit'])), mysql_real_escape_string($internal_user_name)), 0, 8)=="yftsx001") {
				$usermessage_gre[] = "<h2>Server wurde beendet</h2>";
			}
			else {
				$usermessage_red[] = "<h2>Server konnte nicht gestartet werden</h2>";
			}
		}
		elseif ($_GET['system_action'] == "edit") {
			if (isset($_POST['submit'])) {
				$sqlquery_autodjupdate=mysql_query("UPDATE internal_system_db_servers SET streamtitle='".mysql_real_escape_string($_POST['titl'])."',streamurl='".mysql_real_escape_string($_POST['surl'])."',genre='".mysql_real_escape_string($_POST['genr'])."',shuffle='".mysql_real_escape_string($_POST['shuf'])."',quality='".mysql_real_escape_string($_POST['qual'])."',crossfademode='".mysql_real_escape_string($_POST['crom'])."',crossfadelength='".mysql_real_escape_string($_POST['crol'])."',samplerate='".mysql_real_escape_string($_POST['samp'])."',useid3='".mysql_real_escape_string($_POST['uid3'])."',public='".mysql_real_escape_string($_POST['publ'])."',channels='".mysql_real_escape_string($_POST['chan'])."',aim='".mysql_real_escape_string($_POST['maim'])."',icq='".mysql_real_escape_string($_POST['micq'])."',irc='".mysql_real_escape_string($_POST['mirc'])."' WHERE id='".mysql_real_escape_string(trim($_GET['edit']))."' AND portbase='".mysql_real_escape_string(trim(mysql_result($internal_autodj_port_query,0)))."'");	
				$usermessage_gre[] = "<h2>".$language_message["336"]." ".mysql_result($internal_autodj_port_query,0)." ".$language_message["336_pre"]."</h2>";
			}
			$internal_edit_data_query = mysql_query("SELECT * FROM internal_system_db_servers WHERE id='".mysql_real_escape_string($_GET['edit'])."' AND portbase='".mysql_real_escape_string(trim(mysql_result($internal_autodj_port_query,0)))."'");
			while ($editsqlrow = mysql_fetch_array($internal_edit_data_query)) { 
				$formedit_port = $editsqlrow["portbase"]; $formedit_pass = $editsqlrow["password"]; $formedit_bitr = $editsqlrow["bitrate"]; $formedit_titl = $editsqlrow["streamtitle"]; $formedit_surl = $editsqlrow["streamurl"]; $formedit_genr = $editsqlrow["genre"]; $formedit_shuf = $editsqlrow["shuffle"]; $formedit_qual = $editsqlrow["quality"]; $formedit_crom = $editsqlrow["crossfademode"]; $formedit_crol = $editsqlrow["crossfadelength"]; $formedit_samp = $editsqlrow["samplerate"]; $formedit_uid3 = $editsqlrow["useid3"]; $formedit_publ = $editsqlrow["public"]; $formedit_chan = $editsqlrow["channels"]; $formedit_maim = $editsqlrow["aim"]; $formedit_micq = $editsqlrow["icq"]; $formedit_mirc = $editsqlrow["irc"];	
			}
		}
	}
	else {
		$usermessage_red[] = "<h2>".$language_message["337"]."</h2>";
	}
}
?>