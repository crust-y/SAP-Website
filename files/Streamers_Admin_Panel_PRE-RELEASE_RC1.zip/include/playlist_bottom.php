<?PHP
//	Streamers Admin Panel 3.2
//
//	Developer:
//	Main Coding: djcrackhome [Sebastian Graebner]
//	Thanks 2 Raimund Barendt, resh [Mathias Simon], hansy [Rico Reinheckel],
//	 Largo [Michael Savino], Marcel Weinberg, and all translators!
//
//	License:
//	Creative Commons Attribution-ShareAlike 3.0 Unported License
//		This work is licensed under the Creative Commons Attribution-ShareAlike 3.0 Unported License.
//		To view a copy of this license, visit http://creativecommons.org/licenses/by-sa/3.0/ or
//		send a letter to Creative Commons, 171 Second Street, Suite 300, San Francisco, California, 94105, USA.
//
//	URL:		http://www.streamerspanel.com
//	SUPPORT:	http://support.streamerspanel.com
//	MAIL:		info@streamerspanel.com
///////////////////////////////////////////////
//
//	FILENAME: ./include/playlist_bottom.php
//
if ((!defined("_include_security")) || (!preg_match("/content.php/i", $_SERVER['PHP_SELF']))) {
    header('Location: ./../index.php?system_login='.md5(md5("access").date("H:i").$_SERVER['REMOTE_ADDR']));
	die();
}
error_reporting(0);
define('entries_per_page',100);
if (!isset($_GET['filecount']) or !is_numeric($_GET['filecount'])) $offset = 1;
else $offset = $_GET['filecount'];
if ($offset == 1) {
	$listing_start = $offset * entries_per_page - entries_per_page;
}
else {
	$listing_start = $offset * entries_per_page - entries_per_page + 3;
}					
$listing_end = $offset * entries_per_page + 2;
$dirlisting = @scandir($internal_setting["system_dir"]."clients/".$internal_user_id."/".trim($internal_server_port)."/configs/playlists");
if (!isset($dirlisting[$listing_start])) $errors[] = "";
?>
<div id="content">
	<div class="box">
		<h2><?php echo $language_message["391"].htmlspecialchars($internal_server_port);?></h2>
		<div class="tool_top_menu">
			<div class="main_shorttool"><?php echo $language_message["392"];?></div>
			<div class="main_righttool">
				<h2><?php echo $language_message["393"];?></h2>
				<p><?php echo $language_message["394"];?></p>
				<p>&nbsp;</p>
			</div>
		</div>
		<table cellspacing="0" cellpadding="0">
			<thead>
				<tr>
					<th><?php echo $language_message["395"];?></th>
					<th><?php echo $language_message["396"];?></th>
					<th><a class="selector" href="content.php?include=playlist&portbase=<?php echo htmlspecialchars($internal_server_port);?>&indiv=1&listname=<?php echo base64_encode("new playlist.lst")?>"><?php echo $language_message["397"];?></a></th>
				</tr>
			<tbody>
				<?php
				for($i=$listing_start;$i<=$listing_end;$i++) {
					if (($dirlisting[$i]!=".") && ($dirlisting[$i]!="..") && ($dirlisting[$i]!="")) {
							echo "<tr>
								<td>$dirlisting[$i]</td>
								<td>".round((filesize($internal_setting["system_dir"]."clients/".$internal_user_id."/".htmlspecialchars(trim($internal_server_port))."/configs/playlists/".$dirlisting[$i])/1024), 2)." KB (".round((filesize($internal_setting["system_dir"]."clients/".$internal_user_id."/".trim($internal_server_port)."/configs/playlists/".$dirlisting[$i])/1024/1024), 2)." MB)</td>
								<td><a class=\"delete\" href=\"content.php?include=playlist&portbase=".htmlspecialchars(trim($internal_server_port))."&indiv=0&listname=".base64_encode($dirlisting[$i])."&delete=1\">".$language_message["398"]."</a><a class=\"selector\" href=\"content.php?include=playlist&portbase=".htmlspecialchars(trim($internal_server_port))."&indiv=1&listname=".base64_encode($dirlisting[$i])."\">Bearbeiten</a></td>
								</tr>";						
					}
				}
				if (count(scandir($internal_setting["system_dir"]."clients/".$internal_user_id."/".trim($internal_server_port)."/configs/playlists"))==2) echo "<tr><td colspan=\"3\">Es sind keine Playlisten vorhanden.</td></tr>";
				?>
			</tbody>
		</table>
		<?php
		if (!isset($_GET['playlist']) && ($_GET['indiv'] == "1")) { ?>
		<br />
		<h2><?php echo $language_message["401"];?></h2>
		<form action="content.php?include=playlist&portbase=<?php echo htmlspecialchars($internal_server_port);?>&indiv=1&listname=<?php echo $_GET['listname']; ?><?php if ($_GET['listname'] == "bmV3IHBsYXlsaXN0LmxzdA==") { echo "&new=1";} if (isset($_GET['playlist_folder'])) echo "&playlist_folder=".htmlspecialchars($_GET['playlist_folder']);?>" method=post name=treeform onSubmit=setValue()>
			<input name=arv  type=hidden>
			<div class="input_field">
				<label for="a">Erstellungform</label>
				<select class="formselect_loca" name="data_style" id="data_style" onchange="playlist_creation(value);"><option value="1"<?php if ($_GET['set_type']=="1") echo " selected=\"selected\""; ?>>Benutzerdefinierte Wiedergabeliste</option><option value="0"<?php if ($_GET['set_type']=="0") echo " selected=\"selected\""; ?>>Zuf&auml;llige Playliste aus allen Mediendateien</option></select>
                <span class="field_desc">Gew&uuml;nschte Erstellung der Playliste</span>
			</div>
			<div class="input_field">
				<label for="a">Dateiname</label>
				<input class="mediumfield" name="playlistformname" id="playlistformname" type="text" value="<?php if ($_GET['listname'] == "bmV3IHBsYXlsaXN0LmxzdA==") { if (isset($_GET['set_name'])) echo htmlspecialchars($_GET['set_name']); else echo "demoplaylistname"; } else { echo base64_decode($_GET['listname']); }?>" <?php if ($_GET['listname'] !== "bmV3IHBsYXlsaXN0LmxzdA==") { echo "disabled=\"disabled\""; }?> />
                <span class="field_desc">.lst</span>
			</div>
			<div class="input_field">
				<label for="a">Ordnername</label>
				<select class="formselect_loca" name="playlistform_foldername" onchange="window.location.href='content.php?include=playlist&portbase=<?php echo htmlspecialchars($internal_server_port);?>&indiv=1&listname=<?php echo htmlspecialchars($_GET['listname']); if ($_GET['listname'] == "bmV3IHBsYXlsaXN0LmxzdA==") { echo "&new=1"; }?>&playlist_folder='+value+'&set_name='+this.form.playlistformname.value+'&set_type='+this.form.data_style.options[this.form.data_style.selectedIndex].value;"><option value="/">./</option>
                <?php
                if ($handle = opendir($internal_setting["system_dir"]."clients/".$internal_user_id."/".trim($internal_server_port)."/uploads/audio/")) {
					while (false !== ($file = readdir($handle))) {
						if ($file != "." && $file != ".." && !is_file($internal_setting["system_dir"]."clients/".$internal_user_id."/".trim($internal_server_port)."/uploads/audio/".$file)) {
							echo "<option value=\"".$file."\"";
							if ((isset($_GET['playlist_folder'])) && ($_GET['playlist_folder']==$file)) echo " selected=\"selected\"";
							echo ">./".$file."/</option>\n";
							echo "\n";
						}
					}
					closedir($handle);
				}
				?>
                </select>
                <span class="field_desc">Gew&uuml;nschten Zielordner w&auml;hlen</span>
			</div>
			<script src="./include/scripts/dhtmlxcommon.js"></script>
			<script src="./include/scripts/dhtmlxtree.js"></script>
			<table width="0" border="0" cellspacing="0" cellpadding="0" class="playlist" id="playlist_table_id"<?php if ($_GET['set_type']=="0") echo " style=\"display:none;\""; ?>>
				<tr>
					<td>
						<table cellpadding="0" cellspacing="0" class="playlist">
							<thead></thead>
							<tbody>
								<tr>
									<td width="49%">
										<p><?php echo $language_message["403"];?></p>
											<div id="tree1" style="width:275px; height:210px; background-color:#f5f5f5; border :1px solid Silver; overflow:hidden; font-family: Arial, Helvetica, sans-serif; border-collapse:collapse; overflow:auto;"></div>
									</td>
								</tr>
							</tbody>
						</table>
					</td>
					<td>
						<table cellpadding="0" cellspacing="0" class="playlist">
							<thead></thead>
							<tbody>
								<tr>
									<td width="49%">
										<p><?php echo $language_message["404"];?></p>
										<div id="playlist" style="width:275px; height:210px; background-color:#f5f5f5; border :1px solid Silver; overflow:hidden; font-family: Arial, Helvetica, sans-serif; border-collapse:collapse; overflow:auto;"></div>
									</td>
								</tr>
							</tbody>
						</table>
					</td>
				</tr>
			</table>
			<script>
				tree=new dhtmlXTreeObject("tree1","100%","100%",0);
				tree.enableDragAndDrop(true);
				tree.label = "tree1";
				tree.loadXML("content.php?playlist_xml_port=<?php echo htmlspecialchars($internal_server_port);?>&playlist_xml=left&playlist_folder=<?php echo htmlspecialchars($_GET['playlist_folder']);?>");
				tree.enableTreeLines(false);
				tree.enableTreeImages(false); 
				tree.enableImageDrag(false);
				tree.enableActiveImages(false);
				tree2=new dhtmlXTreeObject("playlist","100%","100%",0);
				tree2.enableDragAndDrop(true);
				tree2.loadXML("content.php?playlist_xml_port=<?php echo htmlspecialchars($internal_server_port);?>&playlist_xml=right&playlist_listname=<?php echo htmlspecialchars($_GET['listname']); ?>");
				tree2.enabledpcpy(true);
				tree2.label = "tree2";
				tree2.enableTreeLines(false);
				tree2.enableTreeImages(false); 
				tree2.enableImageDrag(false);
				tree2.enableActiveImages(false);
			</script>
			<input class="submit" type="submit" value="<?php echo $language_message["405"];?>" />
			<input type="button" name="clear" id="clear" onClick="clearPlaylist()" class="submit" value="<?php echo $language_message["406"];?>" <?php if ($_GET['set_type']=="0") echo " style=\"display:none;\""; ?>/>
		</form>
        <?php }?>
	</div> 
</div>