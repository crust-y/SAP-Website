<?PHP
//	Streamers Admin Panel 3.2
//
//	Developer:
//	Main Coding: djcrackhome [Sebastian Graebner]
//	Thanks 2 Raimund Barendt, resh [Mathias Simon], hansy [Rico Reinheckel], Largo [Michael Savino] 
//
//	License:
//	Creative Commons Attribution-ShareAlike 3.0 Unported License
//		This work is licensed under the Creative Commons Attribution-ShareAlike 3.0 Unported License.
//		To view a copy of this license, visit http://creativecommons.org/licenses/by-sa/3.0/ or
//		send a letter to Creative Commons, 171 Second Street, Suite 300, San Francisco, California, 94105, USA.
//
//	URL:		http://www.streamerspanel.com
//	SUPPORT:	http://support.streamerspanel.com
//	MAIL:		info@streamerspanel.com
///////////////////////////////////////////////
//
//	FILENAME: ./include/admserver_bottom.php
//

error_reporting(0);
if ((!defined("_include_security")) || (!preg_match("/content.php/i", $_SERVER['PHP_SELF']))) {
    header('Location: ./../index.php?system_login='.md5(md5("access").date("H:i").$_SERVER['REMOTE_ADDR']));
	die();
}
?>
<div id="content">
	<div class="box">
		<h2><?php echo $language_message["525"]." ".htmlspecialchars($internal_upload_portbase);?></h2>
		<div class="contact_top_menu">
			<div class="tool_top_menu">
				<div class="main_shorttool"><?php echo $language_message["526"];?></div>
				<div class="main_righttool">
					<h2><?php echo $language_message["527"];?></h2>
					<p><?php echo $language_message["528"];?></p>
					<p>&nbsp;</p>
				</div>
			</div>
			<form method="post" action="content.php?include=upload&portbase=<?php echo htmlspecialchars($internal_upload_portbase);?>" enctype="multipart/form-data">
				<fieldset>
					<legend><?php echo $language_message["529"]." ".htmlspecialchars($internal_upload_portbase);?></legend>
					<table cellpadding="0" cellspacing="0" class="upload_table">
						<thead>
							<tr>
								<th><?php echo $language_message["530"];?></th>
								<th><?php echo $language_message["531"];?></th>
								<th colspan="4"><?php echo $language_message["532"];?></th>
							</tr>
						</thead>
						<tbody>
							<tr class="upload_table">
								<td class="subnav_child"><?php echo $language_message["533"];?></td>
								<td class="upload_table"><?php echo htmlspecialchars(round(($internal_server_space['webspace']/1024), 2))." MB";?></td>
								<td class="upload_table"><?php echo htmlspecialchars("".round(($actual_dir_size/1024), 2))." MB";?></td>
								<?php 
								echo '<td><div class="upload_table_show" style="background-position:';
									$negative_background_pos = ($actual_dir_size/$internal_server_space['webspace'])*180;
								echo '-'.$negative_background_pos.'px 0px;"></div></td>';
								?>
						    </tr>
							<tr class="upload_table">
								<td class="subnav_child"><?php echo $language_message["535"];?></td>
								<td colspan="3" class="upload_table"><?php echo htmlspecialchars(ini_get('upload_max_filesize'))."B";?></td>
							</tr>
							<tr class="upload_table">
								<td class="subnav_child"><?php echo $language_message["536"];?></td>
								<td colspan="3" class="upload_table">MP3</td>
							</tr>
							<tr class="upload_table">
								<td class="subnav_child"><?php echo $language_message["537"];?></td>
								<td colspan="3" class="upload_table"><?php echo htmlspecialchars($internal_upload_portbase);?></td>
							</tr>
   							<tr class="upload_table">
								<td class="subnav_child">Ordnername</td>
								<td colspan="3" class="upload_table">
                                <select class="formselect_loca" name="playlistform_foldername" onchange="window.location.href='content.php?include=upload&portbase=<?php echo htmlspecialchars($internal_upload_portbase);?>&playlist_folder='+value;"><option value="/">./</option><?php
                if ($handle = opendir($internal_setting["system_dir"]."clients/".$internal_user_id."/".htmlspecialchars($internal_upload_portbase)."/uploads/audio/")) {
					while (false !== ($file = readdir($handle))) {
						if ($file != "." && $file != ".." && !is_file($internal_setting["system_dir"]."clients/".$internal_user_id."/".htmlspecialchars($internal_upload_portbase)."/uploads/audio/".$file)) {
							echo "<option value=\"".$file."\"";
							if ((isset($_GET['playlist_folder'])) && ($_GET['playlist_folder']==$file)) echo " selected=\"selected\"";
							echo ">./".$file."/</option>\n";
							echo "\n";
						}
					}
					closedir($handle);
				}
				?>
                </select></td>
                </tr>      
						</tbody>
					</table>
					<div class="input_field">
						<label for="a"><?php echo $language_message["538"];?></label>
						<input class="uploadfield" name="uploaded_file" type="file" value="" />
					</div>
					<input class="submit" type="submit" value="<?php echo $language_message["539"];?>" onclick="setVisibility('sub3', 'inline');"; />
					<input class="submit" type="reset" value="<?php echo $language_message["540"];?>" onclick="document.location='content.php?include=music';" />
					<div id="sub3" class="loader_img"></div>
				</fieldset>
			</form>
			<br />
			<table cellspacing="0" cellpadding="0">
				<thead>
					<tr>
						<th><?php echo $language_message["541"];?></th>
						<th><?php echo $language_message["542"];?></th>
						<th>&nbsp;</th>
					</tr>
				</thead>
				<tbody>
				<?php
					for($i=$listing_start;$i<=$listing_end;$i++) {
						if (($dirlisting[$i]!=".") && ($dirlisting[$i]!="..") && ($dirlisting[$i]!="") && is_file($internal_setting["system_dir"]."clients/".$internal_user_id."/".htmlspecialchars($internal_upload_portbase)."/uploads/audio/".$dirlisting[$i])) {
							echo "<tr>
								<td>$dirlisting[$i]</td>
								<td>".htmlspecialchars(round((filesize($internal_setting["system_dir"]."clients/".$internal_user_id."/".htmlspecialchars($internal_upload_portbase)."/uploads/audio/".$dirlisting[$i])/1024), 2))." KB (".htmlspecialchars(round((filesize($internal_setting["system_dir"]."clients/".$internal_user_id."/".htmlspecialchars($internal_upload_portbase)."/uploads/audio/".$dirlisting[$i])/1024/1024), 2))." MB)</td>
									<td><a class=\"delete\" href=\"content.php?include=upload&portbase=".htmlspecialchars($internal_upload_portbase)."&delete=".base64_encode($dirlisting[$i])."\">".$language_message["543"]."</a><a class=\"selector\" href=\"content.php?include=upload&portbase=".htmlspecialchars($internal_upload_portbase)."&download=".base64_encode($dirlisting[$i])."\">".$language_message["544"]."</a></td>
								</tr>";
						}
					}
					if (count(scandir($internal_setting["system_dir"]."clients/".$internal_user_id."/".htmlspecialchars($internal_upload_portbase)."/uploads/audio"))==2) echo "<tr><td colspan=\"3\">Es sind keine Mediendateien vorhanden.</td></tr>";
				?>
				</tbody>
			</table>
            <?php
			if (count(scandir($internal_setting["system_dir"]."clients/".$internal_user_id."/".htmlspecialchars($internal_upload_portbase)."/uploads/audio"))!=2) {?>
			<ul class="paginator">
				<?php
				static $counter;
				$counter=0;
				$recursive=false;
				while (($datei = readdir($dirlistdir)) !== false) {
					if(($datei!=".") and ($datei!="..")) {
						$counter = (is_dir("./pages/uploads/".$port."/".$datei)) ? num_files("./pages/uploads/".$port."/".$datei, $recursive, $counter) : $counter+1;
					}
				}
				closedir($dirlistdir);
				$pagessubcount = ceil($counter/7);
				if ($offset == 1) {
					echo "<li><a href=\"content.php?include=upload&portbase=".$port."&filecount=".($offset)."\">".$language_message["545"]."</a></li>";
				}
				else {
					echo "<li><a href=\"content.php?include=upload&portbase=".$port."&filecount=".($offset-1)."\">".$language_message["545"]."</a></li>";
				}
				for ($pagessubcountfor=0; $pagessubcountfor <= $pagessubcount; $pagessubcountfor += 1) {
					if ($pagessubcountfor!==0) {
						echo "<li";
						if ($offset==$pagessubcountfor) {
							echo " class=\"current\"";
						}
						echo"><a href=\"content.php?include=upload&portbase=".$port."&filecount=".$pagessubcountfor."\">".$pagessubcountfor."</a></li>";
					}
				}
				if ($offset == $pagessubcount) {
				echo "<li><a href=\"content.php?include=upload&portbase=".$port."&filecount=".($offset)."\">".$language_message["546"]."</a></li>";
				}
				else {
					echo "<li><a href=\"content.php?include=upload&portbase=".$port."&filecount=".($offset+1)."\">".$language_message["546"]."</a></li>";
				}
				?>
			</ul>
            <?php } ?>
		</div>
	</div>
</div>