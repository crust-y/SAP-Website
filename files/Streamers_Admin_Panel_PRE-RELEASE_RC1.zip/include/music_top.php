<?PHP
//	Streamers Admin Panel 3.2
//
//	Developer:
//	Main Coding: djcrackhome [Sebastian Graebner]
//	Thanks 2 Raimund Barendt, resh [Mathias Simon], hansy [Rico Reinheckel], Largo [Michael Savino] 
//
//	License:
//	Creative Commons Attribution-ShareAlike 3.0 Unported License
//		This work is licensed under the Creative Commons Attribution-ShareAlike 3.0 Unported License.
//		To view a copy of this license, visit http://creativecommons.org/licenses/by-sa/3.0/ or
//		send a letter to Creative Commons, 171 Second Street, Suite 300, San Francisco, California, 94105, USA.
//
//	URL:		http://www.streamerspanel.com
//	SUPPORT:	http://support.streamerspanel.com
//	MAIL:		info@streamerspanel.com
///////////////////////////////////////////////
//
//	FILENAME: ./include/music_top.php
//

error_reporting(0);
if ((!defined("_include_security")) || (!preg_match("/content.php/i", $_SERVER['PHP_SELF']))) {
    header('Location: ./../index.php?system_login='.md5(md5("access").date("H:i").$_SERVER['REMOTE_ADDR']));
	die();
}
$internal_setting_query = mysql_query("SELECT * FROM internal_system_db_mainsetting WHERE id='0'") or die($language_message["g5"]);
foreach(mysql_fetch_array($internal_setting_query) as $internal_setting_query_key => $internal_setting_query_preference) {
	if (!is_numeric($internal_setting_query_key)) {
		$internal_setting[$internal_setting_query_key] = stripslashes($internal_setting_query_preference);
	}
}
switch ($_GET['error']) {
	case "port":
		$usermessage_red[] = "<h2>".$language_message["385"]."</h2>";
		break;
	case "access":
		$usermessage_red[] = "<h2>".$language_message["386"]."</h2>";
		break;
	case "dir":
		$usermessage_red[] = "<h2>".$language_message["387"]."</h2>";
		break;
	case "space":
		$usermessage_red[] = "<h2>".$language_message["388"]."</h2>";
		break;
	case "dirlisting":
		$usermessage_red[] = "<h2>".$language_message["389"]."</h2>";
		break;
	case "sc_trans_access":
		$usermessage_gre[] = "<h2>".$language_message["390"]."</h2>";
		break;
}
?>