<?PHP
//	Streamers Admin Panel 3.2
//
//	Developer:
//	Main Coding: djcrackhome [Sebastian Graebner]
//	Thanks 2 Raimund Barendt, resh [Mathias Simon], hansy [Rico Reinheckel], Largo [Michael Savino] 
//
//	License:
//	Creative Commons Attribution-ShareAlike 3.0 Unported License
//		This work is licensed under the Creative Commons Attribution-ShareAlike 3.0 Unported License.
//		To view a copy of this license, visit http://creativecommons.org/licenses/by-sa/3.0/ or
//		send a letter to Creative Commons, 171 Second Street, Suite 300, San Francisco, California, 94105, USA.
//
//	URL:		http://www.streamerspanel.com
//	SUPPORT:	http://support.streamerspanel.com
//	MAIL:		info@streamerspanel.com
///////////////////////////////////////////////
//
//	FILENAME: ./include/account_top.php
//

error_reporting(0);
if ((!defined("_include_security")) || (!preg_match("/content.php/i", $_SERVER['PHP_SELF']))) {
    header('Location: ./../index.php?system_login='.md5(md5("access").date("H:i").$_SERVER['REMOTE_ADDR']));
	die();
}
$internal_setting_query = mysql_query("SELECT * FROM internal_system_db_mainsetting WHERE id='0'") or die($language_message["g5"]);
foreach(mysql_fetch_array($internal_setting_query) as $internal_setting_query_key => $internal_setting_query_preference) {
	if (!is_numeric($internal_setting_query_key)) {
		$internal_setting[$internal_setting_query_key] = stripslashes($internal_setting_query_preference);
	}
}
if (isset($_POST['account_internal_submit'])) {
	if ($_POST['account_password'] != "***********") {
		if (($_POST['account_password']) == ($_POST['account_password_repeat'])) {
			if (mysql_query("UPDATE internal_system_db_users SET md5_hash='".mysql_real_escape_string(trim(md5($internal_user_name.$_POST['account_password'])))."' WHERE id='".mysql_real_escape_string($internal_user_id)."'")) {
				$_SESSION['security_session_password'] = $_POST['account_password'];
			}
		}
		else {
			$usermessage_yel[] = "<h2>".$language_message[102]."</h2>";
		}
	}
	if (mysql_query("UPDATE internal_system_db_users SET user_email='".mysql_real_escape_string($_POST["account_email"])."', firstname='".mysql_real_escape_string($_POST["account_firstname"])."', lastname='".mysql_real_escape_string($_POST["account_lastname"])."', dateofbirth='".mysql_real_escape_string($_POST["account_dateofbirth"])."', street='".mysql_real_escape_string($_POST["account_street"])."', city='".mysql_real_escape_string($_POST["account_city"])."', zipcode='".mysql_real_escape_string($_POST["account_zipcode"])."', state='".mysql_real_escape_string($_POST["account_state"])."', country='".mysql_real_escape_string(trim($_POST["account_country"]))."', phone='".mysql_real_escape_string($_POST["account_phone"])."', wwwurl='".mysql_real_escape_string(addslashes(trim($_POST["account_wwwurl"])))."', facebook='".mysql_real_escape_string(addslashes(trim($_POST["account_facebook"])))."' WHERE id='".mysql_real_escape_string(trim($internal_user_id))."'") ) {
		$usermessage_gre[] = "<h2>".$language_message[103]."</h2>";
	}
	else{
		$usermessage_red[] = "<h2>".$language_message[104]."</h2>";
	}
}
if (isset($_POST['api_internal_submit'])) {
	if (mysql_query("UPDATE internal_system_db_users SET secretkey='".mysql_real_escape_string(md5(time().$internal_user_id.md5(date().$_SERVER['REMOTE_ADDR']).md5(mt_rand(5,15)).md5(mt_rand(5,10))))."' WHERE id='".mysql_real_escape_string($internal_user_id)."'") ) {
		$usermessage_gre[] = "<h2>".$language_message[105]."</h2>";
	}
	else{
		$usermessage_red[] = "<h2>".$language_message[106]."</h2>";
	}
}
?>