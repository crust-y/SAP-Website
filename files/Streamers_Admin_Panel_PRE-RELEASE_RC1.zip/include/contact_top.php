<?PHP
//	Streamers Admin Panel 3.2
//
//	Developer:
//	Main Coding: djcrackhome [Sebastian Graebner]
//	Thanks 2 Raimund Barendt, resh [Mathias Simon], hansy [Rico Reinheckel], Largo [Michael Savino] 
//
//	License:
//	Creative Commons Attribution-ShareAlike 3.0 Unported License
//		This work is licensed under the Creative Commons Attribution-ShareAlike 3.0 Unported License.
//		To view a copy of this license, visit http://creativecommons.org/licenses/by-sa/3.0/ or
//		send a letter to Creative Commons, 171 Second Street, Suite 300, San Francisco, California, 94105, USA.
//
//	URL:		http://www.streamerspanel.com
//	SUPPORT:	http://support.streamerspanel.com
//	MAIL:		info@streamerspanel.com
///////////////////////////////////////////////
//
//	FILENAME: ./include/contact_top.php
//

if ((!defined("_include_security")) || (!preg_match("/content.php/i", $_SERVER['PHP_SELF']))) {
    header('Location: ./../index.php?system_login='.md5(md5("access").date("H:i").$_SERVER['REMOTE_ADDR']));
	die();
}
$internal_setting_query = mysql_query("SELECT * FROM internal_system_db_mainsetting WHERE id='0'") or die($messages["g5"]);
foreach(mysql_fetch_array($internal_setting_query) as $internal_setting_query_key => $internal_setting_query_preference) {
	if (!is_numeric($internal_setting_query_key)) {
		$internal_setting[$internal_setting_query_key] = stripslashes($internal_setting_query_preference);
	}
}
if (isset($_POST['internal_contact_submit'])) {
	if (isset($_POST['internal_contact_email'])) {
		if (!preg_match("/[\.a-z0-9_-]+@[a-z0-9-]{2,}\.[a-z]{2,4}$/i", $_POST['internal_contact_email'])) {
			$internal_contact_formerror = "email";
		}
		else {
			if (empty($_POST['internal_contact_reason'])) {
				$internal_contact_formerror = "reason";
			}
			else {
				if (empty($_POST['internal_contact_message'])) {
					$internal_contact_formerror = "message";
				}
				else {
					if (function_exists('htmlspecialchars_decode'))
						$internal_contact_messagesql = htmlspecialchars_decode($_POST['internal_contact_message'], ENT_QUOTES);
					if (function_exists('htmlspecialchars_decode'))
						$internal_contact_reasonsql = htmlspecialchars_decode($_POST['internal_contact_reason'], ENT_QUOTES);
					if (mysql_query("INSERT INTO internal_system_db_notices (username,reason,message,ip) VALUES('".mysql_real_escape_string($internal_user_name)."','".mysql_real_escape_string($internal_contact_reasonsql)."','".mysql_real_escape_string($internal_contact_messagesql)."','".mysql_real_escape_string($_SERVER['REMOTE_ADDR'])."')")) {
						$usermessage_gre[] = "<h2>".$language_message["355"]."</h2>";
						if ($internal_setting['system_contact_email']=="1") {
							mail("".$internal_setting['system_contact_email_adress']."", "Streamers Admin Panel - Eine neue Nachricht von ".$internal_user_name."", $language_message["588_1"]."'".htmlspecialchars($internal_user_name)."'".$language_message["588_2"].htmlspecialchars($internal_contact_reasonsql).$language_message["588_3"]."http".($_SERVER['HTTPS']?'s':null)."://".$_SERVER['HTTP_HOST'].$_SERVER['PHP_SELF'].$language_message["588_4"], "From: noreply@".$_SERVER['HTTP_HOST']."\r\n"); 
						}
					}
					else {
						$usermessage_red[] = "<h2>".$language_message["356"]."</h2>";
					}
				}
			}
		}
	}
	else {
		$usermessage_red[] = "<h2>".$language_message["357"]."</h2>";
		$internal_contact_formerror = "email";
	}
}
?>