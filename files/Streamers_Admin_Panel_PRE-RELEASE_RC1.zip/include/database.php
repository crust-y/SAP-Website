<?PHP
//	Streamers Admin Panel 3.1.5 - Release Candidate
//	Coded by 'djcrackhome'
//
//	License:
//	Creative Commons Attribution-ShareAlike 3.0 Unported License
//		This work is licensed under the Creative Commons Attribution-ShareAlike 3.0 Unported License.
//		To view a copy of this license, visit http://creativecommons.org/licenses/by-sa/3.0/ or
//		send a letter to Creative Commons, 171 Second Street, Suite 300, San Francisco, California, 94105, USA.
//
//	URL:		http://www.streamerspanel.com
//	SUPPORT:	http://support.streamerspanel.com
//	MAIL:		info@streamerspanel.com
///////////////////////////////////////////////
//	./database.php | Database Config File
//	

$config_mysql_host = "localhost"; 
$config_mysql_username = ""; 
$config_mysql_password = ""; 
$config_mysql_database = "";

?>