<?php
//	Streamers Admin Panel 3.1.5 - Release Candidate
//	Coded by 'djcrackhome'
//
//	License:
//	Creative Commons Attribution-ShareAlike 3.0 Unported License
//		This work is licensed under the Creative Commons Attribution-ShareAlike 3.0 Unported License.
//		To view a copy of this license, visit http://creativecommons.org/licenses/by-sa/3.0/ or
//		send a letter to Creative Commons, 171 Second Street, Suite 300, San Francisco, California, 94105, USA.
//
//	URL:		http://www.streamerspanel.com
//	SUPPORT:	http://support.streamerspanel.com
//	MAIL:		info@streamerspanel.com
///////////////////////////////////////////////
//	./include/messages.php | Messages Request
//	

if (!require_once(dirname(__FILE__)."/database.php")) die("database.php could not be loaded!");
if ($config_mysql_host == "" || !isset($config_mysql_host)) header ("Location: ./../install/install.php");
$establish_db_connect = mysql_connect($config_mysql_host, $config_mysql_username, $config_mysql_password) or die ("database could not be connected");
$establish_db_connect_selection = mysql_select_db($config_mysql_database) or die ("database could not be selected");
$language_request_query = mysql_query("SELECT system_lang FROM internal_system_db_mainsetting WHERE id='0'");
$language_request_result = mysql_result($language_request_query,0);
if (!is_file(dirname(__FILE__)."/languages/".$language_request_result.".php")) {
	$usermessage_red[] = "<h2>The language file could not be found, English is the default language!</h2>";
	$language_request_result = "english";
}
include_once (dirname(__FILE__)."/languages/".$language_request_result.".php");
if (!isset($_GET['id'])) $message_pn_error = "error";
else $message_pn_id = $_GET['id'];
$message_pn_id=preg_replace("#/#","", $message_pn_id);
$message_pn_id=strip_tags($message_pn_id);
if ($message_pn_id == "error") {
	echo "<h2>".$language_message["56"]."</h2>";
}
else {
	$message_pn_query = mysql_query("SELECT * FROM internal_system_db_notices WHERE id='".mysql_real_escape_string(trim($message_pn_id))."'");
	$message_pn_fetch = mysql_fetch_array($message_pn_query);
	echo "<h3>".$language_message["57"]." ".htmlspecialchars($message_pn_fetch['username'])."<hr /></h3>
		<h4>".$language_message["58"].": <i>".htmlspecialchars($message_pn_fetch['reason'])."</i></h4>
		<p>".$language_message["59"].": ".nl2br(htmlspecialchars($message_pn_fetch['message']))."</p>
		<p>[".htmlspecialchars(trim($message_pn_fetch['ip']))."]</p>";
}
?>
