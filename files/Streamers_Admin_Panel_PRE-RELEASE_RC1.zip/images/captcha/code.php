<?PHP
//	Streamers Admin Panel 3.2
//
//	Developer:
//	Main Coding: djcrackhome [Sebastian Graebner]
//	Thanks 2 Raimund Barendt, resh [Mathias Simon], hansy [Rico Reinheckel], Largo [Michael Savino] 
//
//	License:
//	Creative Commons Attribution-ShareAlike 3.0 Unported License
//		This work is licensed under the Creative Commons Attribution-ShareAlike 3.0 Unported License.
//		To view a copy of this license, visit http://creativecommons.org/licenses/by-sa/3.0/ or
//		send a letter to Creative Commons, 171 Second Street, Suite 300, San Francisco, California, 94105, USA.
//
//	URL:		http://www.streamerspanel.com
//	SUPPORT:	http://support.streamerspanel.com
//	MAIL:		info@streamerspanel.com
///////////////////////////////////////////////
//
//	FILENAME: ./images/captcha/code.php
//

error_reporting(0);
session_start();
if ((!isset($_SESSION['security_session_captcha_rand'])) or (!is_numeric($_SESSION['security_session_captcha_rand']))) {
    header('Location: ./../../index.php?system_login='.md5(md5("access").date("H:i").$_SERVER['REMOTE_ADDR']));
	die();
}
$security_captcha_image_generator=imagecreatefromjpeg('captcha_bg.jpg');	
$security_captcha_image_numbers=imagettftext($security_captcha_image_generator,15,rand(-10,10),rand(5,80),rand(20,21),imagecolorallocate($security_captcha_image_generator,255-rand(100,255),255-rand(100,255),255-rand(100,255)),"./../../include/css/font_source/delicious-roman-webfont.ttf",empty($_SESSION['security_session_captcha_rand']) ? 'error' : $_SESSION['security_session_captcha_rand']);
header("Content-type:image/jpeg");
header("Content-Disposition:inline ; filename=security_captcha_image.jpg");	
imagejpeg($security_captcha_image_generator);
?>