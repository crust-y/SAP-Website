<?php
//	Streamers Admin Panel 3.2
//
//	Developer:
//	Main Coding: djcrackhome [Sebastian Graebner]
//	Thanks to all VIP Users for their support and all translators, and a special thanks to:
//	Raimund Barendt, resh [Mathias Simon], peaceman2305, hansy [Rico Reinheckel], Largo [Michael Savino] 
//
//	License:
//	Creative Commons Attribution-ShareAlike 3.0 Unported License
//		This work is licensed under the Creative Commons Attribution-ShareAlike 3.0 Unported License.
//		To view a copy of this license, visit http://creativecommons.org/licenses/by-sa/3.0/ or
//		send a letter to Creative Commons, 171 Second Street, Suite 300, San Francisco, California, 94105, USA.
//
//	URL:		http://www.streamerspanel.com
//	SUPPORT:	http://support.streamerspanel.com
//	MAIL:		info@streamerspanel.com
///////////////////////////////////////////////
//
//	FILENAME: ./content.php
//

error_reporting(0);
$define_get_array = array("external_api", "playlist_xml", "action");
foreach ($define_get_array as $define_get_value) {
	$_GET[$define_get_value] = (isset($_GET[$define_get_value])) ? $_GET[$define_get_value]: NULL;
} 
$define_post_array = array("index_security_captcha_field");
foreach ($define_post_array as $define_post_value) {
	$_POST[$define_post_value] = (isset($_POST[$define_post_value])) ? $_POST[$define_post_value]: NULL;
}
define("_include_security",1);
if (!require_once(dirname(__FILE__)."/include/database.php")) die("Streamers Admin Panel ERROR\n'database.php' could not be loaded!");
if ($config_mysql_host == "" || !isset($config_mysql_host)) header("Location: ".dirname(__FILE__)."/install/install.php");
$establish_db_connect = mysql_connect($config_mysql_host, $config_mysql_username, $config_mysql_password) or die("Streamers Admin Panel ERROR\n'database' could not be connected");
$establish_db_connect_selection = mysql_select_db($config_mysql_database) or die("Streamers Admin Panel ERROR\n'database' could not be selected");
session_start();
$define_session_array = array("security_session_captcha_rand");
foreach ($define_session_array as $define_session_value) {
	$_SESSION[$define_session_value] = (isset($_SESSION[$define_session_value])) ? $_SESSION[$define_session_value]: NULL;
}
$language_request_query = mysql_query("SELECT system_lang FROM internal_system_db_mainsetting WHERE id='0'");
$language_request_result = mysql_result($language_request_query,0);
if (!is_file(dirname(__FILE__)."/include/languages/".$language_request_result.".php")) {
	$usermessage_red[] = "<h2>The language file could not be found, English is the default language!</h2>";
	$language_request_result = "english";
	if (!is_file(dirname(__FILE__)."/include/languages/english.php")) die("Language file could not be loaded!");
}
include_once (dirname(__FILE__)."/include/languages/".$language_request_result.".php");
if (!isset($_GET['include']) || !preg_match("/^[a-z]{4,10}$/", $_GET['include'])) $include_var_name = "main";
else $include_var_name = htmlspecialchars($_GET['include']);
if (isset($_GET['security_login'])) {
	if ($_GET['security_login'] == md5(md5("logout").$_SERVER['REMOTE_ADDR'])) {
		session_destroy();
		header('Location: index.php?system_login='.md5(md5("logout").date("H:i").$_SERVER['REMOTE_ADDR']).'');
		die();
	}
}
$security_session_status = FALSE;
if (isset($_SESSION['security_session_username']) && isset($_SESSION['security_session_password']) || isset($_POST['index_username']) && isset($_POST['index_user_password']) && ($_GET['external_api']!="1")) {
	if (isset($_POST['index_login_submit'])) {
		$security_check_login_username = $_POST['index_username'];
		$security_check_login_password = $_POST['index_user_password'];
	}
	else {
		$security_check_login_username = $_SESSION['security_session_username'];
		$security_check_login_password = $_SESSION['security_session_password'];
	}
	if (isset($_POST['index_login_submit'])) {
		$security_captcha_database_query = mysql_query("SELECT system_captcha FROM internal_system_db_mainsetting WHERE id='0'");
		if (mysql_result($security_captcha_database_query,0)== "1") {
			if ($_POST['index_security_captcha_field']!=$_SESSION['security_session_captcha_rand']) {
				if ($include_var_name !== "main" || $include_var_name !== "") {
					header('Location: index.php?system_login='.md5(md5("captcha").date("H:i").$_SERVER['REMOTE_ADDR']).'&redir='.base64_encode($include_var_name).'');
					die();
				}
				else {
					header('Location: index.php?system_login='.md5(md5("captcha").date("H:i").$_SERVER['REMOTE_ADDR']).'');
					die();
				}
			}
		}
	}
	$security_login_usercheck_query = mysql_query("SELECT * FROM internal_system_db_users WHERE md5_hash='".md5(mysql_real_escape_string($security_check_login_username).mysql_real_escape_string($security_check_login_password))."' AND username='".mysql_real_escape_string($security_check_login_username)."'");
	if (mysql_num_rows($security_login_usercheck_query)==1) {
		session_regenerate_id();
		$_SESSION['security_session_username'] = $security_check_login_username;
		$_SESSION['security_session_password'] = $security_check_login_password;
		$internal_user_array = mysql_fetch_array($security_login_usercheck_query);
		$internal_user_name = $internal_user_array['username'];
		$internal_user_level = $internal_user_array['user_level'];
		$internal_user_id = $internal_user_array['id'];
		$security_session_status = TRUE;
		if (isset($_POST['index_login_submit'])) $usermessage_gre[] = "<h2>".$language_message[16]."</h2>";
	}
	else {
		session_destroy();
		$security_session_status = FALSE;
	}
}
if (isset($security_session_status)) {
	if ($security_session_status!=TRUE && ($_GET['external_api']!="1")) {
		if ($include_var_name != "main" || $include_var_name != "") {
			header('Location: index.php?system_login='.md5(md5("data").date("H:i").$_SERVER['REMOTE_ADDR']).'&redir='.base64_encode($include_var_name).'');
			die();
		}
		else {
			header('Location: index.php?system_login='.md5(md5("data").date("H:i").$_SERVER['REMOTE_ADDR']).'');
			die();
		}
	}
}
if (file_exists("".dirname(__FILE__)."/install/install.php")) {
	$usermessage_red[] = "<h2>".$language_message[17]."</h2>";
}
if (!file_exists("".dirname(__FILE__)."/include/".$include_var_name."_bottom.php")) {
	if (file_exists("".dirname(__FILE__)."/include/main_bottom.php")) {
		$usermessage_red[] = "<h2>".$language_message[18]."</h2>";
		$include_var_name = "main";
	}
	else {
		$usermessage_red[] = "<h2>".$language_message[18]."</h2>";
		$include_var_name = "_no";
	}
}
if (($include_var_name == "admserver") || ($include_var_name == "admradio") || ($include_var_name == "admuser")) {
    if (($include_var_name == "admserver") && ($internal_user_level!="Super Administrator")) {
        $include_var_name = "main";
        $usermessage_red[] = "<h2>".$language_message[19]."</h2>";
    }
    elseif ((($include_var_name == "admradio") || ($include_var_name == "admuser")) && (($internal_user_level!="Super Administrator") && ($internal_user_level!="Reseller"))) {
		$include_var_name = "main";
		$usermessage_red[] = "<h2>".$language_message[19]."</h2>";
    }     
}
if (($_GET['playlist_xml'] == "left") && (preg_match("/^[0-9]{1,10}+$/", $_GET['playlist_xml_port']))) {
	$playlist_xml_port = intval($_GET['playlist_xml_port']);
	if (mysql_num_rows(mysql_query("SELECT * FROM internal_system_db_servers WHERE portbase='".mysql_real_escape_string(trim($playlist_xml_port))."' AND owner='".mysql_real_escape_string(trim($internal_user_name))."'"))==1) {
		header("Content-type:text/xml"); print("<?xml version=\"1.0\" encoding=\"".htmlspecialchars("UTF-8")."\" standalone=\"yes\" ?>");
		$playlist_xml_left_listing_start = 1;
		$playlist_xml_left_listing_end = 1000;
		if (isset($_GET['playlist_folder'])) {
			$playlist_xml_left_dirlisting = @scandir("".dirname(__FILE__)."/clients/".$internal_user_id."/".$playlist_xml_port."/uploads/audio/".htmlspecialchars($_GET['playlist_folder'])."/") or die ();
		}
		else {
			$playlist_xml_left_dirlisting = @scandir("".dirname(__FILE__)."/clients/".$internal_user_id."/".$playlist_xml_port."/uploads/audio/") or die ();
		}
		$playlist_xml_left_dirlistingsearch  = array('&', '<', '>', '"', "'");
		$playlist_xml_left_dirlistingreplace = array('&amp;', '&lt;', '&gt;', '&quot;', '&apos;');
		
		if(!isset($playlist_xml_left_dirlisting[$playlist_xml_left_listing_start])) die();
			echo "<tree id=\"0\">";	
		for($i=$playlist_xml_left_listing_start;$i<=$playlist_xml_left_listing_end;$i++) {
			if (isset($_GET['playlist_folder'])) {
				$directory_check = is_file(dirname(__FILE__)."/clients/".$internal_user_id."/".$playlist_xml_port."/uploads/audio/".htmlspecialchars($_GET['playlist_folder'])."/".$playlist_xml_left_dirlisting[$i]);
			}
			else {
				$directory_check = is_file(dirname(__FILE__)."/clients/".$internal_user_id."/".$playlist_xml_port."/uploads/audio/".$playlist_xml_left_dirlisting[$i]);
			}
			if (($playlist_xml_left_dirlisting[$i]!=".") && ($playlist_xml_left_dirlisting[$i]!="..") && ($playlist_xml_left_dirlisting[$i]!="") && ($directory_check)) {
				if (isset($_GET['playlist_folder'])) {
					echo "<item id=\"".dirname(__FILE__)."/clients/".$internal_user_id."/".$playlist_xml_port."/uploads/audio/".htmlspecialchars($_GET['playlist_folder'])."/".str_replace($playlist_xml_left_dirlistingsearch, $playlist_xml_left_dirlistingreplace, $playlist_xml_left_dirlisting[$i])."\" text=\"".str_replace($playlist_xml_left_dirlistingsearch, $playlist_xml_left_dirlistingreplace, $playlist_xml_left_dirlisting[$i])."\" />";
				}
				else {
					echo "<item id=\"".dirname(__FILE__)."/clients/".$internal_user_id."/".$playlist_xml_port."/uploads/audio/".str_replace($playlist_xml_left_dirlistingsearch, $playlist_xml_left_dirlistingreplace, $playlist_xml_left_dirlisting[$i])."\" text=\"".str_replace($playlist_xml_left_dirlistingsearch, $playlist_xml_left_dirlistingreplace, $playlist_xml_left_dirlisting[$i])."\" />";
				}
			}
		}
		echo "</tree>";
		die ();
	}
}
elseif (($_GET['playlist_xml'] == "right") && (isset($_GET['playlist_listname'])) && (preg_match("/^[0-9]{1,10}+$/", $_GET['playlist_xml_port']))) {
	$playlist_xml_port = intval($_GET['playlist_xml_port']);
	if (mysql_num_rows(mysql_query("SELECT * FROM internal_system_db_servers WHERE portbase='".mysql_real_escape_string(trim($playlist_xml_port))."' AND owner='".mysql_real_escape_string(trim($internal_user_name))."'"))==1) {
		header("Content-type:text/xml"); print("<?xml version=\"1.0\" encoding=\"".htmlspecialchars()."\" standalone=\"yes\" ?>");
		if (base64_decode($_GET['playlist_listname']) != "new playlist.lst") {
			$playlist_xml_right_filehandle = fopen("".dirname(__FILE__)."/clients/".$internal_user_id."/".$playlist_xml_port."/configs/playlists/".base64_decode(htmlspecialchars(trim($_GET['playlist_listname'])))."", "r");
			$playlist_xml_right_contents = fread($playlist_xml_right_filehandle, filesize("".dirname(__FILE__)."/clients/".$internal_user_id."/".$playlist_xml_port."/configs/playlists/".base64_decode(htmlspecialchars(trim($_GET['playlist_listname']))).""));
			$playlist_xml_right_entrys = explode("\n",$playlist_xml_right_contents);
			$playlist_xml_right_dirlistingsearch  = array('&', '<', '>', '"', "'");
			$playlist_xml_right_replace = array('&amp;', '&lt;', '&gt;', '&quot;', '&apos;');
		}
		echo ("<tree id='0'>");
		if (base64_decode($_GET['playlist_listname']) != "new playlist.lst") {
			$playlist_xml_right_inta = 0;
			foreach($playlist_xml_right_entrys as $playlist_xml_right_entry) {
				$playlist_xml_right_inta ++;
				$playlist_xml_right_entry1 = str_replace("".dirname(__FILE__)."/clients/".$internal_user_id."/".$playlist_xml_port."/uploads/audio/", "", $playlist_xml_right_entry);
				if($playlist_xml_right_entry1!="")
					echo ("<item child='0' id='".str_replace($playlist_xml_right_dirlistingsearch, $playlist_xml_right_replace, $playlist_xml_right_entry1)."' text='".str_replace($playlist_xml_right_dirlistingsearch, $playlist_xml_right_replace, $playlist_xml_right_entry1)."'></item>");
			}
			fclose($playlist_xml_right_filehandle);
		}
		if (base64_decode($_GET['playlist_listname']) == "new playlist.lst") echo ("<item child='0' id='demo' text='Bitte Playlist leeren'></item>");
		echo("</tree>");
		die ();
	}
}
$internal_user_level = (isset($internal_user_level)) ? $internal_user_level: NULL;
if ($internal_user_level=="Super Administrator" && $_GET['action'] == "remove" && isset($_GET['delmessid'])) {
	if (mysql_query("DELETE FROM internal_system_db_notices WHERE id='".mysql_real_escape_string(trim($_GET['delmessid']))."'")) $usermessage_gre[] = "<h2>".$language_message[20]."</h2>";
	else $usermessage_red[] = "<h2>".$language_message[21]."</h2>";
}
if (!require_once(dirname(__FILE__)."/include/system_function.php")) die ($language_message[22]);
if ((is_file(dirname(__FILE__)."/include/".$include_var_name."_top.php")) && ($include_var_name!="_no")) @include(dirname(__FILE__)."/include/".$include_var_name."_top.php");
$establish_settings_query = mysql_query("SELECT * FROM internal_system_db_mainsetting WHERE id='0'") or die($language_message[23]);
foreach(mysql_fetch_array($establish_settings_query) as $establish_settings_query_key => $establish_settings_query_pref) {
	if (!is_numeric($establish_settings_query_key)) $internal_setting[$establish_settings_query_key] = stripslashes($establish_settings_query_pref);
}
if (!require_once($internal_setting["system_dir"]."include/system_api.php")) die($language_message[22]); elseif ($_GET['external_api']=="1") die();
if ($internal_setting['system_update']=="1") include $internal_setting["system_dir"]."include/update.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" dir="ltr">
<head>

	<title><?php echo htmlspecialchars($internal_setting['system_title'])." - ".htmlspecialchars($internal_setting['system_slogan']);?></title>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<link rel="stylesheet" type="text/css" href="./include/css/framework.css" />
	<link rel="icon" href="./images/favicon.ico" type="image/x-icon" />
	<link rel="shortcut icon" href="./images/favicon.ico" type="image/x-icon" />
	<script type="text/javascript" src="./include/scripts/jquery.min.js"></script>
	<script type="text/javascript" src="./include/scripts/jquery.nyroModal-1.6.2.pack.js"></script>
	<script type="text/javascript" src="./include/scripts/functions.js"></script>
	<?php
	switch ($include_var_name) {
		case "main":
			echo "
			<script type=\"text/javascript\">
			$(function() {		
				function preloadImg(image) {
					var img = new Image();
					img.src = image;
				}
				preloadImg('images/modalwin/ajaxLoader.gif');
			});	
			</script>";
			break;
		case "playlist":
			echo "
			<script type=\"text/javascript\">
			function clearPlaylist()
			{
				var itemId=this.tree2.rootId;
				var temp=this.tree2._globalIdStorageFind(itemId);
				this.tree2.deleteChildItems(itemId);
			}
			function setValue()
			{
				var i = 0;
				var j = 0;
				var n = 0;
				arvArray = new Array();	
				arvArray = getChilds(this.tree2.htmlNode, arvArray)
				var arv = arvArray.toString();
				document.treeform.arv.value = escape(arv);
			}
			function getChilds(Childs, arr, label) {
				var i = 0;
				for(i = 0; i < Childs.childsCount; i++) {
					if(Childs.childNodes[i].childsCount == 0) {
						if(Childs.childNodes[i].label[0] != \"/\") {
							arr.push(label+Childs.childNodes[i].label);
						}
						else arr.push(Childs.childNodes[i].label);
					}
					else {
						arr = getChilds(Childs.childNodes[i], arr, label+Childs.childNodes[i].label+\"/\")
					}
				}
				return arr;
			}
			</script>";
			if (isset($_GET['set_name']))
			echo "
			<script type=\"text/javascript\" src='./include/scripts/jquery.scrollTo-1.4.2-min.js'></script>
			<script type=\"text/javascript\">
			$(document).ready(function() { 
				$.scrollTo( '90%', 800 );
			});
			</script>";
			break;
		case "upload":
			echo "
			<script type=\"text/javascript\">
				function setVisibility(id, visibility) {
					document.getElementById(id).style.display = visibility;
				}
			</script>";
			break;
		case "account":
			if (isset($_POST['account_secretkey'])) {
				echo "
				<script type=\"text/javascript\" src='./include/scripts/jquery.scrollTo-1.4.2-min.js'></script>
				<script type=\"text/javascript\">
				$(document).ready(function() { 
					$.scrollTo( '100%', 800 );
				});
				</script>";
			}
			break;
	}
?>
</head>
<body>
<div id="container">
	<div id="header_top">
		<div class="header logo">
			<a href="content.php" title=""><img src="<?php if (preg_match('~((http|https|ftp):\/\/).*\.(gif|jpeg|jpg|png)$~i', $internal_setting["system_logourl"])) echo htmlspecialchars($internal_setting["system_logourl"]); else echo "./images/logo.png"; ?>" alt="" /></a>
		</div>
		<div class="header top_nav" id="header_top_nav_div">
			<span class="session" id="header_top_nav_cont"><?php echo $language_message[24];?> <?PHP echo $internal_user_name;?> (<a href="content.php?security_login=<?php echo md5(md5("logout").$_SERVER['REMOTE_ADDR']);?>" title="Sign out"><?php echo $language_message[25];?></a>)</span>
		</div>
	</div>
	<div id="sidebar">
		<div id="navigation">
			<div class="sidenav">
				<div class="nav_info">
					<span><?php echo $language_message[26];?> <span class="nav_info_username"><?PHP echo $internal_user_name;?></span>,</span><br/>
					<?php
					if ($internal_user_level=="Super Administrator")	{
						$internal_notices_query = mysql_query("SELECT * FROM internal_system_db_notices");
						if (mysql_num_rows($internal_notices_query)==0) echo "<span class=\"nav_info_messages\">".$language_message[27]."</span>";
						else {
							$internal_notices_query_quant = mysql_num_rows($internal_notices_query);
							if ($internal_notices_query_quant == 1) echo "<span class=\"nav_info_messages\">".htmlspecialchars($language_message[28])." <b>".htmlspecialchars($internal_notices_query_quant)."</b> ".$language_message[29]."</span>";
							else echo "<span class=\"nav_info_messages\">".$language_message[30]." <b>".htmlspecialchars($internal_notices_query_quant)."</b> ".$language_message[31]." </span>";
						}
					}
					else echo "<span class=\"nav_info_messages\">Shoutcast Admin Panel 3 - ".$language_message[32]."</span>";
					?>
				</div>
				<div class="navhead_blank">
					<span><?php echo $language_message[33];?></span>
					<span><?php echo $language_message[34];?></span>
				</div>
				<div class="subnav_child">
					<ul class="submenu">
						<li><a href="content.php?include=contact" title=""><?php echo $language_message[35];?></a></li>
						<li><a href="content.php?include=account" title=""><?php echo $language_message[36];?></a></li>
						<li><a href="content.php?include=server" title=""><?php echo $language_message[37];?></a></li>
					</ul>
				</div>
				<div class="navhead">
					<span><?php echo $language_message[38];?></span>
					<span><?php echo $language_message[39];?></span>
				</div>
				<div class="subnav">
					<ul class="submenu">
						<li><a href="content.php?include=music" title=""><?php echo $language_message[40];?></a></li>
						<li><a href="content.php?include=autodj" title=""><?php echo $language_message[41];?></a></li>
					</ul>
				</div>
				<?php if ($internal_user_level=="Super Administrator" || $internal_user_level=="Reseller") { ?>
				<div class="navhead">
					<span><?php if ($internal_user_level=="Super Administrator") echo $language_message[42]; else echo $language_message[43];?></span>
					<span><?php echo $language_message[44];?></span>
				</div>
				<div class="subnav">
					<ul class="submenu">
                   		<?php if ($internal_user_level=="Super Administrator") echo '<li><a href="content.php?include=admserver" title="">'.$language_message[45].'</a></li>';?>
						<li><a href="content.php?include=admradio" title=""><?php echo $language_message[46];?></a></li>
						<li><a href="content.php?include=admuser" title=""><?php echo $language_message[47];?></a></li>
					</ul>
				</div>
				<?php } ?>
				<div class="navhead">
					<span><?php echo $language_message[48];?></span>
					<span><?php echo $language_message[49];?></span>
				</div>
				<div class="subnav">
					<table cellspacing="0" cellpadding="0" class="ip_table">
						<tbody>
							<tr>
								<td class="ip_table"><?php echo $language_message[51];?>:</td>
								<td class="ip_table_under"><?php echo ($_SERVER['REMOTE_ADDR']);?></td>
							</tr>
							<tr>
								<td class="ip_table"><?php echo $language_message[52];?>:</td>
								<td class="ip_table_under"><?php echo ($_SERVER['SERVER_ADDR']);?></td>
							</tr>
							<tr>
								<td class="ip_table"><?php echo $language_message[53];?>:</td>
								<td class="ip_table_under">3.2 RC1</td>
							</tr>
							<tr>
								<td class="ip_table"><?php echo $language_message[54];?>:</td>
								<td class="ip_table_under"><?php echo phpversion();?></td>
							</tr>
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
	<div id="primary">
    	<noscript><div class="notifi"><h2><?php echo $language_message[55];?></h2></div></noscript>
		<?PHP
		if(count($usermessage_red) > 0) {
			foreach($usermessage_red as $usermessage_red_cont)
				$usermessage_red_list.="<div class=\"error\">".$usermessage_red_cont."</div>";
			echo ($usermessage_red_list);
		}
		if(count($usermessage_yel) > 0) {
			foreach($usermessage_yel as $usermessage_yel_cont)
				$usermessage_yel_list.="<div class=\"notifi\">".$usermessage_yel_cont."</div>";
			echo ($usermessage_yel_list);
		}
		if(count($usermessage_gre) > 0) {
			foreach($usermessage_gre as $usermessage_gre_cont)
				$usermessage_gre_cont_list.="<div class=\"correct\">".$usermessage_gre_cont."</div>";
			echo ($usermessage_gre_cont_list);
		}
		include $internal_setting["system_dir"]."include/".$include_var_name."_bottom.php";
		?>
	</div>
	<div class="clear"></div>
	<?php // DO NOT CHANGE this content of the footer, this is a license requirement, otherwise you would violate the program license, this could be reported!?>
	<div id="footer">
		<p><?php echo htmlspecialchars($internal_setting["system_title"]); ?> | djcrackhome | <a href="http://www.streamerspanel.com">http://www.streamerspanel.com</a> | <a href="http://www.nagualmedia.de/">Design by Zephon</a> | <?php echo $language_message[0];?></p>
	</div>
	<?php // END OF FOOTER ?>
</div>
<script type="text/javascript">
$(document).ready(function() { 
	$('#header_top_nav_div').width($('#header_top_nav_cont').width()+62);
});
</script>
</body>
</html>
<?php
mysql_close($establish_db_connect);
?>