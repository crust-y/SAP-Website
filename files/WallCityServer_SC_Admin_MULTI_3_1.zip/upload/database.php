<?php

$db_host = "localhost"; 
$db_username = "username"; 
$db_password = "password"; 
$database = "dbname";

?>